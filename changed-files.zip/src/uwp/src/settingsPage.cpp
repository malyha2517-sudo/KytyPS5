#include "settingsPage.h"

#include "controlsPage.h"
#include "controllerSettings.h"
#include "fileAccess.h"
#include "folderPanel.h"
#include "input.h"
#include "overlay.h"
#include "settingTiles.h"
#include "settings.h"
#include "trophiesPage.h"
#include "xboxLook.h"

#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Graphics.Display.Core.h>
#include <winrt/Windows.Storage.Pickers.h>
#include <winrt/Windows.Storage.h>
#include <winrt/Windows.System.h>
#include <winrt/Windows.UI.Core.h>
#include <winrt/Windows.UI.Xaml.Controls.Primitives.h>
#include <winrt/Windows.UI.Xaml.Controls.h>
#include <winrt/Windows.UI.Xaml.Input.h>
#include <winrt/Windows.UI.Xaml.Markup.h>
#include <winrt/Windows.UI.Xaml.Media.h>
#include <winrt/Windows.UI.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <filesystem>
#include <functional>
#include <memory>
#include <string>
#include <utility>
#include <vector>

namespace Kyty::Uwp {

namespace {

// The Xbox's current TV mode as the Your TV tile shows it ("4K · 120 Hz"; HdmiDisplayInformation, on the UI thread).
std::wstring TvModeName() {
	try {
		const auto hdmi = winrt::Windows::Graphics::Display::Core::HdmiDisplayInformation::GetForCurrentView();
		const auto mode = hdmi != nullptr ? hdmi.GetCurrentDisplayMode() : nullptr;
		if (mode != nullptr) {
			const auto   width  = mode.ResolutionWidthInRawPixels();
			const auto   height = mode.ResolutionHeightInRawPixels();
			std::wstring name   = width == 3840 && height == 2160   ? L"4K"
			                      : width == 2560 && height == 1440 ? L"1440p"
			                      : width == 1920 && height == 1080 ? L"1080p"
			                      : width == 1280 && height == 720  ? L"720p"
			                                                        : std::to_wstring(width) + L" \u00D7 " + std::to_wstring(height);
			return name + L" \u00B7 " + std::to_wstring(std::lround(mode.RefreshRate())) + L" Гц";
		}
	} catch (winrt::hresult_error const&) {
	}
	return L"Неизвестно";
}


namespace xaml = winrt::Windows::UI::Xaml;

struct Resolution {
	uint32_t       width;
	uint32_t       height;
	const wchar_t* name;
};
// The TV resolution the games are told (VideoOutGetOutputStatus): 1080p below 3840 × 2160, 4K from it. A game that doesn't ask always hears 4K, and
// the picture is scaled to the screen either way, so these two are all there is to choose.
constexpr std::array RESOLUTIONS = {
    Resolution {1920, 1080, L"1080p"},
    Resolution {3840, 2160, L"4K"},
};

// By the system's language ID, as the desktop launcher lists them.
constexpr std::array CONSOLE_LANGUAGES = {
    L"Japanese",
    L"English (United States)",
    L"French (France)",
    L"Spanish (Spain)",
    L"German",
    L"Italian",
    L"Dutch",
    L"Portuguese (Portugal)",
    L"Russian",
    L"Korean",
    L"Chinese (Traditional)",
    L"Chinese (Simplified)",
    L"Finnish",
    L"Swedish",
    L"Danish",
    L"Norwegian",
    L"Polish",
    L"Portuguese (Brazil)",
    L"English (United Kingdom)",
    L"Turkish",
    L"Spanish (Latin America)",
    L"Arabic",
    L"French (Canada)",
    L"Czech",
    L"Hungarian",
    L"Greek",
    L"Romanian",
    L"Thai",
    L"Vietnamese",
    L"Indonesian",
};

constexpr wchar_t SettingsMarkup[] = LR"xaml(
<Grid xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
      xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
      Background="{ThemeResource ApplicationPageBackgroundThemeBrush}" Padding="0,40,0,32">
  <Grid.RowDefinitions>
    <RowDefinition Height="Auto" />
    <RowDefinition Height="*" />
    <RowDefinition Height="Auto" />
  </Grid.RowDefinitions>
  <TextBlock x:Name="PageTitle" Text="Настройки" Style="{StaticResource PageTitleTextBlockStyle}" Margin="48,0,48,20" />
  <!-- As the Xbox's Settings: the categories on the left (the chosen one in its green), the settings of the chosen one in columns of tiles
       (SettingTile, 219 wide, 36 between columns), and next to them the explanation of the one with the focus. -->
  <Grid x:Name="Main" Grid.Row="1" ColumnSpacing="24">
    <Grid.ColumnDefinitions>
      <ColumnDefinition Width="220" />
      <ColumnDefinition Width="*" />
    </Grid.ColumnDefinitions>
    <Grid>
      <Grid.RowDefinitions>
        <RowDefinition Height="*" />
        <RowDefinition Height="Auto" />
      </Grid.RowDefinitions>
      <ListView x:Name="Categories" SelectionMode="Single" Padding="0">
        <ListView.Resources>
          <SolidColorBrush x:Key="ListViewItemBackgroundSelected" Color="#54A81B" />
          <SolidColorBrush x:Key="ListViewItemBackgroundSelectedPointerOver" Color="#5FB526" />
          <SolidColorBrush x:Key="ListViewItemBackgroundSelectedPressed" Color="#4A9518" />
          <SolidColorBrush x:Key="ListViewItemForegroundSelected" Color="White" />
        </ListView.Resources>
        <ListView.ItemContainerStyle>
          <Style TargetType="ListViewItem">
            <Setter Property="CornerRadius" Value="0" />
            <Setter Property="Padding" Value="48,0,12,0" />
            <Setter Property="MinHeight" Value="34" />
          </Style>
        </ListView.ItemContainerStyle>
        <x:String>Экран</x:String>
        <x:String>Оверлей</x:String>
        <x:String>Контроллер</x:String>
        <x:String>Система</x:String>
        <x:String>Хранилище</x:String>
        <x:String>Память и качество</x:String>
        <x:String>Разработчик</x:String>
      </ListView>
      <TextBlock Grid.Row="1" Margin="48,12,12,0" Style="{StaticResource CaptionTextBlockStyle}" TextWrapping="Wrap"
                 Foreground="{ThemeResource SystemControlForegroundBaseMediumBrush}"
                 Text="Настройки игры применяются к следующей запущенной игре." />
    </Grid>

    <Grid Grid.Column="1" Margin="0,0,36,0">
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="Auto" />
        <ColumnDefinition Width="*" />
      </Grid.ColumnDefinitions>
      <ScrollViewer x:Name="Panels" VerticalScrollBarVisibility="Hidden" Padding="0,0,0,16">
        <Grid>
          <!-- A category's settings: one column, or two groups with headings where one column would be taller than the screen, as the Xbox
               groups a page's settings in columns. -->
          <StackPanel x:Name="Display" Orientation="Horizontal" Spacing="36">
            <StackPanel x:Name="DisplayGames" Width="219" Spacing="8" />
            <StackPanel x:Name="DisplayPicture" Width="219" Spacing="8" />
          </StackPanel>

          <StackPanel x:Name="Overlay" Orientation="Horizontal" Spacing="18" Visibility="Collapsed">
            <StackPanel x:Name="OverlayGroup" Width="219" Spacing="8" />
            <StackPanel x:Name="OnScreenGroup" Width="219" Spacing="8" />
          </StackPanel>

          <!-- The category's pages as the Xbox shows a category's pages: wide tiles, two in a row; each opens full screen (Detail). -->
          <Grid x:Name="Controller" ColumnSpacing="8" RowSpacing="8" Visibility="Collapsed">
            <Grid.ColumnDefinitions>
              <ColumnDefinition Width="Auto" />
              <ColumnDefinition Width="Auto" />
            </Grid.ColumnDefinitions>
            <Grid.RowDefinitions>
              <RowDefinition Height="Auto" />
              <RowDefinition Height="Auto" />
            </Grid.RowDefinitions>
          </Grid>

          <!-- What the emulated console tells the games. -->
          <StackPanel x:Name="System" Width="219" Spacing="8" Visibility="Collapsed">
            <TextBox x:Name="UserName" Header="Имя пользователя" MaxLength="16" />
          </StackPanel>

          <!-- Where games are found, and where their data is kept. The headings are as AddHeading makes them. -->
          <StackPanel x:Name="Storage" Width="474" Spacing="12" Visibility="Collapsed">
            <TextBlock Text="Папки с играми" Style="{StaticResource BodyTextBlockStyle}" Margin="0,0,0,-8" />
            <StackPanel x:Name="Folders" Spacing="8" />
            <!-- A menu where there is more than one way to choose (the Xbox's Development Files), else the picker at once. -->
            <Button x:Name="AddFolder" Content="Добавить папку" />
            <DropDownButton x:Name="AddFolderMenu" Content="Добавить папку" Visibility="Collapsed" />
            <TextBlock Text="Папка данных" Style="{StaticResource BodyTextBlockStyle}" Margin="0,24,0,-8" />
            <!-- As a game folder's row: the path, its state under it. -->
            <StackPanel>
              <TextBlock x:Name="UserDataPath" TextWrapping="Wrap" />
              <TextBlock x:Name="UserDataStatus" Style="{StaticResource CaptionTextBlockStyle}" TextWrapping="Wrap" IsTextSelectionEnabled="True" />
            </StackPanel>
            <DropDownButton x:Name="ChooseUserData" Content="Выбрать папку" />
            <!-- Where the games' compiled shaders and pipelines go, as the data folder's row. -->
            <TextBlock Text="Кэш шейдеров" Style="{StaticResource BodyTextBlockStyle}" Margin="0,24,0,-8" />
            <StackPanel>
              <TextBlock x:Name="ShaderCachePath" TextWrapping="Wrap" />
              <TextBlock x:Name="ShaderCacheStatus" Style="{StaticResource CaptionTextBlockStyle}" TextWrapping="Wrap" IsTextSelectionEnabled="True" />
            </StackPanel>
            <DropDownButton x:Name="ChooseShaderCache" Content="Выбрать папку" />
            <!-- Where the logs and frame dumps go, as the data folder's row (shown where a folder can be chosen for them). -->
            <StackPanel x:Name="Logs" Spacing="12" Visibility="Collapsed">
              <TextBlock Text="Журналы и дампы" Style="{StaticResource BodyTextBlockStyle}" Margin="0,24,0,-8" />
              <StackPanel>
                <TextBlock x:Name="LogsPath" TextWrapping="Wrap" />
                <TextBlock x:Name="LogsStatus" Style="{StaticResource CaptionTextBlockStyle}" TextWrapping="Wrap" IsTextSelectionEnabled="True" />
              </StackPanel>
              <DropDownButton x:Name="ChooseLogs" Content="Выбрать папку" />
            </StackPanel>
          </StackPanel>

          <StackPanel x:Name="Memory" Orientation="Horizontal" Spacing="36" Visibility="Collapsed">
            <StackPanel x:Name="MemoryGroup" Width="219" Spacing="8" />
            <StackPanel x:Name="TextureGroup" Width="219" Spacing="8" />
          </StackPanel>

          <StackPanel x:Name="Developer" Orientation="Horizontal" Spacing="36" Visibility="Collapsed">
            <StackPanel x:Name="DiagnosticsGroup" Width="219" Spacing="8" />
            <StackPanel Width="219" Spacing="8">
              <StackPanel x:Name="TestingGroup" Spacing="8" />
              <Button x:Name="RemoveShaders" Content="Удалить скомпилированные шейдеры" HorizontalAlignment="Stretch" Margin="0,8,0,0" />
              <TextBlock x:Name="RemoveShadersStatus" Style="{StaticResource CaptionTextBlockStyle}" TextWrapping="Wrap" />
              <Button x:Name="ResetTrophies" Content="Сбросить все трофеи" HorizontalAlignment="Stretch" Margin="0,8,0,0" />
              <TextBlock x:Name="ResetTrophiesStatus" Style="{StaticResource CaptionTextBlockStyle}" TextWrapping="Wrap" />
            </StackPanel>
          </StackPanel>
        </Grid>
      </ScrollViewer>
      <!-- The explanation of the setting with the focus, or of the category: a paragraph each for what it does, its effect and a warning. -->
      <StackPanel x:Name="Explanation" Grid.Column="1" Margin="24,0,0,0" MaxWidth="216" HorizontalAlignment="Left" VerticalAlignment="Top"
                  Spacing="12" />
    </Grid>
  </Grid>
  <!-- A category's page, full screen as on the Xbox: the category and the page as the title, the page's columns of tiles (a heading over
       each), and next to them the explanation of the tile with the focus. -->
  <Grid x:Name="Detail" Grid.RowSpan="2" Visibility="Collapsed">
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto" />
      <RowDefinition Height="*" />
    </Grid.RowDefinitions>
    <TextBlock x:Name="DetailTitle" Style="{StaticResource PageTitleTextBlockStyle}" Margin="48,0,48,20" />
    <Grid Grid.Row="1" Margin="48,0,48,0">
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="Auto" />
        <ColumnDefinition Width="*" />
      </Grid.ColumnDefinitions>
      <ScrollViewer VerticalScrollBarVisibility="Hidden" Padding="0,0,0,16">
        <StackPanel x:Name="DetailColumns" Orientation="Horizontal" Spacing="36" />
      </ScrollViewer>
      <StackPanel x:Name="DetailExplanation" Grid.Column="1" Margin="36,0,0,0" MaxWidth="325" HorizontalAlignment="Left"
                  VerticalAlignment="Top" Spacing="12" />
    </Grid>
  </Grid>
  <Border x:Name="Hints" Grid.Row="2" Style="{StaticResource HintBarStyle}" Margin="48,16,48,0" />
</Grid>)xaml";

// Settings › Controller's pages.
enum class ControllerPage { Players, Servers, Feedback, Motion };

struct SettingsState {
	AppSettings settings = LoadSettings();
	// The open pages (Detail), the shown one last. Empty while the categories show.
	std::vector<ControllerPage> pages;
	// Focus to restore when returning from the Button layout page.
	winrt::weak_ref<xaml::Controls::Control> return_focus;
	winrt::event_token back_token {};
	bool folders_changed = false;
	bool left = false;
	std::function<void(bool)> back;
	winrt::weak_ref<xaml::Controls::StackPanel> folders;
	// Back for the Development Files panel while it shows (ShowDevelopmentFilesPanel); false once it went.
	std::function<bool()> folder_back;
	// Held, not weak: with weak references these lines stayed empty on the Xbox. They have no handlers, so nothing leads from them
	// back to the state.
	xaml::Controls::TextBlock user_data_path {nullptr};
	xaml::Controls::TextBlock user_data_status {nullptr};
	xaml::Controls::TextBlock logs_path {nullptr};
	xaml::Controls::TextBlock logs_status {nullptr};
	xaml::Controls::TextBlock shader_cache_path {nullptr};
	xaml::Controls::TextBlock shader_cache_status {nullptr};
};

void ListFolders(const std::shared_ptr<SettingsState>& state);

// The data folder when none is chosen: the app's own folder, which on the Xbox is on the console's internal drive.
const wchar_t* DefaultDataFolderName() {
	return IsXbox() ? L"Внутренняя память" : L"Папка по умолчанию";
}

// A chosen folder the app writes in (the data folder, the logs and dumps folder), and whether it may, as `write_error` tells for the calls
// that write there (with the command that allows it where it may not). Empty: the default folder.
void ShowWritableFolder(xaml::Controls::TextBlock const& path_text, xaml::Controls::TextBlock const& status, std::filesystem::path path,
                        uint32_t (*write_error)(const std::filesystem::path&)) {
	// No empty line under the path when there is nothing to say.
	status.Visibility(path.empty() ? xaml::Visibility::Collapsed : xaml::Visibility::Visible);
	if (path.empty()) {
		path_text.Text(DefaultDataFolderName());
		status.Text(L"");
		return;
	}
	path_text.Text(path.make_preferred().wstring());
	// Windows' "file not found", "path not found" and "device not ready": the folder or its drive is not there, which no access helps.
	constexpr std::array<uint32_t, 3> MISSING = {2, 3, 21};
	const auto                        error   = write_error(path);
	if (error == 0) {
		status.Text(L"Запись доступна");
	} else if (std::find(MISSING.begin(), MISSING.end(), error) != MISSING.end()) {
		status.Text(L"Папка не найдена. Подключите диск или выберите другую папку.");
	} else {
		// Only a PC can give apps access to a folder: on the Xbox, the drive goes to a PC for it, where its letter differs (GrantCommand writes X:).
		status.Text(L"Запись невозможна. Код ошибки " + std::to_wstring(error) + L".\n" +
		                             (IsXbox() ? L"Чтобы разрешить запись, подключите диск к компьютеру и выполните это там от имени администратора, подставив букву диска вместо X:\n"
		                                       : L"Чтобы разрешить запись, выполните это от имени администратора:\n") +
		                             GrantCommand(path, true));
	}
}

// Saves, patches and trophies are written with the *FromApp functions (Common::File).
void ShowUserData(const std::shared_ptr<SettingsState>& state) {
	ShowWritableFolder(state->user_data_path, state->user_data_status, state->settings.user_data_path, WriteError);
}

// The compiled shaders, as the user's data, with the *FromApp functions (Common::File).
void ShowShaderCache(const std::shared_ptr<SettingsState>& state) {
	ShowWritableFolder(state->shader_cache_path, state->shader_cache_status, state->settings.shader_cache_path, WriteError);
}

// The logs and the frame dumps with the C library.
void ShowLogs(const std::shared_ptr<SettingsState>& state) {
	ShowWritableFolder(state->logs_path, state->logs_status, state->settings.logs_path, DirectWriteError);
}

// The system's folder picker: `chosen` gets the folder, unless none was chosen.
winrt::fire_and_forget PickFolder(std::function<void(const std::filesystem::path&)> chosen) {
	winrt::Windows::Storage::Pickers::FolderPicker picker;
	picker.FileTypeFilter().Append(L"*");
	const auto folder = co_await picker.PickSingleFolderAsync();
	if (folder == nullptr || folder.Path().empty()) {
		co_return;
	}
	chosen(std::filesystem::path(std::wstring(folder.Path())));
}

void AddGameFolder(const std::shared_ptr<SettingsState>& state, const std::filesystem::path& path) {
	auto& folders = state->settings.game_folders;
	if (std::find(folders.begin(), folders.end(), path) == folders.end()) {
		folders.push_back(path);
		SaveSettings(state->settings);
		state->folders_changed = true;
		ListFolders(state);
	}
}

// The system's folder picker.
winrt::fire_and_forget AddFolder(std::shared_ptr<SettingsState> state) {
	winrt::Windows::Storage::Pickers::FolderPicker picker;
	picker.FileTypeFilter().Append(L"*");
	const auto folder = co_await picker.PickSingleFolderAsync();
	if (folder == nullptr || folder.Path().empty()) {
		co_return;
	}
	AddGameFolder(state, std::filesystem::path(std::wstring(folder.Path())));
}

// A row per game folder: the path, whether the app may read it, and Remove.
void ListFolders(const std::shared_ptr<SettingsState>& state) {
	const auto panel = state->folders.get();
	if (panel == nullptr) {
		return;
	}
	panel.Children().Clear();
	if (state->settings.game_folders.empty()) {
		xaml::Controls::TextBlock none;
		none.Text(L"Папки не добавлены.");
		panel.Children().Append(none);
	}
	for (size_t index = 0; index < state->settings.game_folders.size(); index++) {
		auto folder = state->settings.game_folders[index];

		xaml::Controls::TextBlock path;
		path.Text(folder.make_preferred().wstring());
		path.TextWrapping(xaml::TextWrapping::Wrap);
		xaml::Controls::TextBlock status;
		const auto error = ListError(folder);
		status.Text(error == 0 ? winrt::hstring(L"Чтение доступно")
		                       : L"Чтение невозможно. Код ошибки " + winrt::to_hstring(error) + L". Как это разрешить, показано в библиотеке.");
		status.Style(xaml::Application::Current().Resources().Lookup(winrt::box_value(L"CaptionTextBlockStyle"))
		                 .as<xaml::Style>());
		xaml::Controls::StackPanel text;
		text.Children().Append(path);
		text.Children().Append(status);

		xaml::Controls::Button remove;
		remove.Content(winrt::box_value(L"Remove"));
		remove.VerticalAlignment(xaml::VerticalAlignment::Center);
		remove.Click([state, folder](auto const&, auto const&) {
			auto& folders = state->settings.game_folders;
			folders.erase(std::remove(folders.begin(), folders.end(), folder), folders.end());
			SaveSettings(state->settings);
			state->folders_changed = true;
			ListFolders(state);
		});

		xaml::Controls::Grid row;
		row.ColumnSpacing(16);
		row.ColumnDefinitions().Append(xaml::Controls::ColumnDefinition());
		xaml::Controls::ColumnDefinition button_column;
		button_column.Width(xaml::GridLengthHelper::Auto());
		row.ColumnDefinitions().Append(button_column);
		row.Children().Append(text);
		row.Children().Append(remove);
		xaml::Controls::Grid::SetColumn(remove, 1);
		panel.Children().Append(row);
	}
}

// 0% to 100% in steps of 10: the controller's vibration and speaker volume.
std::vector<std::wstring> Percentages() {
	std::vector<std::wstring> names;
	for (int percent = 0; percent <= 100; percent += 10) {
		names.push_back(std::to_wstring(percent) + L"%");
	}
	return names;
}

} // namespace

xaml::UIElement CreateSettingsPage(std::function<void(bool folders_changed)> back) {
	auto page       = xaml::Markup::XamlReader::Load(SettingsMarkup).as<xaml::Controls::Grid>();
	auto state      = std::make_shared<SettingsState>();
	state->back     = std::move(back);
	state->folders  = winrt::make_weak(page.FindName(L"Folders").as<xaml::Controls::StackPanel>());
	auto& settings  = state->settings;
	const auto save = [state] { SaveSettings(state->settings); };

	SetHints(page.FindName(L"Hints").as<xaml::Controls::Border>(), {{XboxButton::A, L"Выбрать"}, {XboxButton::B, L"Назад"}});
	const auto panel       = [&page](const wchar_t* name) { return page.FindName(name).as<xaml::Controls::Panel>(); };
	const auto explanation = page.FindName(L"Explanation").as<xaml::Controls::StackPanel>();

	// Display: the TV, what games see, then upscaling and frame rate (two columns, as the Xbox's Settings group a page's tiles).
	const auto games   = panel(L"DisplayGames");
	const auto picture = panel(L"DisplayPicture");
	// A heading under other tiles keeps a gap above it.
	const auto heading = [](xaml::Controls::Panel const& column, const wchar_t* text) {
		const bool below = column.Children().Size() > 0;
		AddHeading(column, text);
		if (below) {
			auto added = column.Children().GetAt(column.Children().Size() - 1).as<xaml::FrameworkElement>();
			added.Margin(xaml::ThicknessHelper::FromLengths(0, 16, 0, 4));
		}
	};
	if (IsXbox()) {
		heading(games, L"Ваш ТВ");
		AddAction(
		    games, explanation, TvModeName().c_str(), L"Задаётся в настройках Xbox", [] {},
		    {L"Это режим, который консоль передаёт на ваш ТВ. Чтобы изменить его, откройте Настройки \u203A Общие \u203A Параметры ТВ и дисплея."});
	}
	heading(games, L"Что видят игры");
	{
		std::vector<std::wstring> names;
		for (const auto& resolution: RESOLUTIONS) {
			names.emplace_back(resolution.name);
		}
		// Older sizes from the settings file (1280 x 720, 2560 x 1440) are told as 1080p, and show as it.
		const size_t selected = settings.screen_width >= 3840 && settings.screen_height >= 2160 ? 1 : 0;
		AddChoice(
		    games, explanation, L"Разрешение PS5", std::move(names), selected,
		    [state, save](size_t index) {
			    state->settings.screen_width  = RESOLUTIONS[index].width;
			    state->settings.screen_height = RESOLUTIONS[index].height;
			    save();
		    },
		    {IsXbox() ? L"Некоторые игры выбирают чёткость рендеринга исходя из этого значения. 4K выглядит чётче, но может снизить частоту кадров. Режим вашего ТВ не меняется."
		              : L"Некоторые игры выбирают чёткость рендеринга исходя из этого значения. 4K выглядит чётче, но может снизить частоту кадров. Режим вашего дисплея не меняется."});
	}
	{
		// The settings page's rates; another one from the settings file stays a choice of its own.
		std::vector<uint32_t> rates {30, 60, 120};
		const auto            current = std::clamp<uint32_t>(settings.vblank_frequency, 30, 360);
		if (std::find(rates.begin(), rates.end(), current) == rates.end()) {
			rates.insert(std::upper_bound(rates.begin(), rates.end(), current), current);
		}
		std::vector<std::wstring> names;
		for (const auto rate: rates) {
			names.push_back(std::to_wstring(rate) + L" Гц");
		}
		AddChoice(
		    games, explanation, L"Частота обновления PS5", std::move(names), static_cast<size_t>(std::find(rates.begin(), rates.end(), current) - rates.begin()),
		    [state, save, rates](size_t index) {
			    state->settings.vblank_frequency = rates[index];
			    save();
		    },
		    IsXbox() ? Paragraphs {L"Частота обновления, о которой консоль сообщает играм. Большинство игр рассчитано на 60 Гц.",
		                           L"При 120 Гц игры с режимом 120 Гц переключаются на него, но Xbox в режиме разработчика показывает не больше 60 кадров в секунду, какой бы режим ни был выбран на ТВ."}
		             : Paragraphs {L"Частота обновления, о которой консоль сообщает играм. Большинство игр рассчитано на 60 Гц.",
		                           L"При 120 Гц игры с режимом 120 Гц могут работать до 120 кадров в секунду на дисплее, который поддерживает 120 Гц.",
		                           L"Более низкая частота ограничивает игры этой частотой кадров."});
	}
	AddSwitch(
	    games, explanation, L"Режим PS5 Pro", settings.pro_mode,
	    [state, save](bool on) {
		    state->settings.pro_mode = on;
		    save();
	    },
	    {L"Игры с поддержкой PS5 Pro используют свои настройки графики Pro. Функция экспериментальная, в некоторых играх память может закончиться быстрее."});
	heading(picture, L"Масштабирование");
	if (IsXbox()) {
		std::vector<std::wstring> names {L"Как у ТВ", L"1080p"};
		AddChoice(
		    picture, explanation, L"Выходное разрешение", std::move(names), settings.output_resolution == "1080p" ? 1 : 0,
		    [state, save](size_t index) {
			    state->settings.output_resolution = index == 1 ? "1080p" : "Match TV";
			    save();
		    },
		    {L"«Как у ТВ» сохраняет чёткость 4K-игр на 4K-телевизоре. 1080p расходует меньше памяти, а консоль сама масштабирует картинку под ваш ТВ."});
	}
#ifdef KYTY_HAS_FSR
	{
		// Upstream's --pssr-upscaler. DLSS is NVIDIA's and Vulkan's, so the Xbox has Linear and FSR (built in).
		std::vector<std::wstring> names {L"Линейное", L"FSR"};
		AddChoice(
		    picture, explanation, L"Апскейлер PSSR", std::move(names), settings.pssr_upscaler == "FSR" ? 1 : 0,
		    [state, save](size_t index) {
			    state->settings.pssr_upscaler = index == 1 ? "FSR" : "Linear";
			    save();
		    },
		    {L"Некоторые игры PS5 Pro масштабируют картинку с помощью PSSR — апскейлера Sony. FSR эмулирует PSSR апскейлером AMD и даёт более чёткую картинку. «Линейное» — простое масштабирование."});
	}
#endif
	{
		const std::vector<std::string> values {"Off", "Low", "Medium", "High"};
		std::vector<std::wstring>      names {L"Выкл.", L"Резкость: низкая", L"Резкость: средняя", L"Резкость: высокая"};
		const auto                     found = std::find(values.begin(), values.end(), settings.fsr1_upscaling);
		AddChoice(
		    picture, explanation, L"FSR 1", std::move(names), found != values.end() ? static_cast<size_t>(found - values.begin()) : 0,
		    [state, save, values](size_t index) {
			    state->settings.fsr1_upscaling = values[index < values.size() ? index : 0];
			    save();
		    },
		    {L"Повышает резкость и масштабирует игры, которые рендерятся в разрешении ниже выходного. Функция экспериментальная и не работает с HDR."});
	}
#ifdef KYTY_HAS_FSR
	constexpr bool frame_generation = true;
#else
	constexpr bool frame_generation = false;
#endif
	if (!IsXbox() || frame_generation) {
		heading(picture, L"Частота кадров");
	}
	// V-Sync is the PC's: on the Xbox the games' clock keeps the TV's pace (EmulatorHost::Start), and frames are shown as soon as they're ready.
	if (!IsXbox()) {
		AddSwitch(
		    picture, explanation, L"V-Sync", settings.vsync,
		    [state, save](bool on) {
			    state->settings.vsync = on;
			    save();
		    },
		    {L"Синхронизирует каждый кадр с частотой обновления экрана для плавного движения ценой чуть большей задержки ввода.",
		     L"Когда выключено, кадры показываются сразу, как только готовы, с меньшей задержкой."});
	}
#ifdef KYTY_HAS_FSR
	AddSwitch(
	    picture, explanation, L"Генерация кадров FSR", settings.fsr_frame_generation,
	    [state, save](bool on) {
		    state->settings.fsr_frame_generation = on;
		    save();
	    },
	    {L"Добавляет сгенерированный кадр между кадрами игры для более плавного движения. Работает только с играми PS5 Pro, которые используют PSSR и идут на половине частоты обновления экрана, например 30 кадр/с при 60 Гц. Функция экспериментальная."});
#endif
	// Overlay: the same tiles as in the game menu's Overlay, in two groups.
	AddHeading(panel(L"OverlayGroup"), L"Оверлей");
	AddHeading(panel(L"OnScreenGroup"), L"Также на экране");
	AddOverlaySettings(panel(L"OverlayGroup"), panel(L"OnScreenGroup"), explanation, std::shared_ptr<AppSettings>(state, &state->settings), save);

	// Controller: its pages as entries. Players and DSU servers are the same as in the game menu's Controllers.
	auto       main_view    = page.FindName(L"Main").as<xaml::UIElement>();
	auto       page_title   = page.FindName(L"PageTitle").as<xaml::UIElement>();
	auto       detail       = page.FindName(L"Detail").as<xaml::UIElement>();
	auto       detail_title = page.FindName(L"DetailTitle").as<xaml::Controls::TextBlock>();
	auto       columns      = page.FindName(L"DetailColumns").as<xaml::Controls::StackPanel>();
	auto       detail_text  = page.FindName(L"DetailExplanation").as<xaml::Controls::StackPanel>();
	const auto hints        = page.FindName(L"Hints").as<xaml::Controls::Border>();
	// Shows a page; set below, as the pages open each other.
	auto show_page = std::make_shared<std::function<void(ControllerPage)>>();
	const auto open_page = [state, weak_show = std::weak_ptr(show_page)](ControllerPage which) {
		if (const auto show = weak_show.lock()) {
			state->pages.push_back(which);
			(*show)(which);
		}
	};
	const auto entries = panel(L"Controller");
	// The entries have no text, as the Xbox's: their names say where they go (the focus on one clears the text column).
	const auto add_entry = [&entries, &explanation](xaml::Controls::Button const& entry) {
		Explain(entry, explanation, {});
		entries.Children().Append(entry);
	};
	// In Segoe MDL2 Assets: People, Wifi (as the DSU controllers' symbol in the lists), Volume, Game.
	constexpr wchar_t PEOPLE_SYMBOL[] = {0xE716, 0};
	constexpr wchar_t WIFI_SYMBOL[]   = {0xE701, 0};
	constexpr wchar_t VOLUME_SYMBOL[] = {0xE767, 0};
	constexpr wchar_t GAME_SYMBOL[]   = {0xE7FC, 0};
	constexpr wchar_t ROTATE_SYMBOL[] = {0xE7AD, 0};
	const auto        players_entry   = MakeEntry(PEOPLE_SYMBOL, L"Игроки", [open_page] { open_page(ControllerPage::Players); });
	const auto        servers_entry   = MakeEntry(WIFI_SYMBOL, L"Удалённые контроллеры", [open_page] { open_page(ControllerPage::Servers); });
	const auto        feedback_entry  = MakeEntry(VOLUME_SYMBOL, L"Отклик и звук", [open_page] { open_page(ControllerPage::Feedback); });
	const auto        motion_entry    = MakeEntry(ROTATE_SYMBOL, L"Датчики движения", [open_page] { open_page(ControllerPage::Motion); });
	// The controls page, and back here with the focus on its entry.
	auto layout_entry = MakeEntry(GAME_SYMBOL, L"Раскладка кнопок", [] {});
	layout_entry.Click([state, weak_page = winrt::make_weak(page)](winrt::Windows::Foundation::IInspectable const& sender, auto const&) {
		auto shown = weak_page.get();
		if (shown == nullptr) {
			return;
		}
		state->return_focus = winrt::make_weak(sender.as<xaml::Controls::Control>());
		xaml::Window::Current().Content(CreateControlsPage([shown] { xaml::Window::Current().Content(shown); }, L"Контроллер"));
	});
	for (const auto& entry: {players_entry, servers_entry, feedback_entry, motion_entry, layout_entry}) {
		add_entry(entry);
	}
	// Remote Controllers (the DSU servers) shows only with Developer › Remote Controllers on; the others close up, two in a row.
	const auto place_entries = [players_entry, servers_entry, feedback_entry, motion_entry, layout_entry](bool dsu) {
		servers_entry.Visibility(dsu ? xaml::Visibility::Visible : xaml::Visibility::Collapsed);
		std::vector<xaml::Controls::Button> shown = {players_entry};
		if (dsu) {
			shown.push_back(servers_entry);
		}
		shown.push_back(feedback_entry);
		shown.push_back(motion_entry);
		shown.push_back(layout_entry);
		for (size_t index = 0; index < shown.size(); index++) {
			xaml::Controls::Grid::SetRow(shown[index], static_cast<int>(index / 2));
			xaml::Controls::Grid::SetColumn(shown[index], static_cast<int>(index % 2));
		}
	};
	place_entries(settings.dsu_enabled);

	*show_page = [state, save, main_view, page_title, detail, detail_title, columns, detail_text, hints, open_page](ControllerPage which) {
		columns.Children().Clear();
		detail_text.Children().Clear();
		SetHints(hints, {{XboxButton::A, L"Выбрать"}, {XboxButton::B, L"Назад"}});
		main_view.Visibility(xaml::Visibility::Collapsed);
		page_title.Visibility(xaml::Visibility::Collapsed);
		detail.Visibility(xaml::Visibility::Visible);
		SetPageTitle(detail_title, L"Контроллер",
		             which == ControllerPage::Players   ? L"Игроки"
		             : which == ControllerPage::Servers ? L"Удалённые контроллеры"
		             : which == ControllerPage::Motion  ? L"Датчики движения"
		                                                : L"Отклик и звук");

		const auto settings = std::shared_ptr<AppSettings>(state, &state->settings);
		if (which == ControllerPage::Players) {
			AddPlayersColumns(columns, detail_text, hints, settings, save, [open_page] { open_page(ControllerPage::Servers); });
		} else if (which == ControllerPage::Servers) {
			AddServerColumns(columns, settings, save);
		} else if (which == ControllerPage::Motion) {
			const auto stick = AddColumn(columns, L"Правый стик");
			AddChoice(
			    stick, detail_text, L"Правый стик вверх", std::vector<std::wstring> {L"Наклон назад", L"Наклон вперёд"},
			    state->settings.motion_stick_up_forward ? 1 : 0,
			    [state, save](size_t index) {
				    state->settings.motion_stick_up_forward = index == 1;
				    save();
			    },
			    {L"Пока удерживается View, правый стик управляет датчиками движения — как будто вы наклоняете DualSense.",
			     L"«Назад» подходит играм, где прицел идёт вверх при наклоне контроллера на себя. «Вперёд» подходит играм, где управляют наклоном, например катят шар. Применяется при запуске игры."});
		} else {
			const auto vibration = AddColumn(columns, L"Вибрация");
			const auto audio     = AddColumn(columns, L"Динамик и микрофон");
			AddChoice(
			    vibration, detail_text, L"Сила вибрации", Percentages(), std::min<size_t>((state->settings.controller_vibration + 5) / 10, 10),
			    [state, save](size_t index) {
				    state->settings.controller_vibration = static_cast<uint32_t>(index * 10);
				    save();
			    },
			    {L"Определяет, насколько сильно вибрирует контроллер, включая тактильный отклик, воспроизводимый как вибрация.",
			     L"При 0% контроллер не вибрирует. Impulse Triggers это не затрагивает."});
			AddSwitch(
			    vibration, detail_text, L"Тактильный отклик как лёгкая вибрация", state->settings.haptic_rumble,
			    [state, save](bool on) {
				    state->settings.haptic_rumble = on;
				    save();
			    },
			    {L"Воспроизводит тактильный отклик DualSense как лёгкую вибрацию.",
			     L"Короткие эффекты, например шаги или удары, дают мягкий толчок. Продолжительные эффекты, например дождь или двигатель, дают толчок только при старте.",
			     L"Звук игры не меняется."});
			AddSwitch(
			    vibration, detail_text, L"Impulse Triggers", state->settings.impulse_triggers,
			    [state, save](bool on) {
				    state->settings.impulse_triggers = on;
				    save();
			    },
			    {L"Воспроизводит эффекты адаптивных триггеров DualSense как вибрацию в триггерах контроллера Xbox.",
			     L"Триггер, который сопротивлялся бы или вибрировал, мягко вибрирует, пока вы его нажимаете. Триггер, который бы поддавался, вибрирует один раз.",
			     L"Если нажать триггер до упора, он перестаёт вибрировать."});
			AddSwitch(
			    audio, detail_text, L"Динамик на гарнитуре", state->settings.headset_speaker,
			    [state, save](bool on) {
				    state->settings.headset_speaker = on;
				    save();
			    },
			    // The Xbox doesn't report a controller's headset (input.h): there it is always the chat headset.
			    {IsXbox() ? L"Воспроизводит звук, предназначенный для динамика DualSense игрока 1, на вашей гарнитуре для чата, например подключённой к контроллеру."
			              : L"Воспроизводит звук, предназначенный для динамика DualSense игрока 1, на гарнитуре, подключённой к контроллеру игрока 1, а если её нет — на устройстве связи Windows.",
			     L"Без гарнитуры он воспроизводится вместе с остальным звуком игры."});
			AddChoice(
			    audio, detail_text, L"Громкость динамика", Percentages(), std::min<size_t>((state->settings.controller_speaker_volume + 5) / 10, 10),
			    [state, save](size_t index) {
				    state->settings.controller_speaker_volume = static_cast<uint32_t>(index * 10);
				    save();
			    },
			    {L"Задаёт громкость звука, предназначенного для динамика DualSense.", L"При 50% звук воспроизводится с собственной громкостью игры. 100% громче на 6 дБ."});
			AddSwitch(
			    audio, detail_text, L"Микрофон гарнитуры", state->settings.headset_mic,
			    [state, save](bool on) {
				    state->settings.headset_mic = on;
				    save();
				    if (on) {
					    RequestMicrophoneAccess();
				    }
			    },
			    {IsXbox() ? L"Позволяет играм использовать микрофон вашей гарнитуры для чата как микрофон DualSense игрока 1, например чтобы дуть в него."
			              : L"Позволяет играм использовать микрофон гарнитуры, подключённой к контроллеру игрока 1, а если её нет — микрофон связи Windows, как микрофон DualSense игрока 1.",
			     L"Когда это выключено, игры не находят микрофон.",
			     IsXbox() ? L"При первом использовании будет запрошено разрешение на доступ KytyPS5 к микрофону. Если вы откажете, разрешить его можно позже в настройках конфиденциальности."
			              : L"При первом использовании будет запрошено разрешение на доступ KytyPS5 к микрофону. Если вы откажете, разрешить его можно позже в настройках конфиденциальности Windows."});
		}
		columns.UpdateLayout();
		FocusFirst(columns);
	};
	// Back from a page: to the page under it (the focus on the tile that opened this one), or to the categories' entries.
	const auto close_page = [state, show_page, main_view, page_title, detail, columns, detail_text, players_entry, servers_entry, feedback_entry,
	                         motion_entry] {
		const auto closed = state->pages.back();
		state->pages.pop_back();
		if (!state->pages.empty()) {
			(*show_page)(state->pages.back());
			FocusFirst(columns, L"servers");
			return;
		}
		columns.Children().Clear();
		detail_text.Children().Clear();
		detail.Visibility(xaml::Visibility::Collapsed);
		main_view.Visibility(xaml::Visibility::Visible);
		page_title.Visibility(xaml::Visibility::Visible);
		main_view.UpdateLayout();
		(closed == ControllerPage::Players   ? players_entry
		 : closed == ControllerPage::Servers ? servers_entry
		 : closed == ControllerPage::Motion  ? motion_entry
		                                     : feedback_entry)
		    .Focus(xaml::FocusState::Keyboard);
	};

	auto user_name = page.FindName(L"UserName").as<xaml::Controls::TextBox>();
	user_name.Text(winrt::to_hstring(settings.user_name));
	// The games take up to 16 bytes of UTF-8 (a longer or empty name keeps the default, Kyty): the box takes no more, so that letters outside
	// ASCII, which take 2 to 4 bytes, can't make the name silently fall back.
	user_name.BeforeTextChanging([](auto const&, xaml::Controls::TextBoxBeforeTextChangingEventArgs const& args) {
		if (winrt::to_string(args.NewText()).size() > 16) {
			args.Cancel(true);
		}
	});
	user_name.TextChanged([state, save](winrt::Windows::Foundation::IInspectable const& sender, auto const&) {
		state->settings.user_name = winrt::to_string(sender.as<xaml::Controls::TextBox>().Text());
		save();
	});
	Explain(user_name, explanation,
	        {L"Имя, которое игры показывают для игрока 1.", L"Игроки со 2-го по 4-й называются «Игрок 2», «Игрок 3» и «Игрок 4».",
	         L"Помещается 16 букв. Буквы с диакритикой и нелатинские занимают больше места. Пустое имя отображается как Kyty."});

	{
		std::vector<std::wstring> languages(CONSOLE_LANGUAGES.begin(), CONSOLE_LANGUAGES.end());
		AddChoice(
		    panel(L"System"), explanation, L"Язык консоли", std::move(languages),
		    std::min<size_t>(settings.console_language, CONSOLE_LANGUAGES.size() - 1),
		    [state, save](size_t index) {
			    state->settings.console_language = static_cast<uint32_t>(index);
			    save();
		    },
		    {L"Системный язык, который игры используют для текста и речи, если игра его поддерживает.", L"Названия трофеев тоже следуют ему."});
	}
	AddChoice(
	    panel(L"System"), explanation, L"Аудиовыход", {L"TV", L"AV-ресивер", L"Саундбар", L"Наушники"},
	    std::min<size_t>(settings.audio_output, 3),
	    [state, save](size_t index) {
		    state->settings.audio_output = static_cast<uint32_t>(index);
		    save();
	    },
	    {L"Аудиоустройство, которое видят игры: ТВ, AV-ресивер (7.1), саундбар (5.1) или наушники."});
	AddSwitch(
	    panel(L"System"), explanation, L"3D-звук", settings.audio_3d,
	    [state, save](bool on) {
		    state->settings.audio_3d = on;
		    save();
	    },
	    {L"Позволяет играм с поддержкой 3D-звука PS5 располагать звуки вокруг вас.",
	     L"Если аудиовыход — «Наушники», используется виртуальный объёмный звук (HRTF)."});
	AddSwitch(
	    panel(L"System"), explanation, L"Пропускать вступительные логотипы", settings.skip_intro_logos,
	    [state, save](bool on) {
		    state->settings.skip_intro_logos = on;
		    save();
	    },
	    {L"Пропускает видео с логотипами при запуске игры, если игра это поддерживает.", L"Остальные игры показывают вступительные логотипы как обычно."});
	AddSwitch(
	    panel(L"System"), explanation, L"Музыка главного экрана", settings.home_screen_music,
	    [state, save](bool on) {
		    state->settings.home_screen_music = on;
		    save();
	    },
	    {L"Проигрывает музыку игры в библиотеке, пока её обложка в фокусе, если у игры она есть."});
	AddSwitch(
	    panel(L"System"), explanation, L"Уведомления о трофеях", settings.trophy_notifications,
	    [state, save](bool on) {
		    state->settings.trophy_notifications = on;
		    save();
	    },
	    {L"Показывает уведомление, когда вы получаете трофей.", L"Когда выключено, трофеи всё равно получаются и сохраняются."});
	AddSwitch(
	    panel(L"System"), explanation, L"Сетевое подключение", settings.network_connected,
	    [state, save](bool on) {
		    state->settings.network_connected = on;
		    save();
	    },
	    {IsXbox() ? L"Позволяет играм использовать локальное сетевое подключение консоли." : L"Позволяет играм использовать локальное сетевое подключение вашего компьютера.",
	     L"Когда выключено, играм сообщается, что сети нет."});
	AddSwitch(
	    panel(L"System"), explanation, L"Эмулировать вход в PSN", settings.emulate_psn,
	    [state, save](bool on) {
		    state->settings.emulate_psn = on;
		    save();
	    },
	    {L"Сообщает играм, что вы вошли в PSN, для игр, которым это нужно."});
	AddSwitch(
	    panel(L"System"), explanation, L"Закрывать диалоги игры автоматически", settings.dialog_auto_close,
	    [state, save](bool on) {
		    state->settings.dialog_auto_close = on;
		    save();
	    },
	    {L"Сообщение игры, например ошибка или вход в PSN, само нажимает свою кнопку через 5 секунд."});

	// Memory and quality. Game memory paging: Automatic is "not set" (on where the app's memory limit is small), the others are the cap in MB.
	const auto memory   = panel(L"MemoryGroup");
	const auto textures = panel(L"TextureGroup");
	AddHeading(memory, L"Память");
	AddHeading(textures, L"Текстуры");
	{
		std::vector<std::pair<uint32_t, std::wstring>> choices = {{0xFFFFFFFFu, L"Автоматически"},         {0, L"Выкл.: вся память игры остаётся в ОЗУ"},
		                                                          {1500, L"До 1500 МБ в ОЗУ"},  {2000, L"До 2000 МБ в ОЗУ"},
		                                                          {3000, L"До 3000 МБ в ОЗУ"},  {4000, L"До 4000 МБ в ОЗУ"},
		                                                          {5120, L"До 5120 МБ в ОЗУ"}};
		if (std::none_of(choices.begin(), choices.end(), [&](const auto& choice) { return choice.first == settings.guest_ram_budget_mb; })) {
			choices.emplace_back(settings.guest_ram_budget_mb, L"До " + std::to_wstring(settings.guest_ram_budget_mb) + L" МБ в ОЗУ, из файла настроек");
		}
		std::vector<std::wstring> names;
		size_t                    selected = choices.size();
		for (size_t index = 0; index < choices.size(); index++) {
			names.push_back(choices[index].second);
			if (choices[index].first == settings.guest_ram_budget_mb) {
				selected = index;
			}
		}
		AddChoice(
		    memory, explanation, L"Подкачка памяти игры", std::move(names), selected,
		    [state, choices, save](size_t index) {
			    state->settings.guest_ram_budget_mb = choices[index].first;
			    save();
		    },
		    {L"Когда память игры превышает лимит, части, которые игра давно не использовала, переносятся в файл подкачки. Они загружаются обратно, когда игре снова понадобятся.",
		     IsXbox() ? L"«Автоматически» включает её с лимитом, подходящим под память консоли. Варианты в МБ задают лимит памяти игры. Он ниже, пока место нужно GPU."
		              : L"«Автоматически» включает её, когда приложению доступно 8 ГБ или меньше, как на Xbox. Варианты в МБ задают лимит памяти игры. Он ниже, пока место нужно GPU.",
		     L"Если выключить, игры, которым нужно больше памяти, чем есть, могут вылетать."});
	}
	AddChoice(
	    textures, explanation, L"Детализация текстур", {L"Полная", L"Половинное разрешение", L"Четверть разрешения", L"Одна восьмая разрешения", L"Одна шестнадцатая разрешения"},
	    std::min<uint32_t>(settings.texture_mip_skip, 4),
	    [state, save](size_t index) {
		    state->settings.texture_mip_skip = static_cast<uint32_t>(index);
		    save();
	    },
	    {L"Большие сжатые текстуры с мипмапами загружаются в пониженном разрешении, чтобы сэкономить память GPU.",
	     L"Поверхности вблизи выглядят более размытыми. Дальние остаются прежними."});
	{
		constexpr std::array<uint32_t, 5> TEXTURE_SIZES = {256, 512, 1024, 2048, 4096};
		std::vector<std::wstring>         names;
		size_t                            selected = 3;
		for (size_t index = 0; index < TEXTURE_SIZES.size(); index++) {
			names.push_back(std::to_wstring(TEXTURE_SIZES[index]) + L" пикс.");
			if (TEXTURE_SIZES[index] == settings.texture_mip_skip_min_size) {
				selected = index;
			}
		}
		AddChoice(
		    textures, explanation, L"Текстуры считаются большими от", std::move(names), selected,
		    [state, TEXTURE_SIZES, save](size_t index) {
			    state->settings.texture_mip_skip_min_size = TEXTURE_SIZES[index];
			    save();
		    },
		    {L"Разрешение снижается только у текстур не меньше этого размера. Размер — по длинной стороне, в пикселях.",
		     L"Маленькие текстуры сохраняют полное разрешение."});
	}
	AddSwitch(
	    textures, explanation, L"Уменьшать и несжатые текстуры", settings.texture_mip_skip_uncompressed,
	    [state, save](bool on) {
		    state->settings.texture_mip_skip_uncompressed = on;
		    save();
	    },
	    {L"Несжатые текстуры с мипмапами тоже получают пониженное разрешение.", L"Экономит больше памяти, но часть текста и изображений в меню может стать размытой."});
	AddChoice(
	    textures, explanation, L"Резкость текстур", {L"Полная", L"На один уровень мягче", L"На два уровня мягче", L"На три уровня мягче", L"На четыре уровня мягче"},
	    std::min<uint32_t>(settings.texture_lod_bias, 4),
	    [state, save](size_t index) {
		    state->settings.texture_lod_bias = static_cast<uint32_t>(index);
		    save();
	    },
	    {L"Текстуры рисуются из их уменьшенных версий. Память это не экономит.", L"Может быть немного быстрее, когда упор в GPU, но картинка размытее."});
	AddSwitch(
	    textures, explanation, L"Анизотропная фильтрация", settings.anisotropic_filtering,
	    [state, save](bool on) {
		    state->settings.anisotropic_filtering = on;
		    save();
	    },
	    {L"Сохраняет резкость текстур на поверхностях, видимых под углом, где этого требует игра.", L"При «Выкл.» используется обычная фильтрация. Это может быть чуть быстрее."});
	AddSwitch(
	    textures, explanation, L"Точная синхронизация текстур", settings.accurate_texture_sync,
	    [state, save](bool on) {
		    state->settings.accurate_texture_sync = on;
		    save();
	    },
	    {L"Может исправить пропавшие текстуры и неправильную прозрачность в некоторых играх.", L"Может снизить производительность."});
	AddSwitch(
	    textures, explanation, L"Считывать линейные изображения", settings.readback_linear_images,
	    [state, save](bool on) {
		    state->settings.readback_linear_images = on;
		    save();
	    },
	    {L"Копирует изображения, которые GPU пишет без тайлинга, обратно в память игры после каждой отправки — для игр, которые их читают.",
	     L"Замедляет игры."});
	AddSwitch(
	    textures, explanation, L"Считывать малые тайловые изображения", settings.readback_tiled_images,
	    [state, save](bool on) {
		    state->settings.readback_tiled_images = on;
		    save();
	    },
	    {L"Копирует небольшие изображения, которые GPU пишет в тайловой раскладке, обратно в память игры после каждой отправки. Некоторые игры читают из них результаты GPU, например для физики воды.",
	     L"Может замедлить игры."});
	AddSwitch(
	    textures, explanation, L"Считывать storage-изображения", settings.readback_storage_images,
	    [state, save](bool on) {
		    state->settings.readback_storage_images = on;
		    save();
	    },
	    {L"Копирует изображения, в которые пишут шейдеры, обратно в память игры, когда игра запрашивает у GPU результаты. Изображения двух переключателей выше при этом тоже копируются.",
	     L"Может замедлить игры."});
	AddSwitch(
	    textures, explanation, L"Статистика мипмапов", settings.lod_stats,
	    [state, save](bool on) {
		    state->settings.lod_stats = on;
		    save();
	    },
	    {L"Передаёт в статистику мипмапов GPU текстуры, которые игра привязывает, — игры могут её читать."});
	{
		std::vector<std::pair<uint32_t, std::wstring>> choices = {{0, L"Выкл."}, {128, L"128 МБ"}, {256, L"256 МБ"}, {512, L"512 МБ"}, {768, L"768 МБ"}, {1024, L"1024 МБ"}};
		if (std::none_of(choices.begin(), choices.end(), [&](const auto& choice) { return choice.first == settings.swap_pool_mb; })) {
			choices.emplace_back(settings.swap_pool_mb, std::to_wstring(settings.swap_pool_mb) + L" МБ, из файла настроек");
		}
		std::vector<std::wstring> names;
		size_t                    selected = choices.size();
		for (size_t index = 0; index < choices.size(); index++) {
			names.push_back(choices[index].second);
			if (choices[index].first == settings.swap_pool_mb) {
				selected = index;
			}
		}
		AddChoice(
		    memory, explanation, L"Сжатый пул подкачки", std::move(names), selected,
		    [state, choices, save](size_t index) {
			    state->settings.swap_pool_mb = choices[index].first;
			    save();
		    },
		    {L"Хранит недавно выгруженную память игры в сжатом виде в ОЗУ, чтобы она возвращалась быстрее, чем из файла подкачки.",
		     L"Больший пул вмещает больше, но оставляет игре меньше ОЗУ. Вступает в силу при следующем запуске игры."});
	}
	AddSwitch(
	    memory, explanation, L"Компактное выделение памяти GPU", settings.gpu_memory_savings,
	    [state, save](bool on) {
		    state->settings.gpu_memory_savings = on;
		    save();
	    },
	    {L"Использует меньшие блоки памяти GPU и создаёт некоторые буферы только при необходимости.",
	     L"В тесте сэкономило около 300 МБ без заметной разницы.",
	     IsXbox() ? L"Если выключить, игры могут вылетать при нехватке памяти." : L"Если выключить, игры на Xbox могут вылетать при нехватке памяти."});

	// Storage: game folders, and the data folder. Where the Xbox's Development Files can be read (the system's folder picker doesn't show it),
	// Add folder opens a menu: the picker (File Explorer, as the Xbox shows it) or a panel with Development Files' folders. Choose folder always
	// does, as it also goes back to the default folder.
	ListFolders(state);
	const bool development_files = IsXbox() && DevelopmentFilesReadable();
	// Saves need writing, which the Xbox may not allow there.
	const bool development_files_writable = development_files && DevelopmentFilesWritable();
	const auto picker_name       = IsXbox() ? L"Проводник" : L"Обзор";
	const auto menu = [](std::vector<std::pair<std::wstring, std::function<void()>>> items) {
		xaml::Controls::MenuFlyout flyout;
		flyout.Placement(xaml::Controls::Primitives::FlyoutPlacementMode::BottomEdgeAlignedLeft);
		for (auto& [text, chosen]: items) {
			xaml::Controls::MenuFlyoutItem item;
			item.Text(text);
			item.Click([chosen = std::move(chosen)](auto const&, auto const&) { chosen(); });
			flyout.Items().Append(item);
		}
		return flyout;
	};
	// The Development Files panel over the page; the focus returns to `button` when it goes.
	const auto show_panel = [state, weak_page = winrt::make_weak(page)](winrt::weak_ref<xaml::Controls::Control> const& button, std::wstring caption,
	                                                                    bool count_games, std::function<void(const std::filesystem::path&)> chosen) {
		const auto shown = weak_page.get();
		if (shown == nullptr) {
			return;
		}
		state->folder_back = ShowDevelopmentFilesPanel(shown, {std::move(caption), count_games, std::move(chosen), [button] {
			                                                       if (const auto control = button.get()) {
				                                                       control.Focus(xaml::FocusState::Keyboard);
			                                                       }
		                                                       }});
	};

	auto add_folder      = page.FindName(L"AddFolder").as<xaml::Controls::Button>();
	auto add_folder_menu = page.FindName(L"AddFolderMenu").as<xaml::Controls::DropDownButton>();
	add_folder.Click([state](auto const&, auto const&) { AddFolder(state); });
	if (development_files) {
		add_folder.Visibility(xaml::Visibility::Collapsed);
		add_folder_menu.Visibility(xaml::Visibility::Visible);
		const auto button = winrt::make_weak(add_folder_menu.as<xaml::Controls::Control>());
		add_folder_menu.Flyout(menu({{picker_name, [state] { AddFolder(state); }},
		                             {L"Development Files", [show_panel, state, button] {
			                              show_panel(button, L"Добавить папку", true, [state](const std::filesystem::path& folder) { AddGameFolder(state, folder); });
		                              }}}));
	}
	Paragraphs game_folders_help = {
	    L"KytyPS5 ищет игры в собственной папке Games и в перечисленных здесь папках на глубину до двух уровней.",
	    L"Игра — это папка с eboot.bin или архив .zar с eboot.bin в корне.",
	    L"Каждая папка должна разрешать приложениям чтение. Если не разрешает, библиотека покажет, как это сделать."};
	if (development_files) {
		game_folders_help.emplace_back(L"Development Files — папка, в которую копирует файлы File explorer в Device Portal.");
	}
	Explain(add_folder, explanation, game_folders_help);
	Explain(add_folder_menu, explanation, game_folders_help);

	state->user_data_path   = page.FindName(L"UserDataPath").as<xaml::Controls::TextBlock>();
	state->user_data_status = page.FindName(L"UserDataStatus").as<xaml::Controls::TextBlock>();
	ShowUserData(state);
	auto choose_user_data = page.FindName(L"ChooseUserData").as<xaml::Controls::DropDownButton>();
	// From the picker or the panel; empty: the default folder.
	const auto set_user_data = [state](const std::filesystem::path& folder) {
		state->settings.user_data_path = folder;
		SaveSettings(state->settings);
		ShowUserData(state);
	};
	std::vector<std::pair<std::wstring, std::function<void()>>> data_choices = {{picker_name, [set_user_data] { PickFolder(set_user_data); }}};
	if (development_files_writable) {
		const auto button = winrt::make_weak(choose_user_data.as<xaml::Controls::Control>());
		data_choices.emplace_back(L"Development Files", [show_panel, set_user_data, button] { show_panel(button, L"Папка данных", false, set_user_data); });
	}
	data_choices.emplace_back(DefaultDataFolderName(), [set_user_data] { set_user_data({}); });
	choose_user_data.Flyout(menu(std::move(data_choices)));
	const Paragraphs data_folder_help = {
	    L"Папка для сохранений, патчей и трофеев, например на USB-диске. KytyPS5 хранит их в подпапках _SaveData, _Patches и _Trophies.",
	    L"Сохранения, патчи и трофеи в старой папке не переносятся. Чтобы сохранить их, скопируйте эти подпапки в новую папку самостоятельно.",
	    std::wstring(L"Если при запуске игры в папку нельзя писать, например когда диск не подключён, эта игра использует ") +
	        (IsXbox() ? L"внутреннюю память." : L"папку по умолчанию.")};
	Explain(choose_user_data, explanation, data_folder_help);

	// The shader cache, written as the user's data: the same choices as the data folder.
	state->shader_cache_path   = page.FindName(L"ShaderCachePath").as<xaml::Controls::TextBlock>();
	state->shader_cache_status = page.FindName(L"ShaderCacheStatus").as<xaml::Controls::TextBlock>();
	ShowShaderCache(state);
	auto choose_shader_cache = page.FindName(L"ChooseShaderCache").as<xaml::Controls::DropDownButton>();
	// From the picker or the panel; empty: the default folder. The compiled shaders of the old folder stay there.
	const auto set_shader_cache = [state](const std::filesystem::path& folder) {
		state->settings.shader_cache_path = folder;
		SaveSettings(state->settings);
		ShowShaderCache(state);
	};
	std::vector<std::pair<std::wstring, std::function<void()>>> cache_choices = {{picker_name, [set_shader_cache] { PickFolder(set_shader_cache); }}};
	if (development_files_writable) {
		const auto button = winrt::make_weak(choose_shader_cache.as<xaml::Controls::Control>());
		cache_choices.emplace_back(L"Development Files", [show_panel, set_shader_cache, button] { show_panel(button, L"Кэш шейдеров", false, set_shader_cache); });
	}
	cache_choices.emplace_back(DefaultDataFolderName(), [set_shader_cache] { set_shader_cache({}); });
	choose_shader_cache.Flyout(menu(std::move(cache_choices)));
	Explain(choose_shader_cache, explanation,
	        {L"Папка для скомпилированных шейдеров и пайплайнов игр. KytyPS5 хранит их в подпапке _PipelineCache.",
	         L"Скомпилированные шейдеры в старой папке остаются там. Игры соберут свои заново в новой папке.",
	         std::wstring(L"Если при запуске игры в папку нельзя писать, эта игра использует ") +
	             (IsXbox() ? L"внутреннюю память." : L"папку по умолчанию.")});

	// Logs and dumps, written with the C library, which reaches only folders that grant apps access themselves: on a PC, the picker's choice
	// (the row says when it needs that access); on the Xbox, Development Files, as the picker there only reaches USB drives, which it can't.
	const bool logs_in_development_files = development_files && DevelopmentFilesDirectlyWritable();
	if (!IsXbox() || logs_in_development_files || !settings.logs_path.empty()) {
		page.FindName(L"Logs").as<xaml::UIElement>().Visibility(xaml::Visibility::Visible);
		state->logs_path   = page.FindName(L"LogsPath").as<xaml::Controls::TextBlock>();
		state->logs_status = page.FindName(L"LogsStatus").as<xaml::Controls::TextBlock>();
		ShowLogs(state);
		auto choose_logs = page.FindName(L"ChooseLogs").as<xaml::Controls::DropDownButton>();
		// From the picker or the panel; empty: the default folder.
		const auto set_logs = [state](const std::filesystem::path& folder) {
			state->settings.logs_path = folder;
			SaveSettings(state->settings);
			ShowLogs(state);
		};
		std::vector<std::pair<std::wstring, std::function<void()>>> logs_choices;
		if (!IsXbox()) {
			logs_choices.emplace_back(picker_name, [set_logs] { PickFolder(set_logs); });
		}
		if (logs_in_development_files) {
			const auto button = winrt::make_weak(choose_logs.as<xaml::Controls::Control>());
			logs_choices.emplace_back(L"Development Files", [show_panel, set_logs, button] { show_panel(button, L"Журналы и дампы", false, set_logs); });
		}
		logs_choices.emplace_back(DefaultDataFolderName(), [set_logs] { set_logs({}); });
		choose_logs.Flyout(menu(std::move(logs_choices)));
		Explain(choose_logs, explanation,
		        {IsXbox() ? L"Папка для журналов и дампов кадров. В Development Files их можно открыть с компьютера." : L"Папка для журналов и дампов кадров.",
		         std::wstring(L"Если при запуске игры в папку нельзя писать, эта игра использует ") +
		             (IsXbox() ? L"внутреннюю память." : L"папку по умолчанию.")});
	}

	// A heading above the focused row comes into view with it: scrolled down, the page left "Game folders" cut in half at the top even with
	// the first game folder's Remove in focus.
	page.FindName(L"Storage").as<xaml::UIElement>().BringIntoViewRequested([](auto const&, xaml::BringIntoViewRequestedEventArgs const& args) {
		auto target = args.TargetRect();
		target.Y -= 48;
		target.Height += 48;
		args.TargetRect(target);
	});

	// Developer: what goes to the log, and what helps testing.
	const auto developer = panel(L"DiagnosticsGroup");
	const auto testing   = panel(L"TestingGroup");
	AddHeading(developer, L"Диагностика");
	AddHeading(testing, L"Тестирование");
	AddSwitch(
	    testing, explanation, IsXbox() ? L"Растягивать на экран" : L"Растягивать на окно", settings.stretch,
	    [state, save](bool on) {
		    state->settings.stretch = on;
		    save();
	    },
	    {IsXbox() ? L"Заполняет экран, даже если у картинки игры другие пропорции. Когда выключено, пустое место занимают чёрные полосы."
	              : L"Заполняет окно, даже если у картинки игры другие пропорции. Когда выключено, пустое место занимают чёрные полосы."});
	AddSwitch(
	    developer, explanation, L"Слой отладки графики", settings.debug_layer,
	    [state, save](bool on) {
		    state->settings.debug_layer = on;
		    save();
	    },
	    {L"Записывает ошибки графики в журнал.", L"Замедляет игры.",
	     IsXbox() ? L"Если на консоли его нет, в журнале будет сказано, что слой отладки выключен."
	              : L"Требуется компонент Windows «Graphics Tools». Без него в журнале будет сказано, что слой отладки выключен."});
	AddSwitch(
	    developer, explanation, L"Подробный журнал", settings.game_output,
	    [state, save](bool on) {
		    state->settings.game_output = on;
		    save();
	    },
	    {L"Добавляет в журнал вывод printf игры и трассировку эмулятора. Также показывает предупреждения, которые иначе скрыты.",
	     L"Замедляет игры. Журнал может расти на тысячи строк в секунду."});
	AddSwitch(
	    developer, explanation, L"Подробный отчёт о памяти", settings.gpu_memory_log,
	    [state, save](bool on) {
		    state->settings.gpu_memory_log = on;
		    save();
	    },
	    {L"Каждые 10 секунд записывает в журнал состояние памяти GPU. Пока используется файл подкачки — также файл подкачки и память игры.",
	     L"Каждый отчёт вызывает короткую паузу."});
	AddSwitch(
	    developer, explanation, L"Диагностика сбоев GPU", settings.gpu_crash_diagnostics,
	    [state, save](bool on) {
		    state->settings.gpu_crash_diagnostics = on;
		    save();
	    },
	    {L"Когда GPU зависает или падает, журнал называет шейдеры, которые он выполнял, и сохраняет их.", L"Замедляет игры."});
	AddSwitch(
	    testing, explanation, L"Многопоточное декодирование видео", settings.video_decode_threads,
	    [state, save](bool on) {
		    state->settings.video_decode_threads = on;
		    save();
	    },
	    {L"Декодирует видео, которые игры воспроизводят через системный видеоплеер, на всех ядрах процессора.",
	     L"При «Выкл.» декодирование идёт в одном потоке. Используйте для проверки проблем с видео."});
	AddSwitch(
	    testing, explanation, L"Аппаратное декодирование видео", settings.video_hardware_decode,
	    [state, save](bool on) {
		    state->settings.video_hardware_decode = on;
		    save();
	    },
	    {L"Декодирует видео, которые игры воспроизводят через системный видеоплеер, видеодекодером консоли, чтобы процессор оставался свободным для игры.",
	     L"Видео, которые декодер не принимает, декодируются на процессоре. При «Выкл.» все видео декодируются на процессоре."});
	AddSwitch(
	    testing, explanation, L"Короткие видео", settings.short_videos,
	    [state, save](bool on) {
		    state->settings.short_videos = on;
		    save();
	    },
	    {L"Обрывает видео, воспроизводимые через системный видеоплеер, через одну секунду, чтобы заставки и логотипы проходили быстро.",
	     L"Зацикленные видео воспроизводятся как обычно. Видео, которые игра декодирует сама, проигрываются целиком."});
	AddSwitch(
	    testing, explanation, L"Запасной вариант PlayGo", settings.playgo_fallback,
	    [state, save](bool on) {
		    state->settings.playgo_fallback = on;
		    save();
	    },
	    {L"Выдаёт игре стандартный список установленных частей, если её собственный список не читается.", L"Только для тестирования игр, которым это нужно."});
	AddSwitch(
	    testing, explanation, L"Виртуальный VR-шлем", settings.virtual_vr_headset,
	    [state, save](bool on) {
		    state->settings.virtual_vr_headset = on;
		    save();
	    },
	    {L"Сообщает играм, что VR-шлем подключён и надет.", L"Только для тестирования игр, которым он нужен."});
	AddSwitch(
	    testing, explanation, L"Часы гостя на скорости PS5", settings.guest_tsc,
	    [state, save](bool on) {
		    state->settings.guest_tsc = on;
		    save();
	    },
	    {L"Запускает счётчик меток времени процессора игр на частоте PS5 — 1,6 ГГц.", L"Экспериментально. Для игр, которые идут слишком быстро."});
	AddSwitch(
	    testing, explanation, L"Запросы окклюзии", settings.occlusion_queries,
	    [state, save](bool on) {
		    state->settings.occlusion_queries = on;
		    save();
	    },
	    {L"Считает на GPU то, что игры просят проверить на видимость, чтобы скрытые источники света и объекты оставались скрытыми.",
	     L"Когда выключено, играм сообщается, что видно всё. Включённая функция немного снижает производительность."});
	AddSwitch(
	    testing, explanation, L"Тесселяция", settings.tessellation,
	    [state, save](bool on) {
		    state->settings.tessellation = on;
		    save();
	    },
	    {L"Отрисовывает поверхности, которые игры уточняют на GPU, например воду и ландшафт.", L"Когда выключено, эти поверхности не рисуются."});
	AddSwitch(
	    testing, explanation, L"Упрощённая арифметика float в шейдерах", settings.relaxed_shader_float,
	    [state, save](bool on) {
		    state->settings.relaxed_shader_float = on;
		    save();
	    },
	    {L"Шейдеры используют собственные операции с плавающей запятой GPU.", L"Может быть быстрее, когда упор в GPU, но некоторые эффекты могут выглядеть неправильно.",
	     L"После изменения игры заново компилируют свои шейдеры."});
	AddAction(
	    testing, explanation, L"Отрисовок на одну отправку в GPU", L"",
	    [state, save]() -> winrt::fire_and_forget {
		    const auto settings_state = state;
		    const auto save_settings = save;
		    xaml::Controls::TextBox draws;
		    draws.Header(winrt::box_value(L"Number of draws (0 = off)"));
		    draws.MaxLength(5);
		    draws.Text(std::to_wstring(settings_state->settings.flush_draws));
		    xaml::Input::InputScope scope;
		    xaml::Input::InputScopeName number;
		    number.NameValue(xaml::Input::InputScopeNameValue::Number);
		    scope.Names().Append(number);
		    draws.InputScope(scope);
		    draws.BeforeTextChanging([](auto const&, xaml::Controls::TextBoxBeforeTextChangingEventArgs const& args) {
			    args.Cancel(!std::ranges::all_of(args.NewText(), [](wchar_t ch) { return ch >= L'0' && ch <= L'9'; }));
		    });
		    xaml::Controls::ContentDialog dialog;
		    dialog.Title(winrt::box_value(L"Draws per GPU submission"));
		    dialog.Content(draws);
		    dialog.PrimaryButtonText(L"Применить");
		    dialog.CloseButtonText(L"Отмена");
		    if (co_await dialog.ShowAsync() == xaml::Controls::ContentDialogResult::Primary) {
			    uint32_t count = 0;
			    for (const wchar_t digit: draws.Text()) {
				    count = count * 10 + static_cast<uint32_t>(digit - L'0');
			    }
			    settings_state->settings.flush_draws = count;
			    save_settings();
		    }
	    },
	    {L"Отправляет записанную работу после такого числа отрисовок, чтобы GPU мог начать до конца длинного буфера команд.",
	     L"Лишние отправки тратят время процессора. Используйте 0 для обычной пакетной отправки. Применяется при запуске игры."});
	AddSwitch(
	    testing, explanation, L"Сохранять скомпилированные шейдеры между сборками приложения", settings.shader_cache_any_build,
	    [state, save](bool on) {
		    state->settings.shader_cache_any_build = on;
		    save();
	    },
	    {L"После обновления приложения игры запускаются без повторной компиляции шейдеров, если только обновление не приносит новый транслятор шейдеров.",
	     L"Если обновление изменило способ трансляции шейдеров, игры могут вылетать или показывать неверное изображение.",
	     L"В таком случае выключите эту функцию или удалите скомпилированные шейдеры. При следующем запуске игра скомпилирует шейдеры заново.",
	     L"Включение или выключение этой функции также заставляет каждую игру ещё раз скомпилировать шейдеры."});
	AddSwitch(
	    testing, explanation, L"Удалённые контроллеры", settings.dsu_enabled,
	    [state, save, place_entries](bool on) {
		    state->settings.dsu_enabled = on;
		    save();
		    SetControllerAssignment(state->settings.controller_auto, state->settings.controller_players, DsuServersInUse(state->settings));
		    place_entries(on);
	    },
	    {L"Добавляет удалённые контроллеры: контроллеры, которые приложение с поддержкой DSU на компьютере или телефоне раздаёт по сети. Ещё тестируется."});
	// The games' compiled shaders (ShaderCacheFolder, a file or two per game): each game compiles them afresh on its next start.
	auto remove_shaders_status = page.FindName(L"RemoveShadersStatus").as<xaml::Controls::TextBlock>();
	auto remove_shaders        = page.FindName(L"RemoveShaders").as<xaml::Controls::Button>();
	Explain(remove_shaders, explanation, {L"Удаляет скомпилированные шейдеры всех игр.", L"Каждая игра скомпилирует их заново при следующем запуске."});
	remove_shaders.Click([remove_shaders_status, state](auto const&, auto const&) {
		std::error_code error;
		uint64_t        files = 0;
		uint64_t        bytes = 0;
		for (const auto& entry: std::filesystem::directory_iterator(ShaderCacheFolder(state->settings), error)) {
			const auto size = entry.is_regular_file(error) ? entry.file_size(error) : 0;
			if (std::filesystem::remove(entry.path(), error)) {
				files++;
				bytes += size;
			}
		}
		remove_shaders_status.Text(files == 0 ? std::wstring(L"Нет скомпилированных шейдеров для удаления")
		                                      : L"Удалено " + std::to_wstring(files) + (files == 1 ? L" файл (" : L" файлов (") +
		                                            std::to_wstring((bytes + (1u << 20u) - 1) >> 20u) + L" МБ)");
	});
	// The trophies earned in all games, after the player confirms (Cancel has the focus).
	auto reset_trophies_status = page.FindName(L"ResetTrophiesStatus").as<xaml::Controls::TextBlock>();
	auto reset_trophies        = page.FindName(L"ResetTrophies").as<xaml::Controls::Button>();
	Explain(reset_trophies, explanation, {L"Удаляет трофеи, полученные во всех играх.", L"Это нельзя отменить."});
	reset_trophies.Click([reset_trophies_status](auto const&, auto const&) -> winrt::fire_and_forget {
		auto                          status = reset_trophies_status; // the captures don't outlive the first co_await
		xaml::Controls::ContentDialog dialog;
		dialog.Title(winrt::box_value(L"Reset all trophies?"));
		dialog.Content(winrt::box_value(L"This removes the trophies you've earned in all games. This can't be undone."));
		dialog.PrimaryButtonText(L"Сбросить");
		dialog.CloseButtonText(L"Отмена");
		dialog.DefaultButton(xaml::Controls::ContentDialogButton::Close);
		if (co_await dialog.ShowAsync() != xaml::Controls::ContentDialogResult::Primary) {
			co_return;
		}
		const size_t games = ResetAllTrophies();
		status.Text(games == 0 ? std::wstring(L"Нет трофеев для сброса")
		                                      : L"Сброшены трофеи: " + std::to_wstring(games) + (games == 1 ? L" игра" : L" игр"));
	});

	// The chosen category's settings, in the categories' order (the markup's panels).
	auto categories = page.FindName(L"Categories").as<xaml::Controls::ListView>();
	auto panels     = page.FindName(L"Panels").as<xaml::Controls::ScrollViewer>();
	std::vector<xaml::UIElement> category_panels;
	for (const auto* name: {L"Экран", L"Оверлей", L"Контроллер", L"Система", L"Хранилище", L"Память", L"Разработчик"}) {
		category_panels.push_back(page.FindName(name).as<xaml::UIElement>());
	}
	// The explanation while a category is chosen and before a setting of it has the focus.
	const std::vector<Paragraphs> category_explanations = {
	    {},
	    {},
	    {},
	    {L"Собственные настройки консоли: имя пользователя, язык, вступительные логотипы и музыка главного экрана."},
	    {L"Где KytyPS5 ищет игры и где хранит сохранения, патчи и трофеи."},
	    {IsXbox() ? L"Если выключить параметр памяти, игры, которым она нужна, могут вылетать."
	              : L"На Xbox выключение параметра памяти может привести к вылетам игр, которым она нужна."},
	    {},
	};
	const auto explain_category = [explanation, category_explanations](int32_t index) {
		if (index >= 0 && static_cast<size_t>(index) < category_explanations.size()) {
			ShowExplanation(explanation, category_explanations[static_cast<size_t>(index)]);
		}
	};
	categories.SelectionChanged([panels, category_panels, explain_category](winrt::Windows::Foundation::IInspectable const& sender, auto const&) {
		const auto index = sender.as<xaml::Controls::ListView>().SelectedIndex();
		if (index < 0) {
			return;
		}
		for (size_t panel_index = 0; panel_index < category_panels.size(); panel_index++) {
			category_panels[panel_index].Visibility(panel_index == static_cast<size_t>(index) ? xaml::Visibility::Visible : xaml::Visibility::Collapsed);
		}
		panels.ChangeView(nullptr, 0.0, nullptr, true);
		explain_category(index);
	});
	categories.SelectedIndex(0);
	// Whether the focus is in the settings (B goes back to the categories) or in the categories (B leaves the page).
	auto in_panel = std::make_shared<bool>(false);
	panels.GotFocus([in_panel](auto const&, auto const&) { *in_panel = true; });
	categories.GotFocus([in_panel, explain_category](winrt::Windows::Foundation::IInspectable const& sender, auto const&) {
		*in_panel = false;
		explain_category(sender.as<xaml::Controls::ListView>().SelectedIndex());
	});

	// Back: B, Escape or the window's back button (shown while the page is open).
	const auto leave = [state, in_panel, categories, close_page] {
		if (state->folder_back) {
			const auto back = state->folder_back; // (a copy: going back may end the panel)
			if (back()) {
				return;
			}
			state->folder_back = nullptr;
		}
		if (!state->pages.empty()) {
			close_page();
			return;
		}
		if (*in_panel) {
			categories.Focus(xaml::FocusState::Keyboard);
			return;
		}
		if (!state->left) {
			state->left = true;
			state->back(state->folders_changed);
		}
	};
	page.KeyDown([leave](auto const&, xaml::Input::KeyRoutedEventArgs const& args) {
		if (args.Key() == winrt::Windows::System::VirtualKey::GamepadB ||
		    args.Key() == winrt::Windows::System::VirtualKey::Escape) {
			args.Handled(true);
			leave();
		}
	});
	// Each time the page shows: it shows again after the controls page (Button layout), with the focus back on that entry.
	page.Loaded([state, categories, leave](auto const&, auto const&) {
		auto navigation = winrt::Windows::UI::Core::SystemNavigationManager::GetForCurrentView();
		navigation.AppViewBackButtonVisibility(winrt::Windows::UI::Core::AppViewBackButtonVisibility::Visible);
		state->back_token = navigation.BackRequested([leave](auto const&, winrt::Windows::UI::Core::BackRequestedEventArgs const& args) {
			args.Handled(true);
			leave();
		});
		if (const auto control = state->return_focus.get()) {
			control.Focus(xaml::FocusState::Keyboard);
			state->return_focus = {};
		} else {
			categories.Focus(xaml::FocusState::Keyboard);
		}
	});
	page.Unloaded([state](auto const&, auto const&) {
		auto navigation = winrt::Windows::UI::Core::SystemNavigationManager::GetForCurrentView();
		navigation.BackRequested(state->back_token);
		navigation.AppViewBackButtonVisibility(winrt::Windows::UI::Core::AppViewBackButtonVisibility::Collapsed);
	});
	return page;
}

} // namespace Kyty::Uwp
