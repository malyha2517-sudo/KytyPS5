#include "app.h"

#include "cheatsPage.h"
#include "controllerSettings.h"
#include "emulatorHost.h"
#include "fileAccess.h"
#include "gameGraphics.h"
#include "gameImages.h"
#include "gameLibrary.h"
#include "gameSource.h"
#include "input.h"
#include "keyboard.h"
#include "launcher.h"
#include "log.h"
#include "graphics/host_gpu/d3d12/presentationStubs.h"
#include "common/pipelinePrewarm.h"
#include "graphics/host_gpu/frameDump.h"
#include "graphics/presentation/splashAnimation.h"
#include "overlay.h"
#include "settingsPage.h"
#include "systemDialog.h"
#include "trophiesPage.h"
#include "trophyToast.h"
#include "controlsPage.h"
#include "settings.h"
#include "xboxLook.h"

#include <windows.h>
#include <fileapifromapp.h>

#include <nlohmann/json.hpp>

#include <winrt/Microsoft.UI.Xaml.Controls.h>
#include <winrt/Windows.ApplicationModel.DataTransfer.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Graphics.Display.Core.h>
#include <winrt/Windows.Storage.h>
#include <winrt/Windows.UI.Xaml.Controls.Primitives.h>
#include <winrt/Windows.System.h>
#include <winrt/Windows.UI.Core.h>
#include <winrt/Windows.UI.ViewManagement.h>
#include <winrt/Windows.UI.Xaml.Input.h>
#include <winrt/Windows.UI.Xaml.Controls.h>
#include <winrt/Windows.UI.Composition.h>
#include <winrt/Windows.UI.Xaml.Hosting.h>
#include <winrt/Windows.UI.Xaml.Media.Animation.h>
#include <winrt/Windows.UI.Xaml.Media.h>
#include <winrt/Windows.UI.Xaml.Shapes.h>

#include <algorithm>
#include <array>
#include <cctype>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace Kyty::Uwp {

namespace xaml       = winrt::Windows::UI::Xaml;
namespace activation = winrt::Windows::ApplicationModel::Activation;

namespace {

// On an Xbox the app's window has 1920 x 1080 pixels whatever mode the TV is in, so without this the game's picture went to the screen at 1080p
// and the console scaled that up. RetroArch makes its picture the size of the TV's mode (HdmiDisplayInformation), and the DirectX team's notes
// on UWP for Xbox Series X|S allow a 4K swap chain that the console scales as needed. The factor by which the TV's mode is larger than the window's
// pixels (1 elsewhere): the panel's pixel scale grows by it, so the swap chain gets the TV's size and its inverse transform keeps it in the panel.
// With the setting Output resolution at 1080p, the picture keeps the window's pixels.
float OutputScale(float composition_scale, bool match_tv) {
	static float logged = 0.0f;
	if (!IsXbox() || composition_scale <= 0.0f) {
		return 1.0f;
	}
	if (!match_tv) {
		if (logged != -1.0f) {
			logged = -1.0f;
			Log("screen: Output resolution 1080p: the picture keeps the window's pixels\n");
		}
		return 1.0f;
	}
	float scale = 1.0f;
	try {
		const auto hdmi = winrt::Windows::Graphics::Display::Core::HdmiDisplayInformation::GetForCurrentView();
		if (hdmi == nullptr) {
			return 1.0f;
		}
		const auto  mode          = hdmi.GetCurrentDisplayMode();
		const auto  bounds        = xaml::Window::Current().Bounds();
		const float window_pixels = bounds.Width * composition_scale;
		if (mode == nullptr || window_pixels <= 0.0f) {
			return 1.0f;
		}
		scale = std::max(1.0f, static_cast<float>(mode.ResolutionWidthInRawPixels()) / window_pixels);
		if (scale != logged) {
			logged = scale;
			Log("screen: the TV is at %ux%u, the window has %.0fx%.0f pixels: the picture is made %.2f times larger\n", mode.ResolutionWidthInRawPixels(),
			    mode.ResolutionHeightInRawPixels(), window_pixels, bounds.Height * composition_scale, scale);
		}
	} catch (winrt::hresult_error const& error) {
		Log("screen: the TV's mode could not be read (0x%08x)\n", static_cast<uint32_t>(error.code()));
		return 1.0f;
	}
	return scale;
}

// The game's page: the panel the game presents to; in front of it the launch screen until the game is ready to be seen, and the game menu. The launch
// screen is the game's start screen as the PS5 shows it (its pic1 and pic2), or, when the game has none, a card with its background, name and progress.
constexpr wchar_t GameMarkup[] = LR"xaml(
<Grid xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
      xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
      Background="Black">
  <SwapChainPanel x:Name="Panel" HorizontalAlignment="Center" VerticalAlignment="Center" />
  <Grid x:Name="Launch" Background="Black" IsHitTestVisible="False">
    <Grid.OpacityTransition><ScalarTransition Duration="0:0:0.3" /></Grid.OpacityTransition>
    <Grid x:Name="Splash" Visibility="Collapsed">
      <Viewbox Stretch="Uniform">
        <Canvas Width="1920" Height="1080">
          <Canvas.Clip><RectangleGeometry Rect="0,0,1920,1080" /></Canvas.Clip>
          <Image x:Name="SplashBackground" Stretch="Fill" Opacity="0">
            <Image.RenderTransform><CompositeTransform x:Name="SplashBackgroundTransform" /></Image.RenderTransform>
          </Image>
          <Image x:Name="SplashLogo" Stretch="Fill" Opacity="0">
            <Image.RenderTransform><CompositeTransform x:Name="SplashLogoTransform" /></Image.RenderTransform>
          </Image>
          <Grid x:Name="SplashReveal" Width="1920" Height="1080" />
        </Canvas>
      </Viewbox>
    </Grid>
    <Grid x:Name="LaunchCard" Background="#0B0E14" Visibility="Collapsed">
      <Image x:Name="Backdrop" Stretch="UniformToFill" HorizontalAlignment="Center" VerticalAlignment="Center" Opacity="0">
        <Image.OpacityTransition><ScalarTransition Duration="0:0:0.4" /></Image.OpacityTransition>
      </Image>
      <Rectangle>
        <Rectangle.Fill>
          <LinearGradientBrush StartPoint="0,0" EndPoint="0,1">
            <GradientStop Color="#800B0E14" Offset="0" />
            <GradientStop Color="#990B0E14" Offset="0.45" />
            <GradientStop Color="#F00B0E14" Offset="1" />
          </LinearGradientBrush>
        </Rectangle.Fill>
      </Rectangle>
      <StackPanel VerticalAlignment="Bottom" Margin="48,0,48,48" Spacing="12">
        <TextBlock x:Name="Title" Style="{StaticResource TitleTextBlockStyle}" TextTrimming="CharacterEllipsis"
                   TextWrapping="NoWrap" />
        <StackPanel Orientation="Horizontal" Spacing="12">
          <ProgressRing IsActive="True" Width="16" Height="16" />
          <TextBlock Text="Запуск" Style="{StaticResource BodyTextBlockStyle}" VerticalAlignment="Center"
                     Foreground="{ThemeResource SystemControlForegroundBaseMediumBrush}" />
        </StackPanel>
      </StackPanel>
    </Grid>
  </Grid>

  <!-- The game menu (View + Menu, or Escape): the game keeps running behind it, dimmed. The menu is a panel on the left (Overlay's on the
       right); the text of the item with the focus floats next to it, always at the height of the panel's first item. No hint bar. -->
  <Grid x:Name="Menu" Visibility="Collapsed">
    <Rectangle x:Name="MenuDim" Fill="Black" Opacity="0.8" />
    <Grid x:Name="MenuPanel" Width="320" HorizontalAlignment="Left" Padding="24,32,24,24" Background="#1F1F1F">
      <Grid.RowDefinitions>
        <RowDefinition Height="Auto" />
        <RowDefinition Height="Auto" />
        <RowDefinition Height="*" />
      </Grid.RowDefinitions>
      <TextBlock x:Name="MenuCaption" Text="Меню игры" Style="{StaticResource CaptionTextBlockStyle}"
                 Foreground="{ThemeResource SystemControlForegroundBaseMediumBrush}" />
      <TextBlock x:Name="MenuTitle" Grid.Row="1" Style="{StaticResource SubtitleTextBlockStyle}"
                 MaxLines="2" TextTrimming="CharacterEllipsis" Margin="0,4,0,20" />
      <!-- Overlay, Controllers and its DSU servers: tiles as on the settings page. -->
      <ScrollViewer x:Name="MenuSettings" Grid.Row="2" VerticalScrollBarVisibility="Hidden" Visibility="Collapsed">
        <StackPanel x:Name="MenuTiles" Spacing="8" />
      </ScrollViewer>
      <!-- Trophies: the running game's progress and trophies (ShowGameTrophies). -->
      <Grid x:Name="MenuTrophies" Grid.Row="2" Visibility="Collapsed" />
      <StackPanel x:Name="MenuList" Grid.Row="2">
        <ListView x:Name="MenuItems" SelectionMode="None" IsItemClickEnabled="True" Margin="-12,0">
          <ListView.ItemContainerStyle>
            <Style TargetType="ListViewItem">
              <Setter Property="CornerRadius" Value="0" />
            </Style>
          </ListView.ItemContainerStyle>
        </ListView>
        <TextBlock x:Name="MenuStatus" Style="{StaticResource CaptionTextBlockStyle}" Margin="0,12,0,0"
                   Foreground="{ThemeResource SystemControlForegroundBaseMediumBrush}" Visibility="Collapsed"
                   Text="Сохранение, затем возврат в библиотеку..." />
      </StackPanel>
    </Grid>
    <StackPanel x:Name="MenuText" HorizontalAlignment="Left" VerticalAlignment="Top" Spacing="12" />
  </Grid>
</Grid>)xaml";

// Shown instead of the game when it can't start.
constexpr wchar_t ProblemMarkup[] = LR"(
<Grid xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
      xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
      xmlns:muxc="using:Microsoft.UI.Xaml.Controls" Padding="48">
  <StackPanel MaxWidth="640" VerticalAlignment="Center" Spacing="16">
    <TextBlock Text="Игра не может запуститься" Style="{StaticResource TitleTextBlockStyle}" />
    <TextBlock x:Name="Game" Style="{StaticResource BodyTextBlockStyle}" TextWrapping="Wrap"
               Opacity="0.7" />
    <muxc:InfoBar x:Name="Problem" IsOpen="True" IsClosable="False" Severity="Error" />
    <TextBox x:Name="Command" IsReadOnly="True" FontFamily="Consolas" TextWrapping="Wrap" />
    <StackPanel Orientation="Horizontal" Spacing="8">
      <Button x:Name="CopyCommand" Content="Скопировать команду"
              Style="{StaticResource AccentButtonStyle}" />
      <Button x:Name="Retry" Content="Повторить" />
    </StackPanel>
  </StackPanel>
</Grid>)";

// A kyty://run activation: a game folder (?game=<folder>) or a title ID (?title=<ID>, looked
// up in the game library), and an activity to start in (&activity=<ID>).
struct RunRequest {
	std::filesystem::path folder;
	std::string           title_id;
	// How many times the app restarted for this game (retry=<n>, see EmulatorHost::RestartForAddressCollision).
	uint32_t retry = 0;
	// The activity the game starts in (EmulatorHost::SetLaunchActivity); empty starts normally.
	std::string activity;
};

// The arguments as a kyty:// link to `host`, or nothing. The scheme is KYTY_UWP_PROTOCOL of the build ("kyty", or another name for a build
// installed next to it).
std::optional<winrt::Windows::Foundation::Uri> KytyLink(winrt::hstring const& arguments, std::wstring_view host) {
	if (arguments.empty()) {
		return std::nullopt;
	}
	try {
		winrt::Windows::Foundation::Uri uri(arguments);
		if (std::wstring_view(uri.SchemeName()).substr(0, 4) != L"kyty" || uri.Host() != host) {
			return std::nullopt;
		}
		return uri;
	} catch (const winrt::hresult_error&) {
	}
	return std::nullopt;
}

// A trophy notification's link: kyty://trophy?title=<title ID>&name=<the trophy's name>. It comes back as the notification's activation
// argument, so the scheme is never resolved and any build's name works.
struct TrophyLink {
	std::string title_id;
	std::string name;
};

winrt::hstring TrophyLinkArguments(const std::string& title_id, const std::string& name) {
	using winrt::Windows::Foundation::Uri;
	return L"kyty://trophy?title=" + Uri::EscapeComponent(winrt::to_hstring(title_id)) + L"&name=" + Uri::EscapeComponent(winrt::to_hstring(name));
}

std::optional<TrophyLink> TrophyLinkFromArguments(winrt::hstring const& arguments) {
	const auto uri = KytyLink(arguments, L"trophy");
	if (!uri) {
		return std::nullopt;
	}
	try {
		TrophyLink link;
		for (const auto& entry: uri->QueryParsed()) {
			if (entry.Name() == L"title") {
				link.title_id = winrt::to_string(entry.Value());
			} else if (entry.Name() == L"name") {
				link.name = winrt::to_string(entry.Value());
			}
		}
		if (!link.title_id.empty()) {
			return link;
		}
	} catch (const winrt::hresult_error&) {
	}
	return std::nullopt;
}

// While a game runs: shows a trophy's details over it (SetUpGameMenu).
std::function<void(const TrophyLink&)> g_trophy_over_game;

std::optional<RunRequest> RunRequestFromArguments(winrt::hstring const& arguments) {
	const auto uri = KytyLink(arguments, L"run");
	if (!uri) {
		return std::nullopt;
	}
	try {
		RunRequest request;
		bool       found = false;
		for (const auto& entry: uri->QueryParsed()) {
			if (entry.Name() == L"game") {
				request.folder = std::filesystem::path(std::wstring(entry.Value()));
				found          = true;
			} else if (entry.Name() == L"title") {
				request.title_id = winrt::to_string(entry.Value());
				found            = true;
			} else if (entry.Name() == L"retry") {
				request.retry = static_cast<uint32_t>(std::wcstoul(std::wstring(entry.Value()).c_str(), nullptr, 10));
			} else if (entry.Name() == L"activity") {
				request.activity = winrt::to_string(entry.Value());
			}
		}
		if (found) {
			return request;
		}
	} catch (const winrt::hresult_error&) {
	}
	return std::nullopt;
}

struct GameProblem {
	winrt::hstring title;
	winrt::hstring message;
	// The command that fixes it, if one does.
	winrt::hstring command;
};

// Why the game in `game` can't start, if it can't. Game folders have to grant UWP apps read
// access ("ALL APPLICATION PACKAGES", see docs/uwp.md); files are then read directly, as fast
// as on the desktop.
std::optional<GameProblem> CheckGame(const std::filesystem::path& game) {
	const auto                eboot = game / L"eboot.bin";
	WIN32_FILE_ATTRIBUTE_DATA attributes {};
	if (IsArchivePath(game)) {
		// the archive itself must be readable and hold the game
		if (GetFileAttributesExFromAppW(game.c_str(), GetFileExInfoStandard, &attributes) == 0) {
			Log("cannot read %ls (error %lu)\n", game.c_str(), GetLastError());
			return GameProblem {L"Архив не читается", winrt::hstring(game.wstring())};
		}
		if (GameFileExists(eboot)) {
			return std::nullopt;
		}
		return GameProblem {L"В этом архиве нет игры", L"В корне архива нет eboot.bin."};
	}
	if (GetFileAttributesExFromAppW(eboot.c_str(), GetFileExInfoStandard, &attributes)) {
		return std::nullopt;
	}
	const auto error = GetLastError();
	Log("cannot read %ls (error %lu)\n", eboot.c_str(), error);
	if (error == ERROR_ACCESS_DENIED) {
		const auto games = game.has_parent_path() ? game.parent_path() : game;
		return GameProblem {
		    L"KytyPS5 может не прочитать эту папку",
		    IsXbox() ? L"Приложениям нужен доступ на чтение к папке с играми, который можно выдать на компьютере: подключите диск (NTFS) к компьютеру, откройте свойства папки > Безопасность > Изменить > Добавить, введите ALL APPLICATION PACKAGES и оставьте «Чтение и выполнение» — или выполните там эту команду, подставив букву диска вместо X:. Затем подключите диск обратно и повторите."
		             : L"Дайте приложениям доступ на чтение к папке с играми и повторите: в Проводнике откройте свойства папки > Безопасность > Изменить > Добавить, введите ALL APPLICATION PACKAGES и оставьте «Чтение и выполнение». Или выполните эту команду:",
		    winrt::hstring(GrantCommand(games))};
	}
	if (error == ERROR_FILE_NOT_FOUND || error == ERROR_PATH_NOT_FOUND) {
		return GameProblem {L"В этой папке нет игры", L"В папке нет eboot.bin."};
	}
	return GameProblem {L"Игра не читается",
	                    winrt::hstring(L"Код ошибки ") +
	                        winrt::to_hstring(static_cast<uint32_t>(error))};
}

xaml::UIElement CreateProblemPage(winrt::hstring const& subject, GameProblem const& problem,
                                  std::function<xaml::UIElement()> retry) {
	auto page = xaml::Markup::XamlReader::Load(ProblemMarkup).as<xaml::FrameworkElement>();
	page.FindName(L"Game").as<xaml::Controls::TextBlock>().Text(subject);
	auto info = page.FindName(L"Problem").as<winrt::Microsoft::UI::Xaml::Controls::InfoBar>();
	info.Title(problem.title);
	info.Message(problem.message);
	auto       command     = page.FindName(L"Command").as<xaml::Controls::TextBox>();
	auto       copy        = page.FindName(L"CopyCommand").as<xaml::Controls::Button>();
	const auto has_command = problem.command.empty() ? xaml::Visibility::Collapsed
	                                                 : xaml::Visibility::Visible;
	command.Text(problem.command);
	command.Visibility(has_command);
	// On the Xbox the command is for a PC, which the console's clipboard doesn't reach.
	copy.Visibility(IsXbox() ? xaml::Visibility::Collapsed : has_command);
	copy.Click([text = problem.command](auto const&, auto const&) {
		winrt::Windows::ApplicationModel::DataTransfer::DataPackage package;
		package.SetText(text);
		winrt::Windows::ApplicationModel::DataTransfer::Clipboard::SetContent(package);
	});
	page.FindName(L"Retry").as<xaml::Controls::Button>().Click(
	    [retry = std::move(retry)](auto const&, auto const&) {
		    xaml::Window::Current().Content(retry());
	    });
	return page;
}

winrt::fire_and_forget ShowLaunchBackdrop(xaml::Controls::Image image, std::filesystem::path path) {
	if (auto bitmap = co_await LoadImageAsync(image.Dispatcher(), path, 1920)) {
		image.Source(bitmap);
		image.Opacity(1.0);
	}
}

// Whether the game's logo comes in with its background (param.json's attribute3 bit 12, as upstream's splash animation reads it).
bool LogoFirst(const std::filesystem::path& game) {
	const auto text = ReadGameText(game / L"sce_sys" / L"param.json");
	if (!text) {
		return false;
	}
	const auto json = nlohmann::json::parse(*text, nullptr, false);
	return json.is_object() && json.contains("attribute3") && json["attribute3"].is_number_integer() &&
	       (json["attribute3"].get<int64_t>() & 0x1000) != 0;
}

// The start screen's images are extended on every side by this part of their size, repeating their edge pixels: upstream's animation samples
// them outside their edges (at its start up to 2.7% beyond each edge).
constexpr double SPLASH_EDGE = 0.04;

// Upstream's splash animation (graphics/presentation/splashAnimation.h) as keyframes, so that the compositor runs it: every 1/60 s while the
// background grows in and the logo fades in (3.6 s), every 0.1 s in the slow zoom that follows (to 13.4 s). Each layer's UV span about the
// center becomes a scale and an offset of its image, which covers its UVs from -SPLASH_EDGE to 1 + SPLASH_EDGE.
xaml::Media::Animation::Storyboard SplashStoryboard(xaml::Controls::Image background, xaml::Media::CompositeTransform background_transform,
                                                    xaml::Controls::Image logo, xaml::Media::CompositeTransform logo_transform, bool logo_first) {
	namespace animation = xaml::Media::Animation;
	struct Track {
		animation::DoubleAnimationUsingKeyFrames scale, scale_y, x, y, opacity;
	};
	std::array<Track, 2> tracks;
	std::vector<float>   times;
	for (int step = 0; step <= 216; step++) {
		times.push_back(static_cast<float>(step) / 60.0f);
	}
	for (int step = 1; step <= 98; step++) {
		times.push_back(3.6f + 0.1f * static_cast<float>(step));
	}
	for (const float time: times) {
		const auto key    = animation::KeyTimeHelper::FromTimeSpan(
            std::chrono::duration_cast<winrt::Windows::Foundation::TimeSpan>(std::chrono::duration<float>(time)));
		const auto layers = Libs::Graphics::AnimateSplash(time, logo_first);
		for (size_t index = 0; index < tracks.size(); index++) {
			const auto&  layer = layers[index];
			const double span  = layer.span;
			const double start = 0.5 - 0.5 * span;
			const auto   add   = [&key](animation::DoubleAnimationUsingKeyFrames& track, double value) {
                animation::LinearDoubleKeyFrame frame;
                frame.KeyTime(key);
                frame.Value(value);
                track.KeyFrames().Append(frame);
			};
			add(tracks[index].scale, 1.0 / span);
			add(tracks[index].scale_y, 1.0 / span);
			add(tracks[index].x, -(start + SPLASH_EDGE) * 1920.0 / span);
			add(tracks[index].y, -(start + SPLASH_EDGE) * 1080.0 / span);
			add(tracks[index].opacity, layer.alpha);
		}
	}
	animation::Storyboard storyboard;
	const std::array<xaml::Controls::Image, 2>           images {background, logo};
	const std::array<xaml::Media::CompositeTransform, 2> transforms {background_transform, logo_transform};
	for (size_t index = 0; index < tracks.size(); index++) {
		const auto target = [&storyboard](animation::DoubleAnimationUsingKeyFrames const& track, xaml::DependencyObject const& object,
		                                  const wchar_t* property) {
			animation::Storyboard::SetTarget(track, object);
			animation::Storyboard::SetTargetProperty(track, property);
			storyboard.Children().Append(track);
		};
		target(tracks[index].scale, transforms[index], L"ScaleX");
		target(tracks[index].scale_y, transforms[index], L"ScaleY");
		target(tracks[index].x, transforms[index], L"TranslateX");
		target(tracks[index].y, transforms[index], L"TranslateY");
		target(tracks[index].opacity, images[index], L"Opacity");
	}
	return storyboard;
}

// Upstream's radial reveal (RevealSplash) over the start screen: a black layer whose radial gradient opens from the center. Its stops sit at
// fixed distances from the center; their alpha runs on the compositor, from keyframes sampled every 1/60 s over the 1.4 s the reveal takes.
void StartSplashReveal(xaml::FrameworkElement const& host) {
	namespace composition = winrt::Windows::UI::Composition;
	constexpr float WIDTH  = 1920.0f;
	constexpr float HEIGHT = 1080.0f;
	constexpr float RADIUS = 1102.0f; // a corner's distance from the center
	constexpr int   STOPS  = 16;
	constexpr int   STEPS  = 84;      // 1.4 s at 60 per second
	const auto      black  = [](float alpha) {
        return winrt::Windows::UI::ColorHelper::FromArgb(static_cast<uint8_t>(std::lround(255.0f * std::clamp(alpha, 0.0f, 1.0f))), 0, 0, 0);
	};
	const auto compositor = xaml::Hosting::ElementCompositionPreview::GetElementVisual(host).Compositor();
	auto       brush      = compositor.CreateRadialGradientBrush();
	brush.MappingMode(composition::CompositionMappingMode::Absolute);
	brush.EllipseCenter({WIDTH * 0.5f, HEIGHT * 0.5f});
	brush.EllipseRadius({RADIUS, RADIUS});
	std::vector<std::pair<composition::CompositionColorGradientStop, composition::ColorKeyFrameAnimation>> stops;
	for (int index = 0; index < STOPS; index++) {
		const float offset = static_cast<float>(index) / static_cast<float>(STOPS - 1);
		const float x      = 0.5f + offset * RADIUS / WIDTH; // a point at that distance from the center, in the image's 0..1
		auto        stop   = compositor.CreateColorGradientStop(offset, black(1.0f - Libs::Graphics::RevealSplash(0.0f, x, 0.5f)));
		auto        reveal = compositor.CreateColorKeyFrameAnimation();
		for (int step = 1; step <= STEPS; step++) {
			const float age = static_cast<float>(step) / 60.0f;
			reveal.InsertKeyFrame(static_cast<float>(step) / STEPS, black(1.0f - Libs::Graphics::RevealSplash(age, x, 0.5f)),
			                      compositor.CreateLinearEasingFunction());
		}
		reveal.Duration(std::chrono::milliseconds(1400));
		brush.ColorStops().Append(stop);
		stops.emplace_back(stop, reveal);
	}
	auto visual = compositor.CreateSpriteVisual();
	visual.Size({WIDTH, HEIGHT});
	visual.Brush(brush);
	xaml::Hosting::ElementCompositionPreview::SetElementChildVisual(host, visual);
	for (auto& [stop, reveal]: stops) {
		stop.StartAnimation(L"Color", reveal);
	}
}

// The launch screen: the game's start screen as the PS5 shows it while the game starts (pic1 and pic2's logo over it, with upstream's splash
// animation and its radial reveal), or the card with its background, name and progress when it has none. `own` becomes true with the game's start screen.
winrt::fire_and_forget ShowStartScreen(xaml::Controls::Grid page, std::filesystem::path game, std::shared_ptr<bool> own) {
	const auto dispatcher = page.Dispatcher();
	co_await winrt::resume_background();
	const auto paths      = SplashImages(game, LoadSettings().console_language);
	const bool logo_first = LogoFirst(game);
	// Back on the UI thread before awaiting: an awaited operation resumes on the thread it was awaited from, and the XAML below needs the UI thread.
	co_await winrt::resume_foreground(dispatcher);
	auto background = co_await LoadDdsImageAsync(dispatcher, paths[0], SPLASH_EDGE);
	auto logo       = background != nullptr ? co_await LoadDdsImageAsync(dispatcher, paths[1], SPLASH_EDGE) : nullptr;
	if (background == nullptr || logo == nullptr) {
		page.FindName(L"LaunchCard").as<xaml::UIElement>().Visibility(xaml::Visibility::Visible);
		ShowLaunchBackdrop(page.FindName(L"Backdrop").as<xaml::Controls::Image>(), BackdropImage(game));
		co_return;
	}
	*own                  = true;
	auto background_image = page.FindName(L"SplashBackground").as<xaml::Controls::Image>();
	auto logo_image       = page.FindName(L"SplashLogo").as<xaml::Controls::Image>();
	background_image.Source(background);
	logo_image.Source(logo);
	for (auto image: {background_image, logo_image}) {
		image.Width(1920.0 * (1.0 + 2.0 * SPLASH_EDGE));
		image.Height(1080.0 * (1.0 + 2.0 * SPLASH_EDGE));
	}
	auto storyboard = SplashStoryboard(background_image, page.FindName(L"SplashBackgroundTransform").as<xaml::Media::CompositeTransform>(), logo_image,
	                                   page.FindName(L"SplashLogoTransform").as<xaml::Media::CompositeTransform>(), logo_first);
	auto splash     = page.FindName(L"Splash").as<xaml::Controls::Grid>();
	splash.Resources().Insert(winrt::box_value(L"SplashAnimation"), storyboard); // kept while it runs
	StartSplashReveal(page.FindName(L"SplashReveal").as<xaml::FrameworkElement>());
	splash.Visibility(xaml::Visibility::Visible);
	storyboard.Begin();
}

// In Segoe MDL2 Assets.
constexpr wchar_t CHEVRON_RIGHT[] = {0xE76C, 0};

// An entry of the game menu; `more` adds the chevron of an entry that opens a submenu.
xaml::Controls::ListViewItem MenuEntry(const wchar_t* text, bool more = false) {
	xaml::Controls::ListViewItem entry;
	entry.HorizontalContentAlignment(xaml::HorizontalAlignment::Stretch);
	xaml::Controls::Grid content;
	content.ColumnDefinitions().Append(xaml::Controls::ColumnDefinition());
	xaml::Controls::ColumnDefinition chevron_column;
	chevron_column.Width(xaml::GridLengthHelper::Auto());
	content.ColumnDefinitions().Append(chevron_column);
	xaml::Controls::TextBlock label;
	label.Text(text);
	content.Children().Append(label);
	if (more) {
		xaml::Controls::FontIcon chevron;
		chevron.FontFamily(xaml::Media::FontFamily(L"Segoe MDL2 Assets"));
		chevron.Glyph(CHEVRON_RIGHT);
		chevron.FontSize(12);
		chevron.VerticalAlignment(xaml::VerticalAlignment::Center);
		xaml::Controls::Grid::SetColumn(chevron, 1);
		content.Children().Append(chevron);
	}
	entry.Content(content);
	return entry;
}

void FocusControl(xaml::DependencyObject const& target) {
	if (auto control = target.try_as<xaml::Controls::Control>()) {
		control.Focus(xaml::FocusState::Keyboard);
	}
}

// The game menu's views: its entries, Overlay, Graphics, Controllers (and its DSU servers) and Trophies.
enum class MenuView { Entries, Overlay, Graphics, Controllers, Servers, Trophies };

// The running game's page applies a new Output resolution (the game menu's Graphics page): whether the picture matches the TV's mode.
std::function<void(bool)> g_output_resolution_changed;

// The game menu's panel is 320 wide; the text of the item with the focus starts 28 beside it, level with the panel's first item.
constexpr double MENU_PANEL_WIDTH = 320;
constexpr double MENU_TEXT_GAP    = 28;
constexpr double MENU_TEXT_TOP    = 100;
constexpr double MENU_TEXT_WIDTH  = 310;
// The game is dimmed so that the text reads well; less with Overlay and Graphics, whose changes show in the game.
constexpr double MENU_DIM         = 0.8;
constexpr double MENU_OVERLAY_DIM = 0.72;

// Sets up the game menu and the overlay of the page of `game`.
void SetUpGameMenu(xaml::Controls::Grid const& page, GameEntry const& game, winrt::hstring const& title) {
	auto menu_title    = page.FindName(L"MenuTitle").as<xaml::Controls::TextBlock>();
	auto menu          = page.FindName(L"Menu").as<xaml::UIElement>();
	auto dim           = page.FindName(L"MenuDim").as<xaml::UIElement>();
	auto panel         = page.FindName(L"MenuPanel").as<xaml::FrameworkElement>();
	auto list          = page.FindName(L"MenuList").as<xaml::UIElement>();
	auto items         = page.FindName(L"MenuItems").as<xaml::Controls::ListView>();
	auto status        = page.FindName(L"MenuStatus").as<xaml::UIElement>();
	auto settings_view = page.FindName(L"MenuSettings").as<xaml::UIElement>();
	auto tiles         = page.FindName(L"MenuTiles").as<xaml::Controls::StackPanel>();
	auto text          = page.FindName(L"MenuText").as<xaml::Controls::StackPanel>();
	auto trophies_view = page.FindName(L"MenuTrophies").as<xaml::Controls::Grid>();
	menu_title.Text(title);

	// The overlay goes under the menu, over the launch screen: its log shows the start too.
	uint32_t menu_index = 0;
	page.Children().IndexOf(menu, menu_index);
	auto overlay = std::make_shared<GameOverlay>(page, menu_index, title);
	overlay->Show(OverlayShown());
	const auto toggle_overlay = [overlay] {
		const bool shown = !overlay->Shown();
		overlay->Show(shown);
		SetOverlayShown(shown);
	};

	const auto resume      = MenuEntry(L"Продолжить");
	const auto settings    = MenuEntry(L"Оверлей", true);
	const auto graphics    = MenuEntry(L"Графика", true);
	const auto controllers = MenuEntry(L"Контроллеры", true);
	const auto trophies    = MenuEntry(L"Трофеи", true);
	const auto compile     = MenuEntry(L"Скомпилировать пайплайны");
	const auto dump        = MenuEntry(L"Сохранить дамп кадра");
	const auto quit        = MenuEntry(L"Выйти в библиотеку");
	// The tools under a line.
	xaml::Controls::ListViewItem line;
	{
		xaml::Shapes::Rectangle rule;
		rule.Height(1);
		rule.Fill(xaml::Media::SolidColorBrush(winrt::Windows::UI::ColorHelper::FromArgb(0xFF, 0x3A, 0x3A, 0x3A)));
		line.Content(rule);
		line.HorizontalContentAlignment(xaml::HorizontalAlignment::Stretch);
		line.MinHeight(0);
		line.Padding(xaml::ThicknessHelper::FromLengths(12, 6, 12, 6));
		line.IsEnabled(false);
		line.IsTabStop(false);
	}
	for (const auto& entry: {resume, settings, graphics, controllers, trophies, line, compile, dump, quit}) {
		items.Items().Append(entry);
	}
	// What each entry does, next to the panel while it has the focus.
	struct EntryText {
		xaml::Controls::ListViewItem entry;
		const wchar_t*               name;
		Paragraphs                   text;
	};
	const std::vector<EntryText> entry_texts = {
	    {resume, L"Продолжить", {L"Закрывает меню и возвращает в игру.", L"Пока меню открыто, игра продолжает работать, но управление в ней приостановлено."}},
	    {settings, L"Оверлей", {L"Выберите, что оверлей показывает поверх игры. Игра остаётся на экране, поэтому каждое изменение видно сразу."}},
	    {graphics, L"Графика", {L"Меняйте изображение и текстуры прямо во время игры. Игра остаётся на экране."}},
	    {controllers,
	     L"Контроллеры",
	     {LoadSettings().dsu_enabled
	          ? L"Выберите, какие контроллеры участвуют в игре и за какого игрока. Добавьте удалённые контроллеры, чтобы использовать контроллеры, которые приложения с поддержкой DSU раздают по сети."
	          : L"Выберите, какие контроллеры участвуют в игре и за какого игрока."}},
	    {trophies, L"Трофеи", {L"Трофеи этой игры и те, что вы уже получили."}},
	    {compile,
	     L"Скомпилировать пайплайны",
	     {L"В фоне компилирует пайплайны, которые игра использовала раньше, чтобы в новых местах было меньше подвисаний.",
	      L"Лучше запускать на экране заставки: это занимает несколько минут и расходует память до конца игры."}},
	    {dump, L"Сохранить дамп кадра", {L"Сохраняет цели рендеринга следующего кадра в PNG-файлы, чтобы искать проблемы с графикой."}},
	    {quit, L"Выйти в библиотеку", {L"Закрывает игру и возвращает в библиотеку. Несохранённый прогресс будет потерян."}},
	};
	items.GotFocus([text, entry_texts](auto const&, xaml::RoutedEventArgs const& args) {
		const auto focused = args.OriginalSource().try_as<xaml::Controls::ListViewItem>();
		for (const auto& entry: entry_texts) {
			if (focused == entry.entry) {
				ShowExplanation(text, entry.name, {}, entry.text);
				return;
			}
		}
	});

	// Overlay's and Graphics' panel goes to the right and its text to the left of it, the game a little less dim: the overlay at the top left
	// and the game stay in view.
	// The tiles go when another view shows (Controllers' follow the controllers while they are there).
	auto       current_view = std::make_shared<MenuView>(MenuView::Entries);
	const auto set_view     = [dim, panel, menu_title, title, list, settings_view, trophies_view, tiles, text, current_view](MenuView view) {
		*current_view       = view;
		const auto shown_if = [](bool shown) { return shown ? xaml::Visibility::Visible : xaml::Visibility::Collapsed; };
		const bool overlay_view = view == MenuView::Overlay || view == MenuView::Graphics;
		panel.HorizontalAlignment(overlay_view ? xaml::HorizontalAlignment::Right : xaml::HorizontalAlignment::Left);
		text.HorizontalAlignment(overlay_view ? xaml::HorizontalAlignment::Right : xaml::HorizontalAlignment::Left);
		text.Margin(overlay_view ? xaml::ThicknessHelper::FromLengths(0, MENU_TEXT_TOP, MENU_PANEL_WIDTH + MENU_TEXT_GAP, 0)
		                    : xaml::ThicknessHelper::FromLengths(MENU_PANEL_WIDTH + MENU_TEXT_GAP, MENU_TEXT_TOP, 0, 0));
		text.Width(MENU_TEXT_WIDTH);
		dim.Opacity(overlay_view ? MENU_OVERLAY_DIM : MENU_DIM);
		list.Visibility(shown_if(view == MenuView::Entries));
		settings_view.Visibility(shown_if(overlay_view || view == MenuView::Controllers || view == MenuView::Servers));
		trophies_view.Visibility(shown_if(view == MenuView::Trophies));
		tiles.Children().Clear();
		text.Children().Clear();
		menu_title.Text(view == MenuView::Overlay        ? winrt::hstring(L"Оверлей")
		                : view == MenuView::Graphics    ? winrt::hstring(L"Графика")
		                : view == MenuView::Controllers ? winrt::hstring(L"Контроллеры")
		                : view == MenuView::Servers     ? winrt::hstring(L"Удалённые контроллеры")
		                : view == MenuView::Trophies    ? winrt::hstring(L"Трофеи")
		                                                : title);
	};
	const auto in_subview = [current_view] { return *current_view != MenuView::Entries; };
	// The overlay's tiles, made anew each time so that they show the current values; a change shows at once.
	const auto open_settings = [set_view, tiles, text, overlay] {
		set_view(MenuView::Overlay);
		auto values = std::make_shared<AppSettings>(LoadSettings());
		AddOverlaySettings(tiles, tiles, text, values, [values, overlay] {
			SaveSettings(*values);
			overlay->Apply(*values);
			overlay->Show(OverlayShown());
		});
		tiles.UpdateLayout();
		FocusControl(tiles.Children().GetAt(0));
	};
	// The graphics settings a running game takes at once (gameGraphics.cpp).
	const auto open_graphics = [set_view, tiles, text] {
		set_view(MenuView::Graphics);
		auto values = std::make_shared<AppSettings>(LoadSettings());
		AddGameGraphicsSettings(tiles, text, values, [](bool match_tv) {
			if (g_output_resolution_changed) {
				g_output_resolution_changed(match_tv);
			}
		});
		tiles.UpdateLayout();
		FocusFirst(tiles);
	};
	// The DSU servers, as on the settings page (Settings › Controller › Remote Controllers); a change applies at once.
	const auto open_servers = [set_view, tiles, text] {
		set_view(MenuView::Servers);
		auto values = std::make_shared<AppSettings>(LoadSettings());
		AddServerTiles(tiles, text, values, [values] { SaveSettings(*values); });
		tiles.UpdateLayout();
		FocusFirst(tiles);
	};
	// The controllers and their players, as on the settings page (Settings › Controller › Players); a change applies at once.
	const auto open_controllers = [set_view, tiles, text, open_servers] {
		set_view(MenuView::Controllers);
		auto values = std::make_shared<AppSettings>(LoadSettings());
		AddPlayersTiles(tiles, text, values, [values] { SaveSettings(*values); }, open_servers);
		tiles.UpdateLayout();
		FocusFirst(tiles);
	};
	// The running game's trophies, read anew each time so that the ones earned in this session show.
	const auto open_trophies = [set_view, trophies_view, text, game] {
		set_view(MenuView::Trophies);
		ShowGameTrophies(trophies_view, game, text);
	};
	// Back to the entries, with the focus on the one the view was opened with; from the DSU servers back to the controllers.
	const auto close_subview = [set_view, items, current_view, open_controllers, tiles] {
		if (*current_view == MenuView::Servers) {
			open_controllers();
			FocusFirst(tiles, L"servers");
			return;
		}
		const int32_t from = *current_view == MenuView::Trophies      ? 4
		                     : *current_view == MenuView::Controllers ? 3
		                     : *current_view == MenuView::Graphics    ? 2
		                                                              : 1;
		set_view(MenuView::Entries);
		items.UpdateLayout();
		FocusControl(items.ContainerFromIndex(from));
	};

	const auto show = [menu, items, set_view](bool open) {
		if (!open) {
			set_view(MenuView::Entries);
		}
		menu.Visibility(open ? xaml::Visibility::Visible : xaml::Visibility::Collapsed);
		PauseGameInput(open || GameKeyboardShown() || SystemDialogShown());
		if (open) {
			set_view(MenuView::Entries);
			menu.UpdateLayout();
			FocusControl(items.ContainerFromIndex(0));
		}
	};
	const auto is_open = [menu] { return menu.Visibility() == xaml::Visibility::Visible; };

	// A game asking for text: the box for it goes over the game and the overlay, under the menu; the game's input is paused while it shows.
	page.Children().IndexOf(menu, menu_index);
	SetUpGameKeyboard(page, menu_index, [is_open](bool shown) { PauseGameInput(shown || SystemDialogShown() || is_open()); });
	// A system dialog the game waits for (the PlayStation Network sign-in, an error): the same, its box over the keyboard's.
	page.Children().IndexOf(menu, menu_index);
	SetUpSystemDialog(page, menu_index, [is_open](bool shown) { PauseGameInput(shown || GameKeyboardShown() || is_open()); });

	// A trophy notification selected during the game: the trophy's details over it, the game's input paused while they show (and after them
	// while the menu is open).
	g_trophy_over_game = [is_open](const TrophyLink& link) {
		PauseGameInput(true);
		ShowTrophyDetails(link.title_id, link.name, [is_open] {
			if (!is_open() && !GameKeyboardShown() && !SystemDialogShown()) {
				PauseGameInput(false);
			}
		});
	};

	items.ItemClick([show, open_settings, open_graphics, open_controllers, open_trophies, status, items, resume, settings, graphics, controllers,
	                 trophies, compile, dump, quit](auto const&, xaml::Controls::ItemClickEventArgs const& args) {
		// The entry, or its content: an entry is its own container, and the list may report either.
		const auto clicked = args.ClickedItem();
		const auto is      = [&clicked](xaml::Controls::ListViewItem const& entry) { return clicked == entry || clicked == entry.Content(); };
		if (is(resume)) {
			show(false);
			return;
		}
		if (is(settings)) {
			open_settings();
			return;
		}
		if (is(graphics)) {
			open_graphics();
			return;
		}
		if (is(controllers)) {
			open_controllers();
			return;
		}
		if (is(trophies)) {
			open_trophies();
			return;
		}
		if (is(compile)) {
			// The pipeline cache takes the request at the next flip and builds in the background: the line under the menu follows it.
			Common::PipelinePrewarm::Request();
			auto text = status.try_as<xaml::Controls::TextBlock>();
			if (text == nullptr) {
				return;
			}
			text.Text(L"Компиляция пайплайнов...");
			status.Visibility(xaml::Visibility::Visible);
			xaml::DispatcherTimer timer;
			timer.Interval(std::chrono::milliseconds(500));
			timer.Tick([timer, text](auto const&, auto const&) {
				const auto line = Common::PipelinePrewarm::GetStatus();
				text.Text(winrt::to_hstring(line));
				if (line.rfind("Compiling", 0) != 0) {
					timer.Stop();
				}
			});
			timer.Start();
			return;
		}
		if (is(dump)) {
			// The renderer takes the request at the next flip and writes the render targets as PNG files: the line under the menu follows it.
			Libs::Graphics::FrameDump::Request();
			auto text = status.try_as<xaml::Controls::TextBlock>();
			if (text == nullptr) {
				return;
			}
			text.Text(winrt::to_hstring(Libs::Graphics::FrameDump::GetStatus()));
			status.Visibility(xaml::Visibility::Visible);
			xaml::DispatcherTimer timer;
			timer.Interval(std::chrono::milliseconds(500));
			timer.Tick([timer, text](auto const&, auto const&) {
				const auto line = Libs::Graphics::FrameDump::GetStatus();
				text.Text(winrt::to_hstring(line));
				if (line.rfind("Frame dump", 0) == 0) {
					timer.Stop();
				}
			});
			timer.Start();
			return;
		}
		if (!is(quit)) {
			return;
		}
		items.IsEnabled(false);
		status.Visibility(xaml::Visibility::Visible);
		EmulatorHost::Get().QuitToLibrary();
	});

	// B (or Escape) goes back from Settings or Trophies to the entries and closes the menu from there; View + Menu (or Escape) opens it.
	// View + Menu with both triggers pulled (or F3) shows or hides the overlay.
	menu.KeyDown([show, in_subview, close_subview](auto const&, xaml::Input::KeyRoutedEventArgs const& args) {
		if (args.Key() == winrt::Windows::System::VirtualKey::GamepadB ||
		    args.Key() == winrt::Windows::System::VirtualKey::Escape) {
			args.Handled(true);
			if (in_subview()) {
				close_subview();
			} else {
				show(false);
			}
		}
	});
	winrt::Windows::UI::Core::CoreWindow::GetForCurrentThread().KeyDown(
	    [show, is_open, toggle_overlay](auto const&, winrt::Windows::UI::Core::KeyEventArgs const& args) {
		    if (args.VirtualKey() == winrt::Windows::System::VirtualKey::Escape && !is_open() && !GameKeyboardShown() && !SystemDialogShown()) {
			    args.Handled(true);
			    show(true);
		    } else if (args.VirtualKey() == winrt::Windows::System::VirtualKey::F3) {
			    args.Handled(true);
			    toggle_overlay();
		    }
	    });
	const auto dispatcher = page.Dispatcher();
	OnChords(
	    [dispatcher, show, is_open] {
		    (void)dispatcher.RunAsync(winrt::Windows::UI::Core::CoreDispatcherPriority::Normal,
		                              [show, is_open] { show(!is_open()); });
	    },
	    [dispatcher, toggle_overlay] {
		    (void)dispatcher.RunAsync(winrt::Windows::UI::Core::CoreDispatcherPriority::Normal,
		                              [toggle_overlay] { toggle_overlay(); });
	    });
}

// The emulator's page: a panel the emulator presents to, filling the window, under the game's
// launch screen until the game runs, and the game menu.
xaml::UIElement CreateEmulatorPage(std::filesystem::path game) {
	auto page = xaml::Markup::XamlReader::Load(GameMarkup).as<xaml::Controls::Grid>();
	const auto entry = ReadGame(game);
	const auto title = winrt::to_hstring(entry.name);
	SetUpGameMenu(page, entry, title);
	// Trophies the game unlocks show as system notifications, made on the UI thread from a copy of the name; selecting one opens the trophy.
	Libs::Graphics::SetTrophyUnlockHandler(
	    [dispatcher = page.Dispatcher(), title_id = entry.title_id](std::string_view name, int32_t /*grade*/, std::span<const std::byte> /*icon_png*/) {
		    (void)dispatcher.RunAsync(winrt::Windows::UI::Core::CoreDispatcherPriority::Normal, [title_id, name = std::string(name)] {
			    ShowTrophyToast(name, std::wstring(TrophyLinkArguments(title_id, name)));
		    });
	    });
	// The launch screen goes when the game says it is ready to be seen (sceSystemServiceHideSplashScreen), as on the PS5. A game that never says so
	// is shown once it presents steadily: at once over the card, 10 s later over its own start screen.
	const auto launch    = page.FindName(L"Launch").as<xaml::UIElement>();
	const auto own_start = std::make_shared<bool>(false);
	Libs::Graphics::SetSplashHiddenHandler([dispatcher = page.Dispatcher(), launch] {
		(void)dispatcher.RunAsync(winrt::Windows::UI::Core::CoreDispatcherPriority::Normal, [launch] {
			if (launch.Opacity() != 0.0) {
				Log("launch screen: the game is ready to be seen after %.1f s\n", EmulatorHost::Get().RunTimeMs() / 1000.0);
				launch.Opacity(0.0);
			}
		});
	});
	EmulatorHost::Get().OnGameVisible([launch, own_start] {
		if (!*own_start) {
			launch.Opacity(0.0);
			return;
		}
		xaml::DispatcherTimer timer;
		timer.Interval(std::chrono::seconds(10));
		timer.Tick([launch](winrt::Windows::Foundation::IInspectable const& sender, auto const&) {
			sender.as<xaml::DispatcherTimer>().Stop();
			if (launch.Opacity() != 0.0) {
				Log("launch screen: closed 10 s after the game presented steadily; it never said it was ready\n");
				launch.Opacity(0.0);
			}
		});
		timer.Start();
	});
	page.FindName(L"Title").as<xaml::Controls::TextBlock>().Text(title);
	ShowStartScreen(page, game, own_start);
	auto panel = page.FindName(L"Panel").as<xaml::Controls::SwapChainPanel>();
	// The game's picture is 16:9: the panel is the largest 16:9 rectangle that fits the window (black bars around it), so the picture is never stretched.
	page.SizeChanged([panel](auto const& sender, auto const&) {
		const auto   area   = sender.template as<xaml::FrameworkElement>();
		const double width  = area.ActualWidth();
		const double height = area.ActualHeight();
		if (width <= 0.0 || height <= 0.0) {
			return;
		}
		double panel_width  = width;
		double panel_height = width * 9.0 / 16.0;
		if (panel_height > height) {
			panel_height = height;
			panel_width  = height * 16.0 / 9.0;
		}
		panel.Width(panel_width);
		panel.Height(panel_height);
	});
	// Read when the game starts; the game menu's Graphics page can change it during the game (g_output_resolution_changed).
	const auto match_tv    = std::make_shared<bool>(LoadSettings().output_resolution != "1080p");
	const auto report_size = [match_tv](xaml::Controls::SwapChainPanel const& panel) {
		const float output = OutputScale(panel.CompositionScaleX(), *match_tv);
        EmulatorHost::Get().SetPanelSize(static_cast<float>(panel.ActualWidth()),
		                                                     static_cast<float>(panel.ActualHeight()),
		                                                     panel.CompositionScaleX() * output,
		                                                     panel.CompositionScaleY() * output);
	};
	panel.SizeChanged([report_size](auto const& sender, auto const&) {
		report_size(sender.template as<xaml::Controls::SwapChainPanel>());
	});
	panel.CompositionScaleChanged(
	    [report_size](xaml::Controls::SwapChainPanel const& sender, auto const&) { report_size(sender); });
	g_output_resolution_changed = [match_tv, report_size, weak = winrt::make_weak(panel)](bool matches) {
		*match_tv = matches;
		if (const auto current = weak.get()) {
			report_size(current);
		}
	};
	// On Xbox, B navigates back; in a game it is Circle.
	winrt::Windows::UI::Core::SystemNavigationManager::GetForCurrentView().BackRequested(
	    [](auto const&, winrt::Windows::UI::Core::BackRequestedEventArgs const& args) {
		    args.Handled(true);
	    });
	panel.Loaded([report_size, game = std::move(game)](auto const& sender, auto const&) {
		auto loaded = sender.template as<xaml::Controls::SwapChainPanel>();
		report_size(loaded);
		EmulatorHost::Get().Start(loaded, game);
	});
	return page;
}

// The game's page, or why it can't start.
xaml::UIElement CreateGamePage(std::filesystem::path game) {
	if (const auto problem = CheckGame(game)) {
		return CreateProblemPage(game.wstring().c_str(), *problem,
		                         [game] { return CreateGamePage(game); });
	}
	return CreateEmulatorPage(std::move(game));
}

// The page for a game identified by its title ID.
xaml::UIElement CreateTitlePage(std::string title_id) {
	if (const auto game = FindGame(title_id)) {
		return CreateGamePage(game->folder);
	}
	std::wstring folders;
	for (const auto& folder: GameFolders()) {
		folders += L"\n" + folder.wstring();
	}
	return CreateProblemPage(winrt::to_hstring(title_id),
	                         {L"Нет игры с таким Title ID",
	                          winrt::hstring(L"Её нет в папках с играми:") + folders.c_str()},
	                         [title_id] { return CreateTitlePage(title_id); });
}

xaml::UIElement CreateLibraryPage(bool scan = false, const std::filesystem::path& select = {}) {
	LauncherActions actions;
	actions.play = [](const GameEntry& game, const std::string& activity) {
		SetLastPlayed(game.title_id);
		EmulatorHost::Get().SetLaunchActivity(activity);
		xaml::Window::Current().Content(CreateGamePage(game.folder));
	};
	actions.open_settings = [] {
		xaml::Window::Current().Content(CreateSettingsPage([](bool folders_changed) {
			xaml::Window::Current().Content(CreateLibraryPage(folders_changed));
		}));
	};
	actions.open_trophies = [] {
		xaml::Window::Current().Content(CreateTrophiesPage([] { xaml::Window::Current().Content(CreateLibraryPage()); }));
	};
	actions.open_controls = [] {
		xaml::Window::Current().Content(CreateControlsPage([] { xaml::Window::Current().Content(CreateLibraryPage()); }));
	};
	actions.open_cheats = [](const GameEntry& game) {
		// Back at the game the cheats are for, not the one played last.
		xaml::Window::Current().Content(
		    CreateCheatsPage(game, [folder = game.folder] { xaml::Window::Current().Content(CreateLibraryPage(false, folder)); }));
	};
	return CreateLauncherPage(std::move(actions), scan, select);
}

} // namespace

App::App() {
	RequestedTheme(xaml::ApplicationTheme::Dark);
	// On Xbox, controllers move the focus instead of a mouse cursor.
	RequiresPointerMode(xaml::ApplicationRequiresPointerMode::WhenRequested);
	UnhandledException([](auto const&, xaml::UnhandledExceptionEventArgs const& args) {
		Log("unhandled exception: %ls\n", args.Message().c_str());
	});
}

void App::OnLaunched(activation::LaunchActivatedEventArgs const& args) {
	Show(args.Arguments());
}

void App::OnActivated(activation::IActivatedEventArgs const& args) {
	if (args.Kind() == activation::ActivationKind::Protocol) {
		Show(args.as<activation::ProtocolActivatedEventArgs>().Uri().AbsoluteUri());
	} else if (args.Kind() == activation::ActivationKind::ToastNotification) {
		// A trophy notification selected: its link (TrophyLinkArguments).
		Show(args.as<activation::ToastNotificationActivatedEventArgs>().Argument());
	} else {
		Show(L"");
	}
}

// Arguments left for the next start in LocalState\launch.txt, used once: the Xbox's Device Portal
// starts apps without arguments, so `uwp.ps1 launch` uploads them there first.
static winrt::hstring PendingLaunchArguments() {
	const auto file =
	    std::filesystem::path(winrt::Windows::Storage::ApplicationData::Current().LocalFolder().Path().c_str()) /
	    L"launch.txt";
	auto text = ReadTextFile(file);
	if (!text) {
		return {};
	}
	DeleteFileFromAppW(file.c_str());
	while (!text->empty() && std::isspace(static_cast<unsigned char>(text->back())) != 0) {
		text->pop_back();
	}
	Log("launch arguments from launch.txt\n");
	return winrt::to_hstring(*text);
}

void App::Show(winrt::hstring const& activation_arguments) {
	const auto arguments = activation_arguments.empty() ? PendingLaunchArguments() : activation_arguments;
	Log("activated, arguments: \"%ls\"\n", arguments.c_str());
	StartInput();
	{
		const auto settings = LoadSettings();
		SetControllerAssignment(settings.controller_auto, settings.controller_players, DsuServersInUse(settings));
	}
	if (!m_resources_loaded) {
		Resources().MergedDictionaries().Append(winrt::Microsoft::UI::Xaml::Controls::XamlControlsResources());
		Resources().MergedDictionaries().Append(XboxLookResources());
		m_resources_loaded = true;
	}
	auto window = xaml::Window::Current();
	// A trophy notification's link opens the trophy: over the game while one runs, else on the trophies page (back to the library).
	const auto trophy_link    = TrophyLinkFromArguments(arguments);
	const auto open_trophies = [](const TrophyLink& link) {
		return CreateTrophiesPage([] { xaml::Window::Current().Content(CreateLibraryPage()); }, link.title_id, link.name);
	};
	if (window.Content() == nullptr) {
		WaitForGameFolders();
		const auto run_request = RunRequestFromArguments(arguments);
		if (run_request) {
			EmulatorHost::Get().SetRestartAttempts(run_request->retry);
			EmulatorHost::Get().SetLaunchActivity(run_request->activity);
			RequestLibraryPipelines();
		}
		if (trophy_link) {
			window.Content(open_trophies(*trophy_link));
		} else if (auto request = run_request; !request) {
			window.Content(CreateLibraryPage());
		} else if (!request->title_id.empty()) {
			window.Content(CreateTitlePage(request->title_id));
		} else {
			window.Content(CreateGamePage(request->folder));
		}
	} else if (trophy_link) {
		if (g_trophy_over_game) {
			g_trophy_over_game(*trophy_link);
		} else {
			window.Content(open_trophies(*trophy_link));
		}
	}
	// On a PC the window opens 16:9 (the games' picture is); a console is always full screen. The preferred size applies from the next start of the app,
	// the resize to this one.
	namespace view = winrt::Windows::UI::ViewManagement;
	view::ApplicationView::PreferredLaunchWindowingMode(view::ApplicationViewWindowingMode::PreferredLaunchViewSize);
	view::ApplicationView::PreferredLaunchViewSize(winrt::Windows::Foundation::Size {1280.0f, 720.0f});
	window.Activate();
	(void)view::ApplicationView::GetForCurrentView().TryResizeView(winrt::Windows::Foundation::Size {1280.0f, 720.0f});
}

xaml::Markup::IXamlType App::GetXamlType(xaml::Interop::TypeName const& type) {
	return m_winui_types.GetXamlType(type);
}

xaml::Markup::IXamlType App::GetXamlType(winrt::hstring const& full_name) {
	return m_winui_types.GetXamlType(full_name);
}

winrt::com_array<xaml::Markup::XmlnsDefinition> App::GetXmlnsDefinitions() {
	return m_winui_types.GetXmlnsDefinitions();
}

} // namespace Kyty::Uwp
