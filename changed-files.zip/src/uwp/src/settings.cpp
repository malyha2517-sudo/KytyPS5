#include "settings.h"

#include "common/pipelinePrewarm.h"
#include "fileAccess.h"
#include "log.h"

#include <winrt/Windows.Storage.h>

#include <fstream>
#include <type_traits>
#include <nlohmann/json.hpp>
#include <system_error>

namespace Kyty::Uwp {

std::filesystem::path LocalStateFolder() {
	return std::filesystem::path(
	    std::wstring(winrt::Windows::Storage::ApplicationData::Current().LocalFolder().Path()));
}

namespace {

std::filesystem::path SettingsPath() {
	return LocalStateFolder() / L"kyty-uwp.json";
}

} // namespace

AppSettings LoadSettings() {
	AppSettings settings;
	const auto  text = ReadTextFile(SettingsPath());
	if (!text) {
		return settings;
	}
	const auto json = nlohmann::json::parse(*text, nullptr, false);
	if (json.is_discarded() || !json.is_object()) {
		Log("ignoring %ls: not a JSON object\n", SettingsPath().c_str());
		return settings;
	}
	if (const auto folders = json.find("game_folders"); folders != json.end() && folders->is_array()) {
		for (const auto& folder: *folders) {
			if (folder.is_string()) {
				settings.game_folders.emplace_back(winrt::to_hstring(folder.get<std::string>()).c_str());
			}
		}
	}
	if (const auto path = json.find("user_data_path"); path != json.end() && path->is_string()) {
		settings.user_data_path = winrt::to_hstring(path->get<std::string>()).c_str();
	}
	if (const auto path = json.find("logs_path"); path != json.end() && path->is_string()) {
		settings.logs_path = winrt::to_hstring(path->get<std::string>()).c_str();
	}
	if (const auto path = json.find("shader_cache_path"); path != json.end() && path->is_string()) {
		settings.shader_cache_path = winrt::to_hstring(path->get<std::string>()).c_str();
	}
	const auto read = [&json](const char* key, auto& value) {
		const auto it = json.find(key);
		if (it != json.end() && !it->is_null()) {
			try {
				value = it->get<std::remove_reference_t<decltype(value)>>();
			} catch (const nlohmann::json::exception&) {
				Log("ignoring setting %s: wrong type\n", key);
			}
		}
	};
	read("screen_width", settings.screen_width);
	read("screen_height", settings.screen_height);
	read("vsync", settings.vsync);
	read("vblank_frequency", settings.vblank_frequency);
	read("stretch", settings.stretch);
	read("user_name", settings.user_name);
	read("console_language", settings.console_language);
	read("skip_intro_logos", settings.skip_intro_logos);
	read("audio_output", settings.audio_output);
	read("audio_3d", settings.audio_3d);
	read("home_screen_music", settings.home_screen_music);
	read("controller_vibration", settings.controller_vibration);
	read("controller_speaker_volume", settings.controller_speaker_volume);
	read("trophy_notifications", settings.trophy_notifications);
	read("network_connected", settings.network_connected);
	read("emulate_psn", settings.emulate_psn);
	read("dialog_auto_close", settings.dialog_auto_close);
	read("readback_linear_images", settings.readback_linear_images);
	read("lod_stats", settings.lod_stats);
	read("readback_tiled_images", settings.readback_tiled_images);
	read("readback_storage_images", settings.readback_storage_images);
	read("accurate_texture_sync", settings.accurate_texture_sync);
	read("playgo_fallback", settings.playgo_fallback);
	read("virtual_vr_headset", settings.virtual_vr_headset);
	read("pro_mode", settings.pro_mode);
	read("guest_tsc", settings.guest_tsc);
	read("occlusion_queries", settings.occlusion_queries);
	read("tessellation", settings.tessellation);
	read("relaxed_shader_float", settings.relaxed_shader_float);
	read("pssr_upscaler", settings.pssr_upscaler);
	read("fsr_frame_generation", settings.fsr_frame_generation);
	read("fsr1_upscaling", settings.fsr1_upscaling);
	read("output_resolution", settings.output_resolution);
	if (const auto draws = json.find("flush_draws");
	    draws != json.end() && draws->is_number_unsigned() && draws->get<uint64_t>() <= 99999) {
		settings.flush_draws = draws->get<uint32_t>();
	}
	read("debug_layer", settings.debug_layer);
	read("game_output", settings.game_output);
	read("d3d12_selftest", settings.d3d12_selftest);
	read("overlay_size", settings.overlay_size);
	read("overlay_log_lines", settings.overlay_log_lines);
	read("overlay_detail", settings.overlay_detail);
	read("overlay_log", settings.overlay_log);
	read("overlay_controllers", settings.overlay_controllers);
	read("overlay_cpu", settings.overlay_cpu);
	read("overlay_swap", settings.overlay_swap);
	read("compile_notice", settings.compile_notice);
	read("xbox_gpu_limits", settings.xbox_gpu_limits);
	read("xbox_limits_dxil_parts", settings.xbox_limits_dxil_parts);
	read("dump_pipeline", settings.dump_pipeline);
	read("shader_override", settings.shader_override);
	read("gpu_hang_exit_seconds", settings.gpu_hang_exit_seconds);
	read("mesh_compute", settings.mesh_compute);
	read("guest_ram_budget_mb", settings.guest_ram_budget_mb);
	read("guest_ram_pager_mode", settings.guest_ram_pager_mode);
	read("guest_commit_limit_mb", settings.guest_commit_limit_mb);
	read("texture_mip_skip", settings.texture_mip_skip);
	read("texture_mip_skip_min_size", settings.texture_mip_skip_min_size);
	read("texture_mip_skip_uncompressed", settings.texture_mip_skip_uncompressed);
	read("texture_lod_bias", settings.texture_lod_bias);
	read("anisotropic_filtering", settings.anisotropic_filtering);
	read("frame_dump_after_s", settings.frame_dump_after_s);
	read("frame_dump_snapshots", settings.frame_dump_snapshots);
	read("gpu_memory_savings", settings.gpu_memory_savings);
	read("swap_pool_mb", settings.swap_pool_mb);
	read("video_decode_threads", settings.video_decode_threads);
	read("video_hardware_decode", settings.video_hardware_decode);
	read("short_videos", settings.short_videos);
	read("gpu_memory_log", settings.gpu_memory_log);
	read("gpu_crash_diagnostics", settings.gpu_crash_diagnostics);
	read("shader_cache_any_build", settings.shader_cache_any_build);
	read("app_memory_limit_mb", settings.app_memory_limit_mb);
	read("auto_press_ms", settings.auto_press_ms);
	read("impulse_triggers", settings.impulse_triggers);
	read("haptic_rumble", settings.haptic_rumble);
	read("motion_stick_up_forward", settings.motion_stick_up_forward);
	read("headset_speaker", settings.headset_speaker);
	read("headset_mic", settings.headset_mic);
	read("controller_auto", settings.controller_auto);
	read("controller_players", settings.controller_players);
	read("dsu_servers", settings.dsu_servers);
	read("dsu_enabled", settings.dsu_enabled);
	// The first experiment's one server.
	std::string server;
	read("dsu_server", server);
	if (settings.dsu_servers.empty() && !server.empty()) {
		settings.dsu_servers.push_back(server);
	}
	return settings;
}

std::vector<std::string> DsuServersInUse(const AppSettings& settings) {
	return settings.dsu_enabled ? settings.dsu_servers : std::vector<std::string> {};
}

void SaveSettings(const AppSettings& settings) {
	// Keys this version doesn't know stay as they are.
	const auto text = ReadTextFile(SettingsPath());
	auto       json = nlohmann::json::parse(text.value_or("{}"), nullptr, false);
	if (!json.is_object()) {
		json = nlohmann::json::object();
	}
	auto folders = nlohmann::json::array();
	for (const auto& folder: settings.game_folders) {
		folders.push_back(winrt::to_string(folder.wstring()));
	}
	json["game_folders"]     = folders;
	json["user_data_path"]   = winrt::to_string(settings.user_data_path.wstring());
	json["logs_path"]        = winrt::to_string(settings.logs_path.wstring());
	json["shader_cache_path"] = winrt::to_string(settings.shader_cache_path.wstring());
	json["screen_width"]     = settings.screen_width;
	json["screen_height"]    = settings.screen_height;
	json["vsync"]            = settings.vsync;
	json["vblank_frequency"] = settings.vblank_frequency;
	json["stretch"]          = settings.stretch;
	json["user_name"]        = settings.user_name;
	json["console_language"] = settings.console_language;
	json["skip_intro_logos"] = settings.skip_intro_logos;
	json["audio_output"]     = settings.audio_output;
	json["audio_3d"]         = settings.audio_3d;
	json["home_screen_music"] = settings.home_screen_music;
	json["controller_vibration"]      = settings.controller_vibration;
	json["controller_speaker_volume"] = settings.controller_speaker_volume;
	json["trophy_notifications"]   = settings.trophy_notifications;
	json["network_connected"]      = settings.network_connected;
	json["emulate_psn"]            = settings.emulate_psn;
	json["dialog_auto_close"]      = settings.dialog_auto_close;
	json["readback_linear_images"] = settings.readback_linear_images;
	json["lod_stats"]              = settings.lod_stats;
	json["readback_tiled_images"]  = settings.readback_tiled_images;
	json["readback_storage_images"] = settings.readback_storage_images;
	json["accurate_texture_sync"]  = settings.accurate_texture_sync;
	json["playgo_fallback"]        = settings.playgo_fallback;
	json["virtual_vr_headset"]     = settings.virtual_vr_headset;
	json["pro_mode"]               = settings.pro_mode;
	json["guest_tsc"]              = settings.guest_tsc;
	json["occlusion_queries"]      = settings.occlusion_queries;
	json["tessellation"]           = settings.tessellation;
	json["relaxed_shader_float"]   = settings.relaxed_shader_float;
	json["pssr_upscaler"] = settings.pssr_upscaler;
	json["fsr_frame_generation"] = settings.fsr_frame_generation;
	json["fsr1_upscaling"] = settings.fsr1_upscaling;
	json["output_resolution"] = settings.output_resolution;
	json["flush_draws"]            = settings.flush_draws;
	json["debug_layer"]      = settings.debug_layer;
	json["game_output"]      = settings.game_output;
	json["d3d12_selftest"]   = settings.d3d12_selftest;
	json["overlay_size"]     = settings.overlay_size;
	json["overlay_log_lines"] = settings.overlay_log_lines;
	json["overlay_detail"]      = settings.overlay_detail;
	json["overlay_log"]         = settings.overlay_log;
	json["overlay_controllers"] = settings.overlay_controllers;
	json["overlay_cpu"]         = settings.overlay_cpu;
	json["overlay_swap"]        = settings.overlay_swap;
	json["compile_notice"]      = settings.compile_notice;
	json["guest_ram_budget_mb"]        = settings.guest_ram_budget_mb;
	json["texture_mip_skip"]           = settings.texture_mip_skip;
	json["texture_mip_skip_min_size"]  = settings.texture_mip_skip_min_size;
	json["texture_mip_skip_uncompressed"] = settings.texture_mip_skip_uncompressed;
	json["texture_lod_bias"]           = settings.texture_lod_bias;
	json["anisotropic_filtering"]      = settings.anisotropic_filtering;
	json["gpu_memory_savings"]         = settings.gpu_memory_savings;
	json["swap_pool_mb"]               = settings.swap_pool_mb;
	json["video_decode_threads"]       = settings.video_decode_threads;
	json["video_hardware_decode"]      = settings.video_hardware_decode;
	json["short_videos"]               = settings.short_videos;
	json["gpu_memory_log"]             = settings.gpu_memory_log;
	json["gpu_crash_diagnostics"]      = settings.gpu_crash_diagnostics;
	json["shader_cache_any_build"]     = settings.shader_cache_any_build;
	json["impulse_triggers"]           = settings.impulse_triggers;
	json["haptic_rumble"]              = settings.haptic_rumble;
	json["motion_stick_up_forward"]    = settings.motion_stick_up_forward;
	json["headset_speaker"]            = settings.headset_speaker;
	json["headset_mic"]                = settings.headset_mic;
	json["controller_auto"]            = settings.controller_auto;
	json["controller_players"]         = settings.controller_players;
	json["dsu_servers"]                = settings.dsu_servers;
	json["dsu_enabled"]                = settings.dsu_enabled;
	json.erase("dsu_server");
	std::ofstream(SettingsPath(), std::ios::binary | std::ios::trunc) << json.dump(2);
}

std::filesystem::path LogsPathSetting() {
	try {
		std::ifstream file(SettingsPath(), std::ios::binary);
		const auto    json = nlohmann::json::parse(file, nullptr, false);
		if (json.is_object()) {
			if (const auto path = json.find("logs_path"); path != json.end() && path->is_string()) {
				return winrt::to_hstring(path->get<std::string>()).c_str();
			}
		}
	} catch (...) {
		// No package (LocalState), or a broken file: the log stays in LocalState.
	}
	return {};
}

std::filesystem::path UserDataFolder(const AppSettings& settings) {
	return settings.user_data_path.empty() ? LocalStateFolder() : settings.user_data_path;
}

std::filesystem::path ShaderCacheFolder(const AppSettings& settings) {
	return (settings.shader_cache_path.empty() ? LocalStateFolder() : settings.shader_cache_path) / L"_PipelineCache";
}

std::vector<std::filesystem::path> GameFolders() {
	std::vector<std::filesystem::path> folders;

	const auto      own = LocalStateFolder() / L"Игры";
	std::error_code error;
	std::filesystem::create_directories(own, error);
	folders.push_back(own);

	for (auto& folder: LoadSettings().game_folders) {
		folders.push_back(std::move(folder));
	}
	return folders;
}

namespace {

nlohmann::json ReadAppState() {
	const auto text  = ReadTextFile(LocalStateFolder() / L"app-state.json");
	auto       state = nlohmann::json::parse(text.value_or("{}"), nullptr, false);
	return state.is_object() ? state : nlohmann::json::object();
}

void WriteAppState(const nlohmann::json& state) {
	std::ofstream(LocalStateFolder() / L"app-state.json", std::ios::binary | std::ios::trunc)
	    << state.dump(2);
}

} // namespace

std::string LastPlayed() {
	const auto state = ReadAppState();
	const auto value = state.find("last_played");
	return value != state.end() && value->is_string() ? value->get<std::string>() : std::string();
}

void SetLastPlayed(const std::string& title_id) {
	auto state           = ReadAppState();
	state["last_played"] = title_id;
	WriteAppState(state);
}

bool OverlayShown() {
	const auto state = ReadAppState();
	const auto value = state.find("overlay");
	return value != state.end() && value->is_boolean() && value->get<bool>();
}

void SetOverlayShown(bool shown) {
	auto state       = ReadAppState();
	state["overlay"] = shown;
	WriteAppState(state);
}

std::vector<std::filesystem::path> HiddenGames() {
	std::vector<std::filesystem::path> folders;
	const auto                         state  = ReadAppState();
	const auto                         hidden = state.find("hidden_games");
	if (hidden != state.end() && hidden->is_array()) {
		for (const auto& folder: *hidden) {
			if (folder.is_string()) {
				folders.emplace_back(winrt::to_hstring(folder.get<std::string>()).c_str());
			}
		}
	}
	return folders;
}

void HideGame(const std::filesystem::path& folder) {
	auto state = ReadAppState();
	if (!state.contains("hidden_games") || !state["hidden_games"].is_array()) {
		state["hidden_games"] = nlohmann::json::array();
	}
	state["hidden_games"].push_back(winrt::to_string(folder.wstring()));
	WriteAppState(state);
}

void ShowAllGames() {
	auto state = ReadAppState();
	state.erase("hidden_games");
	WriteAppState(state);
}

PipelineMode LibraryPipelineMode() {
	const auto state = ReadAppState();
	const auto value = state.find("pipeline_mode");
	if (value == state.end() || !value->is_string()) {
		return PipelineMode::WhenNeeded;
	}
	const auto& mode = value->get_ref<const std::string&>();
	return mode == "alongside" ? PipelineMode::Alongside : mode == "first" ? PipelineMode::First : PipelineMode::WhenNeeded;
}

std::vector<std::pair<uint64_t, uint64_t>> KnownFixedRanges(const std::filesystem::path& game) {
	std::vector<std::pair<uint64_t, uint64_t>> ranges;
	const auto                                 state = ReadAppState();
	const auto                                 all   = state.find("fixed_ranges");
	if (all == state.end() || !all->is_object()) {
		return ranges;
	}
	const auto found = all->find(winrt::to_string(game.wstring()));
	if (found == all->end() || !found->is_array()) {
		return ranges;
	}
	for (const auto& range: *found) {
		if (range.is_array() && range.size() == 2 && range[0].is_number_unsigned() && range[1].is_number_unsigned()) {
			ranges.emplace_back(range[0].get<uint64_t>(), range[1].get<uint64_t>());
		}
	}
	return ranges;
}

void AddKnownFixedRange(const std::filesystem::path& game, uint64_t start, uint64_t size) {
	auto  state = ReadAppState();
	auto& list  = state["fixed_ranges"][winrt::to_string(game.wstring())];
	if (!list.is_array()) {
		list = nlohmann::json::array();
	}
	for (const auto& range: list) {
		if (range.is_array() && range.size() == 2 && range[0] == start && range[1] == size) {
			return;
		}
	}
	list.push_back({start, size});
	WriteAppState(state);
}

void RequestLibraryPipelines() {
	switch (LibraryPipelineMode()) {
	case PipelineMode::Alongside:
		// The pipeline cache takes the request at the game's first frame and builds in the background.
		Common::PipelinePrewarm::Request();
		break;
	case PipelineMode::First:
		// The game's code starts once the pipeline cache built them (Emulator::Run); the launch screen shows how far it is.
		Common::PipelinePrewarm::RequestBeforeStart();
		break;
	case PipelineMode::WhenNeeded:
		break;
	}
}

void SetLibraryPipelineMode(PipelineMode mode) {
	auto state             = ReadAppState();
	state["pipeline_mode"] = mode == PipelineMode::Alongside ? "alongside" : mode == PipelineMode::First ? "first" : "when_needed";
	WriteAppState(state);
}

} // namespace Kyty::Uwp
