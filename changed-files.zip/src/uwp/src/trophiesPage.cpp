#include "trophiesPage.h"

#include "fileAccess.h"
#include "gameImages.h"
#include "gameLibrary.h"
#include "gameSource.h"
#include "log.h"
#include "settingTiles.h"
#include "settings.h"
#include "xboxLook.h"

#include "common/archive.h"
#include "common/file.h"
#include "common/trophies.h"

#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Storage.Streams.h>
#include <winrt/Windows.System.h>
#include <winrt/Windows.UI.Core.h>
#include <winrt/Windows.UI.h>
#include <winrt/Windows.UI.Text.h>
#include <winrt/Windows.UI.Xaml.Controls.Primitives.h>
#include <winrt/Windows.UI.Xaml.Controls.h>
#include <winrt/Windows.UI.Xaml.Input.h>
#include <winrt/Windows.UI.Xaml.Interop.h>
#include <winrt/Windows.UI.Xaml.Markup.h>
#include <winrt/Windows.UI.Xaml.Media.Imaging.h>
#include <winrt/Windows.UI.Xaml.Media.h>
#include <winrt/Windows.UI.Xaml.Shapes.h>

// After the WinRT headers: its FindText macro would rename a method of Windows.UI.Text.
#include <windows.h>
#include <fileapifromapp.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <ctime>
#include <cwchar>
#include <filesystem>
#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace Kyty::Uwp {

namespace {

namespace xaml     = winrt::Windows::UI::Xaml;
namespace Trophies = Common::Trophies;

// The emulator's user (Config's default; the app sets no other), whose unlocks are shown.
constexpr int USER_ID = 1000;
// Trophy packages looked for per game: trophy00.ucp to trophy09.ucp (one per service label).
constexpr uint32_t SERVICE_LABELS = 10;

// A trophy cup in a 24 x 24 box, filled: the grade marks.
constexpr wchar_t CUP[] = L"M7,3 H17 V9 C17,12.3 14.8,14.5 12,14.5 C9.2,14.5 7,12.3 7,9 Z "
                          L"M7,4.5 H4 V6.5 C4,8.7 5.3,10.3 7.2,10.7 L7.4,9.2 C6.2,8.9 5.5,7.9 5.5,6.5 V6 H7 Z "
                          L"M17,4.5 H20 V6.5 C20,8.7 18.7,10.3 16.8,10.7 L16.6,9.2 C17.8,8.9 18.5,7.9 18.5,6.5 V6 H17 Z "
                          L"M11,14 H13 V18 H11 Z M8,18 H16 V20.5 H8 Z";

// Sizes in effective pixels, as the library's home screen: its margins, its header (the page title over Body) and its controller
// hints; the lists use Body text only.
constexpr double COVER_SIZE = 56;
constexpr double ICON_SIZE  = 56;
constexpr double CUP_SIZE   = 16;
// The game menu's side panel is narrow: smaller icons, the grade under the name.
constexpr double MENU_ICON_SIZE = 40;
// The grade counts are cells of one width, so that they line up from row to row and with the header's.
constexpr double GRADE_CELL_WIDTH = 88;

constexpr wchar_t PageMarkup[] = LR"xaml(
<Grid xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
      xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
      Background="{ThemeResource ApplicationPageBackgroundThemeBrush}">
  <Grid Padding="0,40,0,32">
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto" />
      <RowDefinition Height="*" />
      <RowDefinition Height="Auto" />
    </Grid.RowDefinitions>

    <!-- The header: "Trophies" or the open game, a line under it, and the grade counts at the right. The gaps are margins, so that "Trophies"
         starts at the page's edge while there is no cover. -->
    <Grid Margin="48,0">
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="Auto" />
        <ColumnDefinition Width="*" />
        <ColumnDefinition Width="Auto" />
      </Grid.ColumnDefinitions>
      <Border x:Name="HeaderCover" Width="48" Height="48" Margin="0,0,16,0" CornerRadius="4" Background="#1C2330" Visibility="Collapsed" />
      <StackPanel Grid.Column="1" Spacing="2" VerticalAlignment="Center">
        <TextBlock x:Name="HeaderTitle" Text="Трофеи" Style="{StaticResource PageTitleTextBlockStyle}" />
        <TextBlock x:Name="HeaderSummary" Style="{StaticResource BodyTextBlockStyle}"
                   Foreground="{ThemeResource SystemControlForegroundBaseMediumBrush}" />
      </StackPanel>
      <StackPanel x:Name="HeaderGrades" Grid.Column="2" Margin="16,0,0,0" Orientation="Horizontal" Spacing="16" VerticalAlignment="Center" />
    </Grid>

    <StackPanel x:Name="Status" Grid.Row="1" Margin="48,32,48,0" Orientation="Horizontal" Spacing="12" VerticalAlignment="Top">
      <ProgressRing x:Name="Loading" IsActive="True" Width="20" Height="20" />
      <TextBlock x:Name="StatusText" Text="Чтение трофеев игр..." Style="{StaticResource BodyTextBlockStyle}"
                 Foreground="{ThemeResource SystemControlForegroundBaseMediumBrush}" />
    </StackPanel>
    <!-- The lists' items have 12 of padding: 36 more puts their content on the header's 48. -->
    <ListView x:Name="Games" Grid.Row="1" Margin="0,24,0,0" Padding="36,0,36,16" SelectionMode="None" IsItemClickEnabled="True"
              XYFocusKeyboardNavigation="Enabled" Visibility="Collapsed" />
    <ListView x:Name="TrophyList" Grid.Row="1" Margin="0,24,0,0" Padding="36,0,36,16" SelectionMode="None" IsItemClickEnabled="True"
              XYFocusKeyboardNavigation="Enabled" Visibility="Collapsed" />

    <Border x:Name="Hints" Grid.Row="2" Style="{StaticResource HintBarStyle}" Margin="48,16,48,0" />
  </Grid>
</Grid>)xaml";

// One trophy package of a game (trophyNN.ucp) with the unlocks of it.
struct GamePackage {
	uint32_t             label = 0;
	Trophies::Package    package;
	Trophies::UnlockData unlocks;
	Trophies::Progress   progress;
};

// A game with trophies: its packages and their progress together.
struct GameTrophies {
	GameEntry                game;
	std::vector<GamePackage> packages;
	Trophies::Progress       progress;
};

// Grades as the PS5 numbers them.
const wchar_t* GradeName(int grade) {
	switch (grade) {
		case 1: return L"Платиновый";
		case 2: return L"Золотой";
		case 3: return L"Серебряный";
		case 4: return L"Бронзовый";
		default: return L"Трофей";
	}
}

// The desktop launcher's grade colours.
winrt::Windows::UI::Color GradeColor(int grade) {
	switch (grade) {
		case 1: return {255, 0x7f, 0xc8, 0xff};
		case 2: return {255, 0xf5, 0xc5, 0x42};
		case 3: return {255, 0xc4, 0xca, 0xd2};
		case 4: return {255, 0xcd, 0x7f, 0x4f};
		default: return {255, 0x80, 0x80, 0x80};
	}
}

// A game's trophy packages and unlocks, or nothing when it has none (a background thread: it reads the game and the user data folder).
std::optional<GameTrophies> LoadGameTrophies(GameEntry game, int language, const std::filesystem::path& user_data) {
	GameTrophies entry;
	entry.game            = std::move(game);
	const bool is_archive = IsArchivePath(entry.game.folder);
	// An archive's packages are looked up in its own index, as the emulator reads them: while its game runs, the Xbox refuses the archive's
	// attributes ("access denied"), which GameFileExists asks for. Held here, the archive's index is read once for all the packages.
	const auto archive = is_archive ? Common::OpenArchive(entry.game.folder) : nullptr;
	for (uint32_t label = 0; label < SERVICE_LABELS; label++) {
		const auto inner = Trophies::PackagePath(label);
		// Common::File reads a member of an archive by its virtual path.
		const auto path = is_archive ? Common::MakeArchivePath(entry.game.folder, inner) : entry.game.folder / inner;
		if (is_archive ? archive == nullptr || !Common::File::IsFileExisting(path) : !GameFileExists(path)) {
			continue;
		}
		GamePackage package;
		package.label   = label;
		package.package = Trophies::LoadPackage(path, language);
		if (package.package.trophies.empty()) {
			continue;
		}
		package.unlocks  = Trophies::LoadUnlockData(Trophies::UnlocksPath(user_data, entry.game.title_id, USER_ID, label));
		package.progress = Trophies::GetProgress(package.package, package.unlocks);
		for (size_t grade = 0; grade < entry.progress.total_grade.size(); grade++) {
			entry.progress.total_grade[grade] += package.progress.total_grade[grade];
			entry.progress.earned_grade[grade] += package.progress.earned_grade[grade];
		}
		entry.progress.total += package.progress.total;
		entry.progress.earned += package.progress.earned;
		entry.packages.push_back(std::move(package));
	}
	if (entry.packages.empty()) {
		return std::nullopt;
	}
	return entry;
}

// The games of the last library scan that have trophy packages, by name (a background thread).
std::vector<GameTrophies> LoadAllTrophies(int language) {
	std::vector<GameTrophies> games;
	const auto                user_data = UserDataFolder(LoadSettings());
	for (auto& game: LoadGameLibrary()) {
		if (auto entry = LoadGameTrophies(std::move(game), language, user_data)) {
			games.push_back(std::move(*entry));
		}
	}
	std::sort(games.begin(), games.end(), [](const GameTrophies& a, const GameTrophies& b) { return a.game.name < b.game.name; });
	return games;
}

// The trophies of the game with this title ID in the last library scan, reading only that game (a background thread).
std::optional<GameTrophies> LoadTitleTrophies(const std::string& title_id, int language) {
	for (auto& game: LoadGameLibrary()) {
		if (game.title_id == title_id) {
			return LoadGameTrophies(std::move(game), language, UserDataFolder(LoadSettings()));
		}
	}
	return std::nullopt;
}

// The package and the id of the trophy with this name.
std::optional<std::pair<size_t, int>> FindTrophy(const GameTrophies& entry, const std::string& name) {
	for (size_t p = 0; p < entry.packages.size(); p++) {
		for (const auto& [id, trophy]: entry.packages[p].package.trophies) {
			if (trophy.name == name) {
				return std::make_pair(p, id);
			}
		}
	}
	return std::nullopt;
}

xaml::Style TextStyle(const wchar_t* name) {
	return xaml::Application::Current().Resources().Lookup(winrt::box_value(name)).as<xaml::Style>();
}

xaml::Media::Brush MediumBrush() {
	return xaml::Application::Current().Resources().Lookup(winrt::box_value(L"SystemControlForegroundBaseMediumBrush")).as<xaml::Media::Brush>();
}

// A cup in a grade's colour, `size` pixels high. (A geometry can only be used once: each cup parses its own.)
xaml::Shapes::Path Cup(int grade, double size) {
	xaml::Shapes::Path cup;
	cup.Data(xaml::Markup::XamlBindingHelper::ConvertValue(winrt::xaml_typename<xaml::Media::Geometry>(), winrt::box_value(CUP))
	             .as<xaml::Media::Geometry>());
	cup.Fill(xaml::Media::SolidColorBrush(GradeColor(grade)));
	cup.Stretch(xaml::Media::Stretch::Uniform);
	cup.Width(size);
	cup.Height(size);
	cup.VerticalAlignment(xaml::VerticalAlignment::Center);
	return cup;
}

xaml::Controls::TextBlock Text(const std::wstring& text, const wchar_t* style = L"BodyTextBlockStyle") {
	xaml::Controls::TextBlock block;
	block.Style(TextStyle(style));
	block.Text(text);
	return block;
}

// The earned and total count per grade, one cell each; a grade without trophies (often platinum) leaves its cell empty.
void FillGrades(xaml::Controls::StackPanel const& panel, const Trophies::Progress& progress) {
	panel.Children().Clear();
	for (int grade = 1; grade <= 4; grade++) {
		xaml::Controls::StackPanel cell;
		cell.Orientation(xaml::Controls::Orientation::Horizontal);
		cell.Spacing(6);
		cell.Width(GRADE_CELL_WIDTH);
		cell.VerticalAlignment(xaml::VerticalAlignment::Center);
		if (progress.total_grade[grade] != 0) {
			cell.Children().Append(Cup(grade, CUP_SIZE));
			cell.Children().Append(Text(std::to_wstring(progress.earned_grade[grade]) + L" / " + std::to_wstring(progress.total_grade[grade])));
		}
		panel.Children().Append(cell);
	}
}

std::wstring Summary(const Trophies::Progress& progress) {
	return std::to_wstring(progress.earned) + L" из " + std::to_wstring(progress.total) + L" получен  ·  " + std::to_wstring(progress.Percentage()) +
	       L" %";
}

// "Earned 2026-10-08 18:30" in local time, or "Earned" without a time.
std::wstring EarnedText(const Trophies::UnlockData& unlocks, int id) {
	const auto found = unlocks.timestamps.find(id);
	if (found == unlocks.timestamps.end() || found->second <= Trophies::UnixEpochTick) {
		return L"Получен";
	}
	const auto seconds = static_cast<std::time_t>((found->second - Trophies::UnixEpochTick) / 1000000);
	std::tm    local {};
	if (localtime_s(&local, &seconds) != 0) {
		return L"Получен";
	}
	wchar_t text[64];
	std::wcsftime(text, std::size(text), L"Получен %d.%m.%Y %H:%M", &local);
	return text;
}

// A trophy's name as shown: hidden ones stay hidden until earned (or revealed in the details).
std::wstring TrophyName(const Trophies::Trophy& trophy, bool masked) {
	if (masked) {
		return L"Скрытый трофей";
	}
	return trophy.name.empty() ? L"Трофей " + std::to_wstring(trophy.id) : std::wstring(winrt::to_hstring(trophy.name));
}

// Shows a PNG (a trophy's icon) in `image`, decoded `width` pixels wide (UI thread).
winrt::fire_and_forget ShowPng(xaml::Controls::Image image, std::vector<std::byte> png, int width) {
	namespace streams = winrt::Windows::Storage::Streams;
	if (png.empty()) {
		co_return;
	}
	streams::InMemoryRandomAccessStream stream;
	streams::DataWriter                 writer(stream);
	const auto*                         bytes = reinterpret_cast<const uint8_t*>(png.data());
	writer.WriteBytes(winrt::array_view<const uint8_t>(bytes, bytes + png.size()));
	co_await writer.StoreAsync();
	writer.DetachStream();
	stream.Seek(0);
	xaml::Media::Imaging::BitmapImage bitmap;
	bitmap.DecodePixelWidth(width);
	try {
		co_await bitmap.SetSourceAsync(stream);
	} catch (const winrt::hresult_error&) {
		co_return; // not a readable PNG
	}
	image.Source(bitmap);
}

// The home screen's colour of a cover until its image loads.
xaml::Media::Brush TileBrush() {
	return xaml::Media::SolidColorBrush(winrt::Windows::UI::ColorHelper::FromArgb(0xFF, 0x1C, 0x23, 0x30));
}

// A game's cover as the home screen shows it: in a rounded tile.
xaml::Controls::Border CoverTile(double size) {
	xaml::Controls::Border tile;
	tile.Width(size);
	tile.Height(size);
	tile.CornerRadius({4, 4, 4, 4});
	tile.Background(TileBrush());
	tile.VerticalAlignment(xaml::VerticalAlignment::Center);
	return tile;
}

winrt::fire_and_forget ShowCover(xaml::Controls::Border tile, std::filesystem::path game, int width) {
	auto bitmap = co_await LoadImageAsync(tile.Dispatcher(), CoverImage(game), width);
	if (bitmap != nullptr) {
		xaml::Media::ImageBrush brush;
		brush.ImageSource(bitmap);
		brush.Stretch(xaml::Media::Stretch::UniformToFill);
		tile.Background(brush);
	}
}

// A column of a list row: a fixed width in pixels, the rest (star) or as wide as its content (auto).
xaml::Controls::ColumnDefinition Column(xaml::GridLength width) {
	xaml::Controls::ColumnDefinition column;
	column.Width(width);
	return column;
}

struct Page {
	std::function<void()>        back;
	bool                         left = false;
	xaml::Controls::Grid         root {nullptr};
	xaml::Controls::Border       header_cover {nullptr};
	xaml::Controls::TextBlock    header_title {nullptr};
	xaml::Controls::TextBlock    header_summary {nullptr};
	xaml::Controls::StackPanel   header_grades {nullptr};
	xaml::Controls::StackPanel   status {nullptr};
	xaml::Controls::ProgressRing loading {nullptr};
	xaml::Controls::TextBlock    status_text {nullptr};
	xaml::Controls::ListView     games_list {nullptr};
	xaml::Controls::ListView     trophy_list {nullptr};
	xaml::Controls::TextBlock    select_hint {nullptr};
	std::vector<GameTrophies>    games;
	size_t                       open_game = 0;
	Trophies::Progress           all; // of all games
	// A trophy notification's link: the game's title ID and the trophy's name. `linked` while only that game is shown.
	std::string                  link_title;
	std::string                  link_trophy;
	bool                         linked = false;
	// The Unloaded handler holds the page while it is shown and lets it go then.
	winrt::event_token          unloaded;

	void ShowOverview();
	void ShowOverviewHeader();
	void ShowGame(size_t index);
	void FocusGame(size_t index) const;
	void FocusTrophy(size_t package, int id) const;
	void Back();
};

void Page::ShowOverviewHeader() {
	header_cover.Visibility(xaml::Visibility::Collapsed);
	header_title.Text(L"Трофеи");
	header_summary.Text(std::to_wstring(all.earned) + L" из " + std::to_wstring(all.total) + L" получен  ·  " + std::to_wstring(games.size()) +
	                    (games.size() == 1 ? L" игра" : L" игр"));
	FillGrades(header_grades, all);
	select_hint.Text(L"Открыть");
}

void Page::ShowOverview() {
	status.Visibility(xaml::Visibility::Collapsed);
	if (games.empty()) {
		loading.IsActive(false);
		loading.Visibility(xaml::Visibility::Collapsed);
		status_text.Text(L"В папках с играми нет игр с трофеями.");
		status.Visibility(xaml::Visibility::Visible);
		return;
	}
	for (const auto& entry: games) {
		for (size_t grade = 0; grade < all.total_grade.size(); grade++) {
			all.total_grade[grade] += entry.progress.total_grade[grade];
			all.earned_grade[grade] += entry.progress.earned_grade[grade];
		}
		all.total += entry.progress.total;
		all.earned += entry.progress.earned;
	}
	ShowOverviewHeader();

	// A row per game: cover, name, progress, and the grade counts in the header's columns.
	games_list.Items().Clear();
	for (size_t i = 0; i < games.size(); i++) {
		const auto& entry = games[i];
		xaml::Controls::Grid row;
		row.Padding({0, 10, 0, 10});
		row.ColumnSpacing(16);
		row.ColumnDefinitions().Append(Column(xaml::GridLengthHelper::FromPixels(COVER_SIZE)));
		row.ColumnDefinitions().Append(Column(xaml::GridLengthHelper::FromValueAndType(1, xaml::GridUnitType::Star)));
		row.ColumnDefinitions().Append(Column(xaml::GridLengthHelper::Auto()));
		auto cover = CoverTile(COVER_SIZE);
		ShowCover(cover, entry.game.folder, 112);
		row.Children().Append(cover);

		xaml::Controls::StackPanel text;
		text.Spacing(4);
		text.VerticalAlignment(xaml::VerticalAlignment::Center);
		auto name = Text(std::wstring(winrt::to_hstring(entry.game.name)));
		name.FontWeight(winrt::Windows::UI::Text::FontWeights::SemiBold());
		name.TextTrimming(xaml::TextTrimming::CharacterEllipsis);
		name.TextWrapping(xaml::TextWrapping::NoWrap);
		text.Children().Append(name);
		auto summary = Text(Summary(entry.progress));
		summary.Foreground(MediumBrush());
		text.Children().Append(summary);
		xaml::Controls::ProgressBar bar;
		bar.Maximum(100);
		bar.Value(entry.progress.Percentage());
		bar.Width(240);
		bar.HorizontalAlignment(xaml::HorizontalAlignment::Left);
		bar.Margin({0, 2, 0, 0});
		text.Children().Append(bar);
		xaml::Controls::Grid::SetColumn(text, 1);
		row.Children().Append(text);

		xaml::Controls::StackPanel grades;
		grades.Orientation(xaml::Controls::Orientation::Horizontal);
		grades.Spacing(16);
		grades.VerticalAlignment(xaml::VerticalAlignment::Center);
		FillGrades(grades, entry.progress);
		xaml::Controls::Grid::SetColumn(grades, 2);
		row.Children().Append(grades);

		row.Tag(winrt::box_value(static_cast<uint32_t>(i)));
		games_list.Items().Append(row);
	}
	games_list.Visibility(xaml::Visibility::Visible);
	FocusGame(0);
}

void Page::FocusGame(size_t index) const {
	// After the list has made its items.
	games_list.UpdateLayout();
	if (auto item = games_list.ContainerFromIndex(static_cast<int32_t>(index)).try_as<xaml::Controls::Control>()) {
		item.Focus(xaml::FocusState::Keyboard);
	} else {
		games_list.Focus(xaml::FocusState::Keyboard);
	}
}

// The details of a trophy (A on it); a hidden one that is not earned is masked until "Show hidden trophy". `closed` runs when they close.
winrt::fire_and_forget ShowDetails(Trophies::Trophy trophy, bool earned, std::wstring earned_text, std::function<void()> closed = {}) {
	xaml::Controls::ContentDialog dialog;
	auto                          content = std::make_shared<xaml::Controls::StackPanel>();
	content->Spacing(16);
	const auto fill = [content, trophy, earned, earned_text](bool masked) {
		content->Children().Clear();
		xaml::Controls::Grid header;
		header.ColumnSpacing(20);
		xaml::Controls::ColumnDefinition icon_column;
		icon_column.Width(xaml::GridLengthHelper::FromPixels(128));
		header.ColumnDefinitions().Append(icon_column);
		header.ColumnDefinitions().Append(xaml::Controls::ColumnDefinition {});
		xaml::Controls::Image icon;
		icon.Width(128);
		icon.Height(128);
		icon.Opacity(earned ? 1.0 : 0.4);
		if (!masked) {
			ShowPng(icon, trophy.icon_png, 256);
			header.Children().Append(icon);
		} else {
			auto cup = Cup(0, 96);
			cup.Opacity(0.5);
			header.Children().Append(cup);
		}
		xaml::Controls::StackPanel title;
		title.Spacing(6);
		title.VerticalAlignment(xaml::VerticalAlignment::Center);
		auto name = Text(TrophyName(trophy, masked), L"SubtitleTextBlockStyle");
		name.TextWrapping(xaml::TextWrapping::Wrap);
		title.Children().Append(name);
		if (!masked) {
			xaml::Controls::StackPanel grade;
			grade.Orientation(xaml::Controls::Orientation::Horizontal);
			grade.Spacing(6);
			grade.Children().Append(Cup(trophy.grade, CUP_SIZE));
			grade.Children().Append(Text(GradeName(trophy.grade)));
			title.Children().Append(grade);
		}
		auto status = Text(earned ? earned_text : std::wstring(L"Не получен"));
		status.Foreground(MediumBrush());
		title.Children().Append(status);
		xaml::Controls::Grid::SetColumn(title, 1);
		header.Children().Append(title);
		content->Children().Append(header);
		if (masked) {
			auto note = Text(L"Этот трофей скрыт, пока не будет получен.");
			note.Foreground(MediumBrush());
			content->Children().Append(note);
			return;
		}
		if (!trophy.description.empty()) {
			auto details = Text(std::wstring(winrt::to_hstring(trophy.description)));
			details.TextWrapping(xaml::TextWrapping::Wrap);
			content->Children().Append(details);
		}
		if (trophy.has_reward && !trophy.reward.empty()) {
			auto reward = Text(L"Награда: " + std::wstring(winrt::to_hstring(trophy.reward)));
			reward.TextWrapping(xaml::TextWrapping::Wrap);
			reward.Foreground(MediumBrush());
			content->Children().Append(reward);
		}
	};
	const bool masked = trophy.hidden && !earned;
	fill(masked);
	dialog.Content(*content);
	dialog.CloseButtonText(L"Закрыть");
	if (masked) {
		dialog.PrimaryButtonText(L"Показать скрытый трофей");
		dialog.PrimaryButtonClick([fill, weak = winrt::make_weak(dialog)](auto const&, xaml::Controls::ContentDialogButtonClickEventArgs const& args) {
			args.Cancel(true); // stays open, now unmasked
			fill(false);
			if (auto shown = weak.get()) {
				shown.PrimaryButtonText(L"");
			}
		});
	}
	// Only one dialog shows at a time: another one open (details already shown) makes this one fail.
	try {
		co_await dialog.ShowAsync();
	} catch (const winrt::hresult_error& error) {
		Log("trophy details: %ls\n", error.message().c_str());
	}
	if (closed) {
		closed();
	}
}

// The details of the trophy `id` of the game's package `package`.
void ShowTrophyOf(const GameTrophies& entry, size_t package, int id, std::function<void()> closed = {}) {
	const auto& unlocks = entry.packages[package].unlocks;
	const bool  earned  = unlocks.unlocked.contains(id);
	ShowDetails(entry.packages[package].package.trophies.at(id), earned, earned ? EarnedText(unlocks, id) : std::wstring(), std::move(closed));
}

// A trophy's row in the game menu's side panel: its icon, its name, and under it its grade and when it was earned.
xaml::Controls::Grid MenuTrophyRow(const Trophies::Trophy& trophy, const Trophies::UnlockData& unlocks) {
	const bool earned = unlocks.unlocked.contains(trophy.id);
	const bool masked = trophy.hidden && !earned;
	xaml::Controls::Grid row;
	row.Padding({0, 8, 0, 8});
	row.ColumnSpacing(12);
	row.ColumnDefinitions().Append(Column(xaml::GridLengthHelper::FromPixels(MENU_ICON_SIZE)));
	row.ColumnDefinitions().Append(Column(xaml::GridLengthHelper::FromValueAndType(1, xaml::GridUnitType::Star)));
	if (masked) {
		auto cup = Cup(0, 24);
		cup.Opacity(0.5);
		row.Children().Append(cup);
	} else {
		xaml::Controls::Image icon;
		icon.Width(MENU_ICON_SIZE);
		icon.Height(MENU_ICON_SIZE);
		icon.Opacity(earned ? 1.0 : 0.4);
		icon.VerticalAlignment(xaml::VerticalAlignment::Center);
		ShowPng(icon, trophy.icon_png, 80);
		row.Children().Append(icon);
	}
	xaml::Controls::StackPanel text;
	text.Spacing(2);
	text.VerticalAlignment(xaml::VerticalAlignment::Center);
	auto name = Text(TrophyName(trophy, masked));
	name.FontWeight(winrt::Windows::UI::Text::FontWeights::SemiBold());
	name.TextTrimming(xaml::TextTrimming::CharacterEllipsis);
	name.TextWrapping(xaml::TextWrapping::NoWrap);
	text.Children().Append(name);
	xaml::Controls::StackPanel line;
	line.Orientation(xaml::Controls::Orientation::Horizontal);
	line.Spacing(6);
	if (!masked) {
		line.Children().Append(Cup(trophy.grade, 12));
	}
	auto status = Text(earned ? EarnedText(unlocks, trophy.id) : std::wstring(L"Не получен"));
	status.Foreground(MediumBrush());
	status.TextTrimming(xaml::TextTrimming::CharacterEllipsis);
	line.Children().Append(status);
	text.Children().Append(line);
	xaml::Controls::Grid::SetColumn(text, 1);
	row.Children().Append(text);
	return row;
}

// The grade counts in one line, for the side panel: a cup and "earned/total" per grade that has trophies.
xaml::Controls::StackPanel MenuGrades(const Trophies::Progress& progress) {
	xaml::Controls::StackPanel grades;
	grades.Orientation(xaml::Controls::Orientation::Horizontal);
	grades.Spacing(14);
	for (int grade = 1; grade <= 4; grade++) {
		if (progress.total_grade[grade] == 0) {
			continue;
		}
		xaml::Controls::StackPanel cell;
		cell.Orientation(xaml::Controls::Orientation::Horizontal);
		cell.Spacing(4);
		cell.Children().Append(Cup(grade, 14));
		cell.Children().Append(Text(std::to_wstring(progress.earned_grade[grade]) + L"/" + std::to_wstring(progress.total_grade[grade])));
		grades.Children().Append(cell);
	}
	return grades;
}

// After the game menu found no trophies: each step of reading the first trophy package once more, for the log (background thread).
void LogTrophyReadSteps(const GameEntry& game, int language) {
	const auto inner = Trophies::PackagePath(0);
	if (IsArchivePath(game.folder)) {
		WIN32_FILE_ATTRIBUTE_DATA attributes {};
		const bool                read  = GetFileAttributesExFromAppW(game.folder.c_str(), GetFileExInfoStandard, &attributes) != 0;
		const auto                error = read ? 0ul : GetLastError();
		Log("trophies: %s: the archive's attributes %s (error %lu)\n", game.title_id.c_str(), read ? "read" : "not read", error);
	}
	Log("trophies: %s: %ls in the game: %s\n", game.title_id.c_str(), inner.c_str(), GameFileExists(game.folder / inner) ? "yes" : "no");
	const auto   path = IsArchivePath(game.folder) ? Common::MakeArchivePath(game.folder, inner) : game.folder / inner;
	Common::File file(path, Common::File::Mode::Read);
	const bool   opened = !file.IsInvalid();
	Log("trophies: %s: package opened: %s, %llu bytes; parsed now: %zu trophies\n", game.title_id.c_str(), opened ? "yes" : "no",
	    static_cast<unsigned long long>(opened ? file.Size() : 0), Trophies::LoadPackage(path, language).trophies.size());
}

// Focuses the first item of `list` that can take the focus (a trophy, not a package's heading).
void FocusFirstItem(xaml::Controls::ListView const& list) {
	list.UpdateLayout();
	for (uint32_t index = 0; index < list.Items().Size(); index++) {
		if (auto item = list.ContainerFromIndex(static_cast<int32_t>(index)).try_as<xaml::Controls::Control>(); item != nullptr && item.IsEnabled()) {
			item.Focus(xaml::FocusState::Keyboard);
			return;
		}
	}
}

void Page::ShowGame(size_t index) {
	open_game        = index;
	const auto& entry = games[index];
	header_cover.Background(TileBrush());
	header_cover.Visibility(xaml::Visibility::Visible);
	ShowCover(header_cover, entry.game.folder, 96);
	header_title.Text(winrt::to_hstring(entry.game.name));
	header_summary.Text(Summary(entry.progress));
	FillGrades(header_grades, entry.progress);
	select_hint.Text(L"Подробности");

	// A row per trophy: icon, name and description, then its grade and whether it is earned in columns of their own.
	trophy_list.Items().Clear();
	for (size_t p = 0; p < entry.packages.size(); p++) {
		const auto& package = entry.packages[p];
		if (entry.packages.size() > 1) {
			// Several packages (service labels): a heading for each.
			auto heading = Text(package.package.title.empty() ? L"Пакет трофеев " + std::to_wstring(package.label)
			                                                  : std::wstring(winrt::to_hstring(package.package.title)));
			heading.FontWeight(winrt::Windows::UI::Text::FontWeights::SemiBold());
			heading.Foreground(MediumBrush());
			heading.Margin({0, p == 0 ? 0.0 : 16.0, 0, 4});
			xaml::Controls::ListViewItem item;
			item.Content(heading);
			item.IsEnabled(false);
			trophy_list.Items().Append(item);
		}
		for (const auto& [id, trophy]: package.package.trophies) {
			const bool earned = package.unlocks.unlocked.contains(id);
			const bool masked = trophy.hidden && !earned;
			xaml::Controls::Grid row;
			row.Padding({0, 10, 0, 10});
			row.ColumnSpacing(16);
			row.ColumnDefinitions().Append(Column(xaml::GridLengthHelper::FromPixels(ICON_SIZE)));
			row.ColumnDefinitions().Append(Column(xaml::GridLengthHelper::FromValueAndType(1, xaml::GridUnitType::Star)));
			row.ColumnDefinitions().Append(Column(xaml::GridLengthHelper::FromPixels(112)));
			row.ColumnDefinitions().Append(Column(xaml::GridLengthHelper::FromPixels(176)));

			if (masked) {
				auto cup = Cup(0, 32);
				cup.Opacity(0.5);
				row.Children().Append(cup);
			} else {
				xaml::Controls::Image icon;
				icon.Width(ICON_SIZE);
				icon.Height(ICON_SIZE);
				icon.Opacity(earned ? 1.0 : 0.4); // locked trophies dimmed (the launcher greys them)
				icon.VerticalAlignment(xaml::VerticalAlignment::Center);
				ShowPng(icon, trophy.icon_png, 112);
				row.Children().Append(icon);
			}

			xaml::Controls::StackPanel text;
			text.Spacing(4);
			text.VerticalAlignment(xaml::VerticalAlignment::Center);
			auto name = Text(TrophyName(trophy, masked));
			name.FontWeight(winrt::Windows::UI::Text::FontWeights::SemiBold());
			name.TextTrimming(xaml::TextTrimming::CharacterEllipsis);
			name.TextWrapping(xaml::TextWrapping::NoWrap);
			text.Children().Append(name);
			const auto description = masked ? std::wstring(L"Скрыт, пока не будет получен.") : std::wstring(winrt::to_hstring(trophy.description));
			if (!description.empty()) {
				auto line = Text(description);
				line.TextWrapping(xaml::TextWrapping::Wrap);
				line.TextTrimming(xaml::TextTrimming::CharacterEllipsis);
				line.MaxLines(2);
				line.Foreground(MediumBrush());
				text.Children().Append(line);
			}
			xaml::Controls::Grid::SetColumn(text, 1);
			row.Children().Append(text);

			if (!masked) {
				xaml::Controls::StackPanel grade;
				grade.Orientation(xaml::Controls::Orientation::Horizontal);
				grade.Spacing(6);
				grade.VerticalAlignment(xaml::VerticalAlignment::Center);
				grade.Children().Append(Cup(trophy.grade, CUP_SIZE));
				grade.Children().Append(Text(GradeName(trophy.grade)));
				xaml::Controls::Grid::SetColumn(grade, 2);
				row.Children().Append(grade);
			}

			auto status = Text(earned ? EarnedText(package.unlocks, id) : std::wstring(L"Не получен"));
			status.Foreground(MediumBrush());
			status.TextAlignment(xaml::TextAlignment::Right);
			status.VerticalAlignment(xaml::VerticalAlignment::Center);
			xaml::Controls::Grid::SetColumn(status, 3);
			row.Children().Append(status);

			// Which trophy: the package and the trophy id.
			row.Tag(winrt::box_value((static_cast<uint32_t>(p) << 16u) | static_cast<uint32_t>(id)));
			trophy_list.Items().Append(row);
		}
	}

	games_list.Visibility(xaml::Visibility::Collapsed);
	trophy_list.Visibility(xaml::Visibility::Visible);
	trophy_list.UpdateLayout();
	trophy_list.Focus(xaml::FocusState::Keyboard);
}

// The trophy's row in the open game's list, scrolled to with the focus.
void Page::FocusTrophy(size_t package, int id) const {
	const uint32_t tag = (static_cast<uint32_t>(package) << 16u) | static_cast<uint32_t>(id);
	for (uint32_t index = 0; index < trophy_list.Items().Size(); index++) {
		const auto row = trophy_list.Items().GetAt(index).try_as<xaml::FrameworkElement>();
		if (row == nullptr || row.Tag() == nullptr || winrt::unbox_value<uint32_t>(row.Tag()) != tag) {
			continue;
		}
		trophy_list.ScrollIntoView(row);
		trophy_list.UpdateLayout();
		if (auto item = trophy_list.ContainerFromIndex(static_cast<int32_t>(index)).try_as<xaml::Controls::Control>()) {
			item.Focus(xaml::FocusState::Keyboard);
		}
		return;
	}
}

void Page::Back() {
	// A link shows only its game: from its list straight back.
	if (trophy_list.Visibility() == xaml::Visibility::Visible && !linked) {
		trophy_list.Visibility(xaml::Visibility::Collapsed);
		trophy_list.Items().Clear();
		games_list.Visibility(xaml::Visibility::Visible);
		ShowOverviewHeader();
		FocusGame(open_game);
		return;
	}
	if (!left) {
		left = true;
		back();
	}
}


winrt::fire_and_forget LoadTrophies(std::shared_ptr<Page> page) {
	const auto dispatcher = page->root.Dispatcher();
	const int  language   = static_cast<int>(LoadSettings().console_language);
	co_await winrt::resume_background();
	// A link reads only its game: its list with the trophy's details open. Without that game, the whole page.
	if (!page->link_title.empty()) {
		auto entry = LoadTitleTrophies(page->link_title, language);
		co_await winrt::resume_foreground(dispatcher);
		if (page->left) {
			co_return;
		}
		if (entry) {
			page->linked = true;
			page->games.push_back(std::move(*entry));
			page->status.Visibility(xaml::Visibility::Collapsed);
			page->ShowGame(0);
			if (const auto found = FindTrophy(page->games[0], page->link_trophy)) {
				page->FocusTrophy(found->first, found->second);
				ShowTrophyOf(page->games[0], found->first, found->second);
			}
			co_return;
		}
		Log("trophy link: no trophies for %s in the library\n", page->link_title.c_str());
		co_await winrt::resume_background();
	}
	auto games = LoadAllTrophies(language);
	co_await winrt::resume_foreground(dispatcher);
	if (page->left) {
		co_return;
	}
	page->games = std::move(games);
	page->ShowOverview();
}

} // namespace

void ShowTrophyDetails(std::string title_id, std::string trophy_name, std::function<void()> closed) {
	[](std::string title_id, std::string trophy_name, std::function<void()> closed) -> winrt::fire_and_forget {
		const auto dispatcher = xaml::Window::Current().Dispatcher();
		const int  language   = static_cast<int>(LoadSettings().console_language);
		co_await winrt::resume_background();
		auto entry = LoadTitleTrophies(title_id, language);
		co_await winrt::resume_foreground(dispatcher);
		const auto found = entry ? FindTrophy(*entry, trophy_name) : std::nullopt;
		if (!found) {
			Log("trophy details: no trophy \"%s\" for %s\n", trophy_name.c_str(), title_id.c_str());
			if (closed) {
				closed();
			}
			co_return;
		}
		ShowTrophyOf(*entry, found->first, found->second, std::move(closed));
	}(std::move(title_id), std::move(trophy_name), std::move(closed));
}

void ShowGameTrophies(xaml::Controls::Grid const& host, GameEntry game, xaml::Controls::StackPanel text) {
	host.Children().Clear();
	host.RowDefinitions().Clear();
	host.RowSpacing(12);
	xaml::Controls::RowDefinition header_row;
	header_row.Height(xaml::GridLengthHelper::Auto());
	host.RowDefinitions().Append(header_row);
	host.RowDefinitions().Append(xaml::Controls::RowDefinition {});
	xaml::Controls::StackPanel header;
	header.Spacing(8);
	host.Children().Append(header);
	// The menu's own list has the same margin: the rows' content lines up with the panel's.
	xaml::Controls::ListView list;
	list.SelectionMode(xaml::Controls::ListViewSelectionMode::None);
	list.IsItemClickEnabled(true);
	list.Margin({-12, 0, -12, 0});
	xaml::Controls::Grid::SetRow(list, 1);
	host.Children().Append(list);

	// While they are read, and when there are none: a line that says so, with the focus.
	const auto status = [list](const wchar_t* text) {
		list.Items().Clear();
		auto line = Text(text);
		line.TextWrapping(xaml::TextWrapping::Wrap);
		line.Foreground(MediumBrush());
		xaml::Controls::ListViewItem item;
		item.Content(line);
		list.Items().Append(item);
		FocusFirstItem(list);
	};
	status(L"Чтение трофеев игры...");

	[](xaml::Controls::Grid host, xaml::Controls::StackPanel header, xaml::Controls::ListView list, GameEntry game,
	   std::function<void(const wchar_t*)> status, xaml::Controls::StackPanel text) -> winrt::fire_and_forget {
		const auto dispatcher = host.Dispatcher();
		const int  language   = static_cast<int>(LoadSettings().console_language);
		co_await winrt::resume_background();
		const auto started = std::chrono::steady_clock::now();
		auto       loaded  = LoadGameTrophies(game, language, UserDataFolder(LoadSettings()));
		// Once it found none and the next try found them: what failed, for the log.
		if (!loaded) {
			const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - started).count();
			Log("trophies: the game menu found none for %s (read in %lld ms)\n", game.title_id.c_str(), static_cast<long long>(ms));
			LogTrophyReadSteps(game, language);
		}
		co_await winrt::resume_foreground(dispatcher);
		// The menu went on to something else meanwhile.
		uint32_t index = 0;
		if (host.Visibility() != xaml::Visibility::Visible || !host.Children().IndexOf(list, index)) {
			co_return;
		}
		if (!loaded) {
			status(L"У этой игры нет трофеев.");
			co_return;
		}
		const auto entry = std::make_shared<GameTrophies>(std::move(*loaded));
		header.Children().Append(Text(Summary(entry->progress)));
		header.Children().Append(MenuGrades(entry->progress));

		list.Items().Clear();
		for (size_t p = 0; p < entry->packages.size(); p++) {
			const auto& package = entry->packages[p];
			if (entry->packages.size() > 1) {
				auto heading = Text(package.package.title.empty() ? L"Пакет трофеев " + std::to_wstring(package.label)
				                                                  : std::wstring(winrt::to_hstring(package.package.title)));
				heading.FontWeight(winrt::Windows::UI::Text::FontWeights::SemiBold());
				heading.Foreground(MediumBrush());
				heading.Margin({0, p == 0 ? 0.0 : 12.0, 0, 0});
				xaml::Controls::ListViewItem item;
				item.Content(heading);
				item.IsEnabled(false);
				list.Items().Append(item);
			}
			for (const auto& [id, trophy]: package.package.trophies) {
				auto row = MenuTrophyRow(trophy, package.unlocks);
				// Which trophy: the package and the trophy id.
				row.Tag(winrt::box_value((static_cast<uint32_t>(p) << 16u) | static_cast<uint32_t>(id)));
				list.Items().Append(row);
			}
		}
		// The trophy with the focus: its name, grade and when it was earned, and what to do for it (a hidden one keeps that to itself).
		list.GotFocus([entry, text](auto const&, xaml::RoutedEventArgs const& args) {
			const auto item = args.OriginalSource().try_as<xaml::Controls::ListViewItem>();
			const auto row  = item != nullptr ? item.Content().try_as<xaml::FrameworkElement>() : nullptr;
			if (row == nullptr || row.Tag() == nullptr) {
				return;
			}
			const uint32_t tag   = winrt::unbox_value<uint32_t>(row.Tag());
			const auto&    found = entry->packages[tag >> 16u];
			const auto     at    = found.package.trophies.find(static_cast<int>(tag & 0xffffu));
			if (at == found.package.trophies.end()) {
				return;
			}
			const auto&        trophy = at->second;
			const bool         earned = found.unlocks.unlocked.contains(trophy.id);
			const bool         masked = trophy.hidden && !earned;
			const std::wstring state  = earned ? EarnedText(found.unlocks, trophy.id) : std::wstring(L"Не получен");
			ShowExplanation(text, TrophyName(trophy, masked), {masked ? state : std::wstring(GradeName(trophy.grade)) + L" · " + state},
			                {masked ? std::wstring(L"Этот трофей скрыт, пока вы его не получите.") : std::wstring(winrt::to_hstring(trophy.description))});
		});
		list.ItemClick([entry](auto const&, xaml::Controls::ItemClickEventArgs const& args) {
			const auto row = args.ClickedItem().try_as<xaml::FrameworkElement>();
			if (row == nullptr || row.Tag() == nullptr) {
				return;
			}
			const uint32_t tag = winrt::unbox_value<uint32_t>(row.Tag());
			ShowTrophyOf(*entry, tag >> 16u, static_cast<int>(tag & 0xffffu));
		});
		FocusFirstItem(list);
	}(host, header, list, std::move(game), status, std::move(text));
}

size_t ResetAllTrophies() {
	const auto root  = UserDataFolder(LoadSettings()) / L"_Trophies";
	size_t     games = 0;
	for (const auto& folder: Subfolders(root)) {
		size_t           removed = 0;
		WIN32_FIND_DATAW data {};
		HANDLE find = FindFirstFileExFromAppW((folder / L"trophies_*.json").c_str(), FindExInfoBasic, &data, FindExSearchNameMatch, nullptr, 0);
		if (find != INVALID_HANDLE_VALUE) {
			do {
				if ((data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0 && DeleteFileFromAppW((folder / data.cFileName).c_str()) != 0) {
					removed++;
				}
			} while (FindNextFileW(find, &data));
			FindClose(find);
		}
		// The game's folder too, when nothing else is left in it.
		RemoveDirectoryFromAppW(folder.c_str());
		if (removed != 0) {
			games++;
		}
	}
	Log("trophies: reset, the unlocks of %zu games removed from %ls\n", games, root.c_str());
	return games;
}

xaml::UIElement CreateTrophiesPage(std::function<void()> back, std::string title_id, std::string trophy_name) {
	auto page  = std::make_shared<Page>();
	page->back = std::move(back);
	page->link_title  = std::move(title_id);
	page->link_trophy = std::move(trophy_name);
	page->root = xaml::Markup::XamlReader::Load(PageMarkup).as<xaml::Controls::Grid>();
	const auto find   = [&page](const wchar_t* name) { return page->root.FindName(name); };
	page->header_cover   = find(L"HeaderCover").as<xaml::Controls::Border>();
	page->header_title   = find(L"HeaderTitle").as<xaml::Controls::TextBlock>();
	page->header_summary = find(L"HeaderSummary").as<xaml::Controls::TextBlock>();
	page->header_grades  = find(L"HeaderGrades").as<xaml::Controls::StackPanel>();
	page->status         = find(L"Status").as<xaml::Controls::StackPanel>();
	page->loading        = find(L"Loading").as<xaml::Controls::ProgressRing>();
	page->status_text    = find(L"StatusText").as<xaml::Controls::TextBlock>();
	page->games_list     = find(L"Games").as<xaml::Controls::ListView>();
	page->trophy_list    = find(L"TrophyList").as<xaml::Controls::ListView>();
	page->select_hint    = SetHints(find(L"Hints").as<xaml::Controls::Border>(), {{XboxButton::A, L"Открыть"}, {XboxButton::B, L"Назад"}}).front();

	page->games_list.ItemClick([weak = std::weak_ptr<Page>(page)](auto const&, xaml::Controls::ItemClickEventArgs const& args) {
		if (auto shared = weak.lock()) {
			const auto row = args.ClickedItem().try_as<xaml::FrameworkElement>();
			if (row != nullptr && row.Tag() != nullptr) {
				shared->ShowGame(winrt::unbox_value<uint32_t>(row.Tag()));
			}
		}
	});
	page->trophy_list.ItemClick([weak = std::weak_ptr<Page>(page)](auto const&, xaml::Controls::ItemClickEventArgs const& args) {
		auto shared = weak.lock();
		const auto card = args.ClickedItem().try_as<xaml::FrameworkElement>();
		if (shared == nullptr || card == nullptr || card.Tag() == nullptr) {
			return;
		}
		const uint32_t tag     = winrt::unbox_value<uint32_t>(card.Tag());
		const auto&    package = shared->games[shared->open_game].packages[tag >> 16u];
		const int      id      = static_cast<int>(tag & 0xffffu);
		const auto     trophy  = package.package.trophies.find(id);
		if (trophy == package.package.trophies.end()) {
			return;
		}
		const bool earned = package.unlocks.unlocked.contains(id);
		ShowDetails(trophy->second, earned, earned ? EarnedText(package.unlocks, id) : std::wstring());
	});

	// Back: B, Escape or the window's back button (shown while the page is open).
	page->root.KeyDown([weak = std::weak_ptr<Page>(page)](auto const&, xaml::Input::KeyRoutedEventArgs const& args) {
		if (args.Key() == winrt::Windows::System::VirtualKey::GamepadB || args.Key() == winrt::Windows::System::VirtualKey::Escape) {
			args.Handled(true);
			if (auto shared = weak.lock()) {
				shared->Back();
			}
		}
	});
	auto navigation = winrt::Windows::UI::Core::SystemNavigationManager::GetForCurrentView();
	navigation.AppViewBackButtonVisibility(winrt::Windows::UI::Core::AppViewBackButtonVisibility::Visible);
	auto back_token = navigation.BackRequested(
	    [weak = std::weak_ptr<Page>(page)](auto const&, winrt::Windows::UI::Core::BackRequestedEventArgs const& args) {
		    args.Handled(true);
		    if (auto shared = weak.lock()) {
			    shared->Back();
		    }
	    });
	// The page's state lives while the page is shown: this handler holds it and removes itself when the page goes.
	page->unloaded = page->root.Unloaded([page, navigation, back_token](auto const&, auto const&) {
		navigation.BackRequested(back_token);
		navigation.AppViewBackButtonVisibility(winrt::Windows::UI::Core::AppViewBackButtonVisibility::Collapsed);
		page->left = true;
		page->root.Unloaded(page->unloaded);
	});
	LoadTrophies(page);
	return page->root;
}

} // namespace Kyty::Uwp
