#include "gameGraphics.h"

#include "common/emulatorConfig.h"
#include "fileAccess.h"
#include "settingTiles.h"

#include <algorithm>
#include <array>
#include <string>
#include <vector>

namespace Kyty::Uwp {

namespace {

// The settings page's sizes for "Textures count as big from", and the draw counts the game menu offers.
constexpr std::array<uint32_t, 5> TEXTURE_SIZES = {256, 512, 1024, 2048, 4096};
constexpr std::array<uint32_t, 6> DRAW_COUNTS   = {0, 25, 50, 100, 250, 500};
// A texture keeps the size it was made with: a change reaches the textures the game loads afterwards.
constexpr wchar_t TEXTURES_LATER[] = L"Применяется к текстурам, загружаемым с этого момента, например после загрузки следующего уровня.";

void ApplyTextureSizes(const AppSettings& settings) {
	Config::SetTextureMipSkip(settings.texture_mip_skip, settings.texture_mip_skip_min_size, settings.texture_mip_skip_uncompressed);
}

void ApplyTextureFiltering(const AppSettings& settings) {
	Config::SetTextureFiltering(settings.texture_lod_bias, settings.anisotropic_filtering);
}

} // namespace

void AddGameGraphicsSettings(winrt::Windows::UI::Xaml::Controls::Panel const& tiles, winrt::Windows::UI::Xaml::Controls::StackPanel const& explanation,
                             std::shared_ptr<AppSettings> settings, std::function<void(bool)> output_changed) {
	const auto save = [settings] { SaveSettings(*settings); };

	AddHeading(tiles, L"Изображение");
	{
		const std::vector<std::string> values {"Off", "Low", "Medium", "High"};
		const auto                     found = std::find(values.begin(), values.end(), settings->fsr1_upscaling);
		AddChoice(
		    tiles, explanation, L"FSR 1", {L"Выкл.", L"Резкость: низкая", L"Резкость: средняя", L"Резкость: высокая"},
		    found != values.end() ? static_cast<size_t>(found - values.begin()) : 0,
		    [settings, save, values](size_t index) {
			    const size_t mode        = index < values.size() ? index : 0;
			    settings->fsr1_upscaling = values[mode];
			    Config::SetFsr1Upscaling(static_cast<uint32_t>(mode));
			    save();
		    },
		    {L"Повышает резкость и масштабирует игры, которые рендерятся в разрешении ниже выходного. Функция экспериментальная и не работает с HDR."});
	}
	if (IsXbox()) {
		AddChoice(
		    tiles, explanation, L"Выходное разрешение", {L"Как у ТВ", L"1080p"}, settings->output_resolution == "1080p" ? 1 : 0,
		    [settings, save, output_changed](size_t index) {
			    settings->output_resolution = index == 1 ? "1080p" : "Match TV";
			    save();
			    if (output_changed) {
				    output_changed(index != 1);
			    }
		    },
		    {L"«Как у ТВ» сохраняет чёткость 4K-игр на 4K-телевизоре. 1080p расходует меньше памяти, а консоль сама масштабирует картинку под ваш ТВ."});
	}
	// V-Sync is the PC's (see the settings page).
	if (!IsXbox()) {
		AddSwitch(
		    tiles, explanation, L"V-Sync", settings->vsync,
		    [settings, save](bool on) {
			    settings->vsync = on;
			    Config::SetPresentMode(on ? Config::PresentMode::Fifo : Config::PresentMode::Mailbox);
			    save();
		    },
		    {L"Синхронизирует каждый кадр с частотой обновления экрана для плавного движения ценой чуть большей задержки ввода.",
		     L"Когда выключено, кадры показываются сразу, как только готовы, с меньшей задержкой."});
	}

	AddHeading(tiles, L"Частота кадров");
#ifdef KYTY_HAS_FSR
	if (Config::FsrFrameGenerationAvailable()) {
		AddSwitch(
		    tiles, explanation, L"Генерация кадров FSR", Config::FsrFrameGenerationEnabled(),
		    [settings, save](bool on) {
			    settings->fsr_frame_generation = on;
			    Config::SetFsrFrameGeneration(on);
			    save();
		    },
		    {L"Добавляет сгенерированный кадр между кадрами игры для более плавного движения. Работает только с играми PS5 Pro, которые используют PSSR и идут на половине частоты обновления экрана, например 30 кадр/с при 60 Гц. Функция экспериментальная."});
	} else {
		// Its resources are made when a game starts: during a game it can only be turned off.
		AddAction(tiles, explanation, L"Генерация кадров FSR", L"Выкл.", [] {},
		          {L"Добавляет сгенерированный кадр между кадрами игры для более плавного движения.",
		           L"Чтобы использовать, включите её в разделе Настройки \u203A Экран до запуска игры. Во время игры её можно только выключить."});
	}
#endif
	{
		std::vector<uint32_t> counts(DRAW_COUNTS.begin(), DRAW_COUNTS.end());
		if (std::find(counts.begin(), counts.end(), settings->flush_draws) == counts.end()) {
			counts.push_back(settings->flush_draws);
		}
		std::vector<std::wstring> names;
		size_t                    selected = 0;
		for (size_t index = 0; index < counts.size(); index++) {
			names.push_back(counts[index] == 0 ? std::wstring(L"Выкл.") : std::to_wstring(counts[index]) + L" отрисовок");
			if (counts[index] == settings->flush_draws) {
				selected = index;
			}
		}
		AddChoice(
		    tiles, explanation, L"Отрисовок на одну отправку в GPU", std::move(names), selected,
		    [settings, save, counts](size_t index) {
			    settings->flush_draws = counts[index];
			    Config::SetFlushDraws(counts[index]);
			    save();
		    },
		    {L"Отправляет записанную работу после такого числа отрисовок, чтобы GPU мог начать до конца длинного буфера команд.",
		     L"Лишние отправки тратят время процессора. «Выкл.» — обычная пакетная отправка."});
	}

	AddHeading(tiles, L"Текстуры");
	AddChoice(
	    tiles, explanation, L"Детализация текстур", {L"Полная", L"Половинное разрешение", L"Четверть разрешения", L"Одна восьмая разрешения", L"Одна шестнадцатая разрешения"},
	    std::min<uint32_t>(settings->texture_mip_skip, 4),
	    [settings, save](size_t index) {
		    settings->texture_mip_skip = static_cast<uint32_t>(index);
		    ApplyTextureSizes(*settings);
		    save();
	    },
	    {L"Большие сжатые текстуры с мипмапами загружаются в пониженном разрешении, чтобы сэкономить память GPU.", TEXTURES_LATER});
	{
		std::vector<std::wstring> names;
		size_t                    selected = 3;
		for (size_t index = 0; index < TEXTURE_SIZES.size(); index++) {
			names.push_back(std::to_wstring(TEXTURE_SIZES[index]) + L" пикс.");
			if (TEXTURE_SIZES[index] == settings->texture_mip_skip_min_size) {
				selected = index;
			}
		}
		AddChoice(
		    tiles, explanation, L"Текстуры считаются большими от", std::move(names), selected,
		    [settings, save](size_t index) {
			    settings->texture_mip_skip_min_size = TEXTURE_SIZES[index];
			    ApplyTextureSizes(*settings);
			    save();
		    },
		    {L"Разрешение снижается только у текстур не меньше этого размера. Размер — по длинной стороне, в пикселях.", TEXTURES_LATER});
	}
	AddSwitch(
	    tiles, explanation, L"Уменьшать и несжатые текстуры", settings->texture_mip_skip_uncompressed,
	    [settings, save](bool on) {
		    settings->texture_mip_skip_uncompressed = on;
		    ApplyTextureSizes(*settings);
		    save();
	    },
	    {L"Несжатые текстуры с мипмапами тоже получают пониженное разрешение.", TEXTURES_LATER});
	AddChoice(
	    tiles, explanation, L"Резкость текстур", {L"Полная", L"На один уровень мягче", L"На два уровня мягче", L"На три уровня мягче", L"На четыре уровня мягче"},
	    std::min<uint32_t>(settings->texture_lod_bias, 4),
	    [settings, save](size_t index) {
		    settings->texture_lod_bias = static_cast<uint32_t>(index);
		    ApplyTextureFiltering(*settings);
		    save();
	    },
	    {L"Текстуры рисуются из их уменьшенных версий. Память это не экономит.", L"Может быть немного быстрее, когда упор в GPU, но картинка размытее."});
	AddSwitch(
	    tiles, explanation, L"Анизотропная фильтрация", settings->anisotropic_filtering,
	    [settings, save](bool on) {
		    settings->anisotropic_filtering = on;
		    ApplyTextureFiltering(*settings);
		    save();
	    },
	    {L"Сохраняет резкость текстур на поверхностях, видимых под углом, где этого требует игра.", L"При «Выкл.» используется обычная фильтрация. Это может быть чуть быстрее."});
}

} // namespace Kyty::Uwp
